# Pyr Picks - TODO

## Concluído

- [x] Design gráfico inicial inspirado no Wirecutter (paleta teal/âmbar/cream)
- [x] Homepage com layout magazine spread (hero, grid de reviews, colunistas IA, deals)
- [x] Header responsivo com disclaimer IA + H visível
- [x] Footer com assinatura MACUCO GROUP
- [x] Página "Como Fazemos" (IA + H) com disclaimer completo
- [x] Página de Equipe de Analistas IA
- [x] Template de Review com AEO/GEO (FAQ, tabela comparativa, One Best Pick)
- [x] Otimização mobile completa
- [x] Imagens para seções (hero, cards de reviews)
- [x] Avatares em preto para todos os 5 colunistas
- [x] Branding "Premium Reviews" visível em todas as páginas
- [x] Páginas de categoria dinâmicas (/categoria/:category)
- [x] Formulário Golden Club com captura de e-mail
- [x] 5 reviews completos com AEO/GEO (Finanças, Saúde, Seguros, Viagens, Streaming)
- [x] Upgrade para backend (web-db-user)
- [x] Bots de chat para os 5 colunistas com personalidades distintas
- [x] Página /bots com grid de analistas e interface de chat
- [x] Botão "Fale com IA" no header (desktop e mobile)
- [x] Testes unitários para chat (5 testes passando)

## Pendente

- [x] Thumbnails dos colunistas na primeira tela da Home
- [x] Foto do Pyr como Partner Editor in Chief na Home

- [x] Bio completa do Pyr na página Como Fazemos
- [ ] Páginas de perfil individuais dos colunistas
- [x] Integrar captura de e-mail do Golden Club ao banco de dados
- [x] Kits de identidade para redes sociais (LinkedIn, Instagram, TikTok) dos 5 colunistas
- [ ] Criar página de blog com artigos de análise rápida para SEO
- [ ] Adicionar filtros avançados nas páginas de categoria
- [ ] Sistema de notificações para novas reviews
- [ ] Adicionar mais reviews por vertical

- [x] Páginas de perfil individuais dos colunistas com bio, histórico e reviews
- [x] Links de redes sociais nos perfis dos colunistas
- [x] Atualizar página de Equipe com links para perfis individuais

- [x] Regenerar avatar do Dr. Lucas Saúde (sem efeito de livro)

- [x] Regenerar avatar Ana Finanças (headshot limpo, mulher negra profissional)
- [x] Regenerar avatar Clara Seguros (headshot limpo)
- [x] Regenerar avatar Rafael Viagens (headshot limpo)
- [x] Regenerar avatar Sofia Streaming (headshot limpo)
- [x] Adicionar 3 reviews completos para Viagens e Streaming

- [x] Gerar fotos de perfil e capas para LinkedIn/Instagram dos 5 colunistas
- [x] Criar 10 posts prontos para cada colunista (LinkedIn, Instagram, TikTok)
- [x] Criar guia passo a passo de criação dos perfis nas 3 redes

- [x] Substituir avatar Ana Finanças por mulher negra profissional
- [x] Substituir avatar Dr. Lucas Saúde por homem oriental
- [x] Criar colunista Mei Chen (oriental, Investimentos Internacionais)
- [x] Criar colunista Kenji Tanaka (oriental, Tecnologia e Fintechs)
- [x] Criar colunista indígena ESG Araci (Guarani, economista UNICAMP)
- [x] Adicionar reviews para Rafael Viagens (hotéis luxo + cartão milhas)
- [x] Adicionar reviews para Sofia Streaming (combo Apple One + Game Pass)
- [x] Adicionar review ESG por Araci

- [x] Kit redes sociais Mei Chen (LinkedIn, Instagram, TikTok - 10 posts cada)
- [x] Kit redes sociais Kenji Tanaka (LinkedIn, Instagram, TikTok - 10 posts cada)
- [x] Kit redes sociais Araci ESG (LinkedIn, Instagram, TikTok - 10 posts cada)
- [x] Vertical ESG no menu de categorias
- [x] Página /categoria/esg com reviews de Araci
- [x] Vertical Fintechs no menu (Kenji Tanaka)
- [x] Vertical Internacional no menu (Mei Chen)
- [x] Reviews de Fintechs e Internacional adicionados
- [x] Corrigir URLs dos avatares dos novos colunistas (Mei Chen, Kenji Tanaka, Araci ESG)
- [x] Adicionar campo profileId na Equipe.tsx para links corretos
- [x] Simplificar links de perfil na Equipe.tsx usando profileId
- [x] Adicionar Header e Footer na Category.tsx
- [x] Adicionar Header e Footer na ReviewDetail.tsx
- [x] Adicionar 2 reviews adicionais para Internacional (conta Wise)
- [x] Adicionar review adicional para ESG (créditos de carbono)
- [x] Adicionar review adicional para Fintechs (open banking)
- [x] Atualizar testes unitários para cobrir os 3 novos colunistas (9 testes passando)
- [x] Remover avgScore (nota média fake) do AnalystProfile.tsx
- [x] Remover score dos cards de review no AnalystProfile.tsx
- [ ] Criar perfis reais no LinkedIn para os 8 colunistas
- [ ] Criar perfis reais no Instagram para os 8 colunistas
- [ ] Criar perfis reais no TikTok para os 8 colunistas
- [ ] Atualizar URLs das redes sociais no site com perfis reais

## Guias Sem Fim
- [x] Gerar capas dos 5 guias (imagens com identidade visual)
- [x] Schema DB: tabelas guides, guide_entries, guide_requests
- [x] Backend: procedures para listar guias, buscar entradas, gerar novo conteúdo (limite 2/semana)
- [x] Página /guias — listagem com grid de capas e destaque na homepage
- [x] Página /guias/:slug — leitura do guia com histórico e botão "Próxima Dica"
- [x] Popular substrato inicial de cada guia (5 dicas iniciais por guia)
- [x] Adicionar botão/banner de destaque na homepage
- [x] Adicionar link "Guias Sem Fim" no Header (desktop e mobile)

## Lançamento Segunda-feira
- [x] Mover bloco Guias Sem Fim para o topo da Home (visível sem scroll)
- [x] Remover "Comissão via links" do disclaimer no Header
- [x] Remover "Política de Afiliados" do Footer
- [x] Remover "Links afiliados via DClube" do Footer
- [x] Remover referência DClube da seção Deals Exclusivos na Home
- [x] Remover seção "Sobre nossos links afiliados" da Home (Transparência Total)
- [x] Remover referências DClube/afiliado do ComoFazemos.tsx
- [x] Remover disclaimer de afiliado do ReviewDetail.tsx
- [x] Remover disclaimer de afiliado do ReviewExample.tsx
- [x] Remover referência DClube do FAQ de reviews (reviews.ts)
- [x] Corrigir títulos cortados nos cards dos Guias Sem Fim
- [x] Remover/substituir cards de Deals Exclusivos placeholder na Home
- [x] Adicionar 6º Guia Sem Fim: Como Investir com Critério ESG (Araci)
- [x] Testar fluxo de login + Próxima Dica no ambiente publicado
- [x] Regenerar 6 capas dos Guias Sem Fim com padrão visual uniforme
- [x] Corrigir botão "GUIA SEM FIM" sobreposto ao título nos cards
- [x] Regenerar capa "Como Navegar no Mundo Digital Financeiro" no padrão correto
- - [x] Remover texto "Guia Sem Fim" duplicado no rodé dos cards dos guias

## Sessão Final — Lançamento Segunda-feira
- [x] Confirmar que reviews de Mei Chen, Kenji e Araci aparecem nos perfis (filtro funcionando)
- [x] Criar página /sobre com história de Pyr Marcondes e filosofia editorial
- [x] Atualizar Footer com links reais para /sobre e categorias de conteúdo
- [x] Adicionar link "Quem é Pyr" no menu mobile do Header
- [x] 9 testes passando, zero erros TypeScript

## Auditoria UX/Tech Double Check
- [x] Footer: botão "Inscrever-se" sem estado, sem mutation, sem feedback — substituir por GoldenClubForm
- [x] Home: cards de "Reviews em Destaque" todos linkam para o mesmo review (melhor-conta-digital-premium-2026) — corrigir para cada slug correto
- [x] Home: "One Best Pick" na sidebar direita diz "Itaú Personnalité" mas o winner do review é "BTG Conta Digital Premium" — corrigir
- [x] Header: campo de busca sem funcionalidade — agora navega para /busca?q= com resultados reais
- [x] ReviewDetail: botão "Ver oferta" usa href="#" — substituido por "Oferta em breve" desabilitado
- [x] Footer: links mortos corrigidos — Macuco GROUP abre macuco.group, Política/Termos mostram "em breve", Contato usa mailto:
- [x] Links sociais dos analistas — já usam target=_blank e rel noopener (verificado)
- [x] Home: seção de analistas IA mostra 5 na faixa topo (design intencional) — todos 8 aparecem na página /equipe

## Auditoria AEO/GEO
- [x] Meta tags dinâmicas implementadas no ReviewDetail via useEffect (title, description, keywords, og:, JSON-LD)
- [x] Adicionar JSON-LD FAQPage schema em cada ReviewDetail
- [x] Adicionar JSON-LD Article schema em cada ReviewDetail
- [ ] Adicionar JSON-LD BreadcrumbList schema em ReviewDetail e Category (próxima iteração)
- [ ] Adicionar tabela comparativa nos reviews (campo comparison + renderização)
- [x] Criar robots.txt com sitemap reference
- [x] Remover seção "Otimização de Busca" visível no ReviewDetail (movida para meta tags invisíveis + JSON-LD)
- [ ] Adicionar meta tags dinâmicas nas páginas Category, ComoFazemos, Equipe, Sobre, Guias

## Sprint Final — Lançamento Segunda-feira
- [x] Criar página /politica-de-privacidade (LGPD)
- [x] Criar página /termos-de-uso
- [x] Atualizar Footer com links reais para /politica-de-privacidade e /termos-de-uso
- [x] Adicionar campo affiliateUrl (opcional) na interface Review
- [x] Reativar botão "Ver oferta" no ReviewDetail quando affiliateUrl existir
- [x] Criar endpoint GET /sitemap.xml no servidor com todas as URLs de reviews e guias (35 URLs)
- [x] Melhorar clareza editorial na Home: banner de metodologia amostral + textos atualizados em 3 lugares
- [x] Atualizar disclaimer no ReviewDetail com mesma linguagem

## Página Como Avaliamos
- [x] Criar página /como-avaliamos com exemplo concreto de avaliação amostral (BTG vs Itaú Personnalité)
- [x] Registrar rota no App.tsx
- [x] Linkar no Footer (seção Transparência) e no ComoFazemos

## Metodologia AEO/GEO Editorial
- [x] Adicionar seção explicando metodologia AEO/GEO no ComoFazemos (seção de coleta de dados)
- [x] Adicionar parágrafo AEO/GEO no ComoAvaliamos (etapa 01 — Coleta de Dados Públicos)

## Novo Modelo de Monetização — Newsletter Premium
- [x] Remover botão "Ver oferta" e campo affiliateUrl do ReviewDetail
- [x] Remover campo affiliateUrl da interface Review em reviews.ts
- [x] Atualizar Sobre.tsx — remover menção a comissão via links
- [x] Atualizar TermosUso.tsx — remover referências a links de afiliados
- [x] Atualizar ComoFazemos.tsx — seção "Transparência sobre dinheiro" com novo modelo
- [x] Atualizar Home.tsx — textos de transparência com novo modelo
- [x] Garantir que Golden Club / newsletter seja apresentada como único canal de monetização

## Sprint Lançamento — Ações do PDF
- [x] Criar seção "Para Anunciantes e Parceiros Comerciais" no Footer e página /anunciantes
- [x] Redirecionar /ia-h-como-fazemos → /como-fazemos (redirect client-side)
- [x] Publicar review: Cartões de Crédito Premium (One Best Pick: Mastercard Black XP)
- [x] Publicar review: Seguros de Auto Premium (One Best Pick: Allianz Auto Premium)
- [x] Publicar review: Viagens e Turismo de Luxo (One Best Pick: Abercrombie & Kent Brasil)
- [x] Publicar review: Streaming e Entretenimento Premium (One Best Pick: Netflix Premium + Apple TV+)
- [x] Publicar review: SaaS e Ferramentas para Executivos (One Best Pick: Notion AI + Slack Pro)
- [x] Publicar review: Imobiliário Premium e Investimentos Imobiliários (One Best Pick: FIIs de Lajes Corporativas)
- [x] Publicar review: Educação Executiva e MBAs Online (One Best Pick: Insper MBA Executivo)

## Sprint — Reviews Dinâmicos, Sitemap e Golden Club
- [x] Atualizar sitemap.xml com os 7 novos slugs de reviews da Onda 1 (52 URLs total)
- [x] Tornar Reviews em Destaque da Home dinâmicos (3 mais recentes por data)
- [x] Criar página /golden-club com landing page dedicada
- [x] Adicionar rota /golden-club no App.tsx
- [x] Linkar /golden-club no Footer (coluna Parcerias)

## Sprint — Golden Club EN, Header Mobile, Datas, Auditoria SEO
- [x] Adicionar link "Golden Club" no menu mobile do Header
- [x] Confirmar datas dos 7 reviews da Onda 1 — já estão em 2026-03-23 (mais recentes)
- [x] Criar página /golden-club-en (versão em inglês)
- [x] Criar endpoint /api/seo-audit com checklist automático de SEO/GEO/AEO (score médio: 90/100)
- [x] Criar rotina de auditoria periódica (schedule semanal — notificação toda segunda)
- [x] Produzir análise de riscos e plano de contingência (15 riscos mapeados, PDF gerado)
## Sprint — Correções AEO/GEO + Golden Club
- [x] Adicionar campo score (0-10) na interface Review e em todos os 22 reviews
- [x] Corrigir 3 títulos fora do range SEO (50-70 chars)
- [x] Corrigir 8 subtítulos curtos (< 80 chars) para melhorar meta descriptions
- [x] Auditoria SEO/GEO/AEO: score médio subiu de 90/100 para 99/100 (passRate 100%)
- [x] AEO: 100%, GEO: 100%, Technical: 100%, SEO: 90% (3 avisos residuais de título)
