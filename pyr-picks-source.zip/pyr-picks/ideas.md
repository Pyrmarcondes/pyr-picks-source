# Brainstorm de Design — Pyr Picks

## Contexto
Site de reviews editoriais premium estilo Wirecutter brasileiro, focado em serviços financeiros, saúde, seguros, viagens e lifestyle premium. Público: executivos e investidores de alto poder aquisitivo. Modelo: IA + H (Human in the Loop) com 10 robôs colunistas e curadoria de Pyr (50 anos de jornalismo).

---

<response>
<idea>

### Ideia 1: "Editorial Broadsheet" — Jornalismo de Autoridade

**Design Movement**: Inspirado no design editorial clássico de broadsheets premium (Financial Times, The Economist), com toques de Swiss Typography e a limpeza do Wirecutter.

**Core Principles**:
1. Hierarquia tipográfica rigorosa — o texto é o herói, não a decoração.
2. Espaço em branco como sinal de sofisticação e confiança.
3. Estrutura assimétrica em colunas que remete a um jornal de qualidade.
4. Credibilidade visual transmitida pela sobriedade, não pelo excesso.

**Color Philosophy**: Paleta restrita e intencional. Fundo off-white quente (#FAFAF7) que evoca papel de qualidade. Texto em preto profundo (#1A1A1A). Cor de destaque em azul-marinho (#0A2540) para links e CTAs — transmite confiança institucional sem ser corporativo demais. Amarelo pálido (#FFF3CD) para caixas de "One Best Pick", evocando o destaque editorial com caneta marca-texto. Vermelho editorial (#C53030) apenas para badges de urgência.

**Layout Paradigm**: Layout assimétrico em 3 colunas na homepage (sidebar esquerda estreita com navegação contextual, coluna central dominante com hero article, sidebar direita com deals). Páginas de review usam layout de leitura longa com margem generosa e sidebar flutuante para "Table of Contents". Mobile-first com colapso inteligente.

**Signature Elements**:
1. Linhas finas horizontais como separadores de seção (estilo broadsheet), com pequenos detalhes tipográficos nos cruzamentos.
2. Caixas de "One Best Pick" com borda esquerda grossa em azul-marinho e fundo amarelo pálido — o elemento mais reconhecível do site.
3. Avatares dos robôs colunistas em estilo "gravura digital" — ilustrações monocromáticas com sutil glitch digital, posicionados ao lado do byline.

**Interaction Philosophy**: Interações sutis e funcionais. Hover em links revela underline animado. Cards de review têm micro-elevação no hover. Transições de página são crossfades suaves. Nada pisca, nada distrai — cada interação reforça a sensação de publicação séria.

**Animation**: Entrada de elementos com fade-in sutil de baixo para cima (staggered, 100ms entre elementos). Tabelas comparativas revelam linhas sequencialmente. Sidebar de "Table of Contents" acompanha o scroll com smooth-scroll. Caixas de "One Best Pick" têm uma animação de "spotlight" sutil ao entrar no viewport.

**Typography System**: Títulos em **Playfair Display** (serifada, peso 700-900) para autoridade e tradição. Corpo em **Source Sans 3** (sans-serif, peso 400-600) para leitura confortável em telas. Bylines e metadados em **Source Sans 3** italic/light. Tabelas em **JetBrains Mono** para dados numéricos. Escala tipográfica: H1 (2.5rem), H2 (1.75rem), H3 (1.25rem), body (1.05rem, line-height 1.7).

</idea>
<text>Design editorial broadsheet premium com tipografia serifada dominante, layout assimétrico em 3 colunas, paleta restrita (off-white, azul-marinho, amarelo pálido) e interações sutis que reforçam credibilidade jornalística.</text>
<probability>0.08</probability>
</response>

---

<response>
<idea>

### Ideia 2: "Fintech Brutalism Lite" — Transparência Radical como Estética

**Design Movement**: Inspirado no Neo-Brutalism digital (Linear, Gumroad) combinado com a transparência radical do Wirecutter e a clareza de dados do NerdWallet. Anti-decoração, pró-informação.

**Core Principles**:
1. Informação acima de tudo — cada pixel serve a um propósito funcional.
2. Contraste extremo para hierarquia imediata.
3. Bordas visíveis e estrutura exposta como metáfora de transparência.
4. Dados são o ornamento — tabelas, gráficos e números são os elementos visuais.

**Color Philosophy**: Fundo branco puro (#FFFFFF) com blocos de cor sólida sem gradiente. Preto (#000000) para texto e bordas. Verde-escuro (#0D4B3C) como cor primária — evoca dinheiro, crescimento e confiança sem ser o "verde startup" genérico. Amarelo vivo (#FFD60A) para highlights e badges "One Best Pick". Cinza claro (#F0F0F0) para cards e seções alternadas.

**Layout Paradigm**: Grid modular com bordas visíveis entre seções (estilo jornal/dashboard). Homepage usa grid de cards com tamanhos variados (hero card 2x2, cards regulares 1x1). Páginas de review usam layout de "documento" com seções claramente delimitadas por bordas e backgrounds alternados. Sem cantos arredondados — tudo angular e direto.

**Signature Elements**:
1. Bordas pretas de 2px em todos os cards e seções — a estrutura é visível, nada se esconde.
2. Badge "One Best Pick" em amarelo vivo com texto preto bold e sombra offset (estilo neo-brutalist).
3. Robôs colunistas representados como ícones geométricos estilizados com código binário sutil no fundo — cada um com uma cor de destaque diferente.

**Interaction Philosophy**: Interações diretas e "honestas". Hover em cards adiciona sombra offset sólida (não blur). Botões têm estado pressed visível com deslocamento. Tooltips aparecem instantaneamente. Feedback é imediato e sem ambiguidade — como o modelo IA + H.

**Animation**: Mínima e funcional. Entrada de cards com slide-in lateral rápido (200ms). Tabelas expandem com accordion sem bounce. Números em tabelas fazem count-up ao entrar no viewport. Transições de página são cortes secos com fade mínimo.

**Typography System**: Títulos em **Space Grotesk** (geométrica, peso 700) para modernidade e impacto. Corpo em **IBM Plex Sans** (peso 400-500) para legibilidade técnica. Dados e tabelas em **IBM Plex Mono** para precisão. Bylines em **Space Grotesk** peso 500. Escala: H1 (3rem), H2 (2rem), H3 (1.4rem), body (1rem, line-height 1.65).

</idea>
<text>Neo-brutalism digital com bordas visíveis, contraste extremo, verde-escuro e amarelo vivo, layout em grid modular angular e tipografia geométrica — transparência radical como princípio estético.</text>
<probability>0.05</probability>
</response>

---

<response>
<idea>

### Ideia 3: "Curated Intelligence" — Sofisticação Discreta com DNA Digital

**Design Movement**: Inspirado no design de publicações premium digitais (Monocle, Bloomberg Businessweek online) com influência de interfaces de dados financeiros (Bloomberg Terminal simplificado). Sofisticação que não grita.

**Core Principles**:
1. Elegância funcional — cada elemento é bonito porque é útil.
2. Densidade informacional controlada — muito conteúdo, zero ruído.
3. Dualidade humano-máquina como tema visual (IA + H refletido no design).
4. Microdetalhes que recompensam a atenção do leitor premium.

**Color Philosophy**: Fundo em cinza-creme muito sutil (#F8F6F3) que é mais quente que branco puro. Texto em grafite profundo (#2D2D2D). Cor primária em teal escuro (#0C6B58) — sofisticado, diferente do azul genérico, evoca expertise financeira. Cor secundária em âmbar (#D4A843) para destaques e "One Best Pick" — evoca ouro e premium. Linhas e separadores em cinza médio (#D1CCC5).

**Layout Paradigm**: Layout "magazine spread" com seções de largura variável. Homepage usa hero section com tipografia grande + grid de cards abaixo com 2-3 colunas que se adaptam. Páginas de review usam layout de leitura com "margin notes" (anotações na margem, como livros acadêmicos) para dados extras e links. Sidebar colapsável com perfis dos robôs colunistas.

**Signature Elements**:
1. "Margin notes" nas páginas de review — dados complementares, citações e links aparecem na margem como em publicações acadêmicas premium, colapsando em tooltips no mobile.
2. Indicador visual "IA + H" em cada artigo: uma barra sutil que mostra a proporção de contribuição IA vs. humana (ex: "Pesquisa IA 70% | Curadoria Pyr 30%").
3. Avatares dos robôs colunistas em estilo "retrato editorial com overlay digital" — fotos estilizadas com camada sutil de padrão de circuito, cada um com sua cor teal/âmbar.

**Interaction Philosophy**: Interações que revelam profundidade. Hover em cards mostra preview do "One Best Pick" em tooltip rico. Scroll em reviews revela "margin notes" com parallax sutil. Tabelas comparativas têm sorting e filtering inline. Cada interação dá ao leitor a sensação de estar usando uma ferramenta de inteligência, não apenas lendo um blog.

**Animation**: Sofisticada e contida. Elementos entram com fade + scale sutil (de 0.98 a 1.0, 300ms ease-out). Tabelas têm row-highlight animado no hover. Barra "IA + H" preenche com animação suave ao entrar no viewport. Transições de página usam shared-element animation nos cards que viram artigos. Scroll-triggered animations para seções de dados.

**Typography System**: Títulos em **DM Serif Display** (serifada elegante, peso 400-700) para sofisticação editorial. Corpo em **DM Sans** (sans-serif, peso 400-500) para harmonia com os títulos e leitura fluida. Dados em **Fira Code** (monospace) para tabelas e números. Metadados em **DM Sans** peso 300 italic. Escala: H1 (2.75rem), H2 (1.875rem), H3 (1.3rem), body (1.05rem, line-height 1.75).

</idea>
<text>Sofisticação discreta com DNA digital, layout magazine com margin notes, paleta teal-escuro e âmbar, indicador visual IA + H e tipografia serifada elegante — publicação premium que funciona como ferramenta de inteligência.</text>
<probability>0.07</probability>
</response>
