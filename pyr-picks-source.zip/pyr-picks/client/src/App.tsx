import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Category from "./pages/Category";
import ReviewDetail from "./pages/ReviewDetail";
import ComoFazemos from "./pages/ComoFazemos";
import Equipe from "./pages/Equipe";
import ReviewExample from "./pages/ReviewExample";
import Bots from "./pages/Bots";
import AnalystProfile from "./pages/AnalystProfile";
import Guias from "./pages/Guias";
import Sobre from "./pages/Sobre";
import GuiaDetail from "./pages/GuiaDetail";
import Busca from "./pages/Busca";
import PoliticaPrivacidade from "./pages/PoliticaPrivacidade";
import TermosUso from "./pages/TermosUso";
import ComoAvaliamos from "./pages/ComoAvaliamos";
import Anunciantes from "./pages/Anunciantes";
import GoldenClub from "./pages/GoldenClub";
import GoldenClubEn from "./pages/GoldenClubEn";
import { Redirect } from "wouter";
function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/categoria/:category"} component={Category} />
      <Route path={"/review/:id"} component={ReviewDetail} />
      <Route path={"/como-fazemos"} component={ComoFazemos} />
      <Route path={"/equipe"} component={Equipe} />
      <Route path={"/bots"} component={Bots} />
      <Route path={"/colunista/:id"} component={AnalystProfile} />
      <Route path={"/guias"} component={Guias} />
      <Route path={"/guias/:slug"} component={GuiaDetail} />
      <Route path={"/sobre"} component={Sobre} />
      <Route path={"/busca"} component={Busca} />
      <Route path={"/politica-de-privacidade"} component={PoliticaPrivacidade} />
      <Route path={"/termos-de-uso"} component={TermosUso} />
      <Route path={"/como-avaliamos"} component={ComoAvaliamos} />
      <Route path={"/anunciantes"} component={Anunciantes} />
      <Route path={"/golden-club"} component={GoldenClub} />
      <Route path={"/golden-club-en"} component={GoldenClubEn} />
      {/* Redirect legado: /ia-h-como-fazemos → /como-fazemos */}
      <Route path={"/ia-h-como-fazemos"}>
        <Redirect to="/como-fazemos" />
      </Route>
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
