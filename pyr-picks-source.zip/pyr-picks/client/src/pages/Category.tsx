import { useParams, Link } from 'wouter';
import { motion } from 'framer-motion';
import { ArrowRight, ChevronLeft } from 'lucide-react';
import { getReviewsByCategory, categories } from '@/lib/reviews';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function Category() {
  const { category } = useParams<{ category: string }>();
  
  const categoryData = categories.find(c => c.id === category);
  const categoryReviews = category ? getReviewsByCategory(category) : [];

  if (!categoryData) {
    return (
      <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
        <Header />
        <main className="flex-1 flex flex-col items-center justify-center">
          <h1 className="text-2xl font-bold text-[#2D2D2D] mb-4">Categoria não encontrada</h1>
          <Link href="/" className="flex items-center gap-2 text-[#0C6B58] hover:underline no-underline">
            <ChevronLeft className="w-4 h-4" />
            Voltar para home
          </Link>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
      <Header />
      <main className="flex-1">
        {/* Page Header */}
        <div className="border-b border-[#D1CCC5]/50 bg-gradient-to-b from-[#D4A843]/5 to-white">
          <div className="container py-8 lg:py-12">
            <Link href="/" className="inline-flex items-center gap-2 text-sm text-[#0C6B58] hover:underline no-underline mb-4">
              <ChevronLeft className="w-4 h-4" />
              Voltar
            </Link>
            <h1 className="text-3xl lg:text-4xl text-[#2D2D2D] mb-2" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
              {categoryData.name}
            </h1>
            <p className="text-base lg:text-lg text-[#2D2D2D]/60">
              {categoryData.description}
            </p>
          </div>
        </div>

        {/* Reviews Grid */}
        <div className="container py-8 lg:py-16">
          {categoryReviews.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-lg text-[#2D2D2D]/60">Nenhuma review disponível nesta categoria ainda.</p>
              <p className="text-sm text-[#2D2D2D]/40 mt-2">Nossos analistas IA estão trabalhando nas próximas análises.</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {categoryReviews.map((review, index) => (
                <motion.div
                  key={review.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Link href={`/review/${review.id}`} className="group no-underline">
                    <div className="bg-white rounded-xl overflow-hidden border border-[#D1CCC5]/30 hover:border-[#0C6B58]/20 hover:shadow-lg transition-all h-full flex flex-col">
                      {/* Image */}
                      <div className="relative h-48 overflow-hidden bg-[#F8F6F3]">
                        <img
                          src={review.image}
                          alt={review.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      </div>

                      {/* Content */}
                      <div className="p-5 lg:p-6 flex flex-col flex-1">
                        <div className="flex items-center gap-2 mb-3">
                          <span className="inline-block px-2.5 py-1 bg-[#D4A843] text-[#2D2D2D] text-[10px] font-bold uppercase tracking-wider rounded-full">
                            One Best Pick
                          </span>
                          <span className="inline-block px-2 py-0.5 bg-[#0C6B58]/10 text-[#0C6B58] text-[9px] font-semibold uppercase tracking-wider rounded">
                            {review.analyst}
                          </span>
                        </div>

                        <h3 className="text-base lg:text-lg font-semibold text-[#2D2D2D] mb-2 line-clamp-2" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                          {review.title}
                        </h3>

                        <p className="text-xs lg:text-sm text-[#2D2D2D]/60 mb-4 flex-1">
                          {review.subtitle}
                        </p>

                        <div className="flex items-center justify-between pt-4 border-t border-[#D1CCC5]/30">
                          <span className="text-xs font-semibold text-[#0C6B58]">
                            {review.winner}
                          </span>
                          <ArrowRight className="w-4 h-4 text-[#0C6B58] group-hover:translate-x-1 transition-transform" />
                        </div>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}
