/**
 * Pyr Picks — Página Golden Club
 * Landing page dedicada para a newsletter premium
 */
import { motion } from "framer-motion";
import { Star, Shield, Mail, TrendingUp, Users, CheckCircle, ArrowRight } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import GoldenClubForm from "@/components/GoldenClubForm";
import { Link } from "wouter";

const PYR_PHOTO = "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/pyr-marcondes-editor_53a6a2c4.jpeg";

const benefits = [
  {
    icon: TrendingUp,
    title: "Ofertas Premium Curadas",
    description: "Negociadas diretamente por Pyr com parceiros selecionados. Nunca disponíveis ao público geral.",
    color: "#D4A843",
  },
  {
    icon: Star,
    title: "Reviews em Primeira Mão",
    description: "Receba as análises antes de serem publicadas no site. Seja o primeiro a saber qual é o One Best Pick.",
    color: "#0C6B58",
  },
  {
    icon: Shield,
    title: "Zero Conflito de Interesse",
    description: "As ofertas chegam na newsletter — nunca nos reviews. A análise editorial é 100% independente das ofertas.",
    color: "#1a5276",
  },
  {
    icon: Mail,
    title: "Frequência Respeitosa",
    description: "Enviamos apenas quando há algo relevante. Sem spam, sem conteúdo de enchimento, sem pressão de vendas.",
    color: "#6a1b9a",
  },
];

const faq = [
  {
    question: "O que é o Golden Club?",
    answer: "É a newsletter premium do Pyr Picks. Nela, Pyr Marcondes compartilha ofertas exclusivas negociadas com parceiros selecionados — produtos e serviços que passaram pelo mesmo rigor editorial dos reviews, mas com condições especiais para membros.",
  },
  {
    question: "Como o Golden Club se diferencia dos reviews do site?",
    answer: "Os reviews são 100% editoriais e independentes — nenhum clique neles gera receita para o Pyr Picks. O Golden Club é o único canal de monetização: as ofertas chegam na newsletter, nunca no conteúdo editorial. Essa separação é a garantia da independência.",
  },
  {
    question: "Com que frequência a newsletter é enviada?",
    answer: "Enviamos apenas quando há algo genuinamente relevante para os membros. Não há frequência fixa — pode ser semanal em períodos de muitas novidades, ou quinzenal quando o mercado está parado. Nunca enviamos por obrigação de calendário.",
  },
  {
    question: "Como as ofertas são selecionadas?",
    answer: "Pyr negocia diretamente com os parceiros. O critério é o mesmo dos reviews: o produto ou serviço precisa ser genuinamente bom para o perfil executivo do leitor. Parceiros que não passam nesse critério não entram na newsletter, independentemente do valor comercial.",
  },
  {
    question: "Posso cancelar a inscrição?",
    answer: "Sim, a qualquer momento. Todo e-mail tem um link de descadastramento. Não há período mínimo de permanência.",
  },
  {
    question: "Meus dados são compartilhados com os parceiros?",
    answer: "Não. Seu e-mail é usado exclusivamente para envio da newsletter do Pyr Picks. Não compartilhamos, vendemos ou cedemos dados de membros a terceiros — em conformidade com a LGPD.",
  },
];

export default function GoldenClub() {
  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
      <Header />

      <main className="flex-1">

        {/* Hero */}
        <section className="relative overflow-hidden bg-gradient-to-br from-[#2D2D2D] via-[#1a1a1a] to-[#0C6B58]">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-[#D4A843] blur-3xl" />
            <div className="absolute bottom-0 left-0 w-64 h-64 rounded-full bg-[#0C6B58] blur-3xl" />
          </div>
          <div className="container relative py-16 lg:py-24">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
              >
                <div className="flex items-center gap-2 mb-4">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#D4A843]/20 border border-[#D4A843]/30 rounded-full text-xs font-bold uppercase tracking-[0.2em] text-[#D4A843]">
                    <Star className="w-3 h-3" />
                    Newsletter Premium
                  </span>
                </div>
                <h1
                  className="text-4xl lg:text-5xl text-white mb-4 leading-tight"
                  style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
                >
                  Golden Club
                </h1>
                <p className="text-xl text-white/70 mb-2 font-medium">
                  A newsletter de ofertas premium do Pyr Picks.
                </p>
                <p className="text-base text-white/50 mb-8 leading-relaxed">
                  Ofertas exclusivas negociadas por Pyr Marcondes com parceiros selecionados.
                  Nunca disponíveis ao público geral. Enviadas apenas quando há algo genuinamente relevante.
                </p>

                <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-6">
                  <p className="text-sm text-white/70 mb-4 font-medium">Inscreva-se gratuitamente:</p>
                  <GoldenClubForm source="golden-club-page" />
                  <p className="text-xs text-white/40 mt-3">
                    Sem spam. Cancelamento a qualquer momento. Seus dados nunca são compartilhados.
                  </p>
                </div>
              </motion.div>

              <motion.div
                className="hidden lg:flex flex-col gap-6"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                {/* Carta do Pyr */}
                <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6">
                  <div className="flex items-start gap-4 mb-4">
                    <img
                      src={PYR_PHOTO}
                      alt="Pyr Marcondes"
                      className="w-14 h-14 rounded-full object-cover border-2 border-[#D4A843]/50"
                    />
                    <div>
                      <p className="text-white font-semibold text-sm">Pyr Marcondes</p>
                      <p className="text-white/50 text-xs">Editor-Chefe, Pyr Picks</p>
                      <p className="text-white/40 text-xs">50 anos de jornalismo editorial de negócios, economia e finanças</p>
                    </div>
                  </div>
                  <blockquote className="text-white/70 text-sm leading-relaxed italic border-l-2 border-[#D4A843]/50 pl-4">
                    "O Golden Club nasceu de uma convicção simples: quem lê o Pyr Picks merece ofertas tão rigorosas quanto nossas análises. Só entra na newsletter o que eu mesmo usaria — e o que eu posso defender com o mesmo padrão editorial dos reviews."
                  </blockquote>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-white/5 border border-white/10 rounded-xl p-4 text-center">
                    <p className="text-2xl font-bold text-[#D4A843]">22</p>
                    <p className="text-xs text-white/50 mt-1">Reviews publicados</p>
                  </div>
                  <div className="bg-white/5 border border-white/10 rounded-xl p-4 text-center">
                    <p className="text-2xl font-bold text-[#D4A843]">8</p>
                    <p className="text-xs text-white/50 mt-1">Analistas IA</p>
                  </div>
                  <div className="bg-white/5 border border-white/10 rounded-xl p-4 text-center">
                    <p className="text-2xl font-bold text-[#D4A843]">0%</p>
                    <p className="text-xs text-white/50 mt-1">Payola nos reviews</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* O que você recebe */}
        <section className="bg-white border-t border-[#D1CCC5]/50">
          <div className="container py-12 lg:py-16">
            <div className="text-center mb-10">
              <h2
                className="text-2xl lg:text-3xl text-[#2D2D2D] mb-3"
                style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
              >
                O que você recebe no Golden Club
              </h2>
              <p className="text-[#2D2D2D]/60 text-base max-w-xl mx-auto">
                Uma newsletter que respeita seu tempo e sua inteligência.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {benefits.map((benefit, i) => (
                <motion.div
                  key={i}
                  className="bg-[#F8F6F3] rounded-xl p-6 border border-[#D1CCC5]/30"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.1 }}
                >
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center mb-4"
                    style={{ backgroundColor: `${benefit.color}15` }}
                  >
                    <benefit.icon className="w-5 h-5" style={{ color: benefit.color }} />
                  </div>
                  <h3 className="text-sm font-bold text-[#2D2D2D] mb-2">{benefit.title}</h3>
                  <p className="text-xs text-[#2D2D2D]/60 leading-relaxed">{benefit.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* A separação editorial */}
        <section className="bg-gradient-to-br from-[#0C6B58]/5 to-[#D4A843]/5 border-t border-[#D1CCC5]/50">
          <div className="container py-12 lg:py-16">
            <div className="max-w-3xl mx-auto">
              <div className="flex items-center gap-3 mb-6">
                <Shield className="w-6 h-6 text-[#0C6B58]" />
                <h2
                  className="text-xl lg:text-2xl text-[#2D2D2D]"
                  style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
                >
                  A Separação que Garante a Independência
                </h2>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-white rounded-xl p-6 border border-[#D1CCC5]/30">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-6 h-6 rounded-full bg-[#0C6B58]/10 flex items-center justify-center">
                      <CheckCircle className="w-4 h-4 text-[#0C6B58]" />
                    </div>
                    <span className="text-sm font-bold text-[#0C6B58] uppercase tracking-wider">Reviews no Site</span>
                  </div>
                  <ul className="space-y-2 text-sm text-[#2D2D2D]/70">
                    <li className="flex items-start gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#0C6B58] mt-2 flex-shrink-0" />
                      100% editorial e independente
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#0C6B58] mt-2 flex-shrink-0" />
                      Nenhum clique gera receita para o Pyr Picks
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#0C6B58] mt-2 flex-shrink-0" />
                      One Best Pick escolhido exclusivamente por mérito
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#0C6B58] mt-2 flex-shrink-0" />
                      Parceiros comerciais não influenciam as análises
                    </li>
                  </ul>
                </div>

                <div className="bg-white rounded-xl p-6 border border-[#D4A843]/30">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-6 h-6 rounded-full bg-[#D4A843]/10 flex items-center justify-center">
                      <Star className="w-4 h-4 text-[#D4A843]" />
                    </div>
                    <span className="text-sm font-bold text-[#D4A843] uppercase tracking-wider">Golden Club</span>
                  </div>
                  <ul className="space-y-2 text-sm text-[#2D2D2D]/70">
                    <li className="flex items-start gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#D4A843] mt-2 flex-shrink-0" />
                      Único canal de monetização do Pyr Picks
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#D4A843] mt-2 flex-shrink-0" />
                      Ofertas negociadas diretamente por Pyr
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#D4A843] mt-2 flex-shrink-0" />
                      Apenas produtos que passam pelo rigor editorial
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#D4A843] mt-2 flex-shrink-0" />
                      Enviado apenas quando há algo genuinamente relevante
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section className="bg-white border-t border-[#D1CCC5]/50">
          <div className="container py-12 lg:py-16">
            <div className="max-w-3xl mx-auto">
              <h2
                className="text-2xl lg:text-3xl text-[#2D2D2D] mb-8 text-center"
                style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
              >
                Perguntas Frequentes
              </h2>
              <div className="space-y-4">
                {faq.map((item, i) => (
                  <motion.div
                    key={i}
                    className="border border-[#D1CCC5]/50 rounded-xl p-5"
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.3, delay: i * 0.05 }}
                  >
                    <h3 className="text-sm font-bold text-[#2D2D2D] mb-2">{item.question}</h3>
                    <p className="text-sm text-[#2D2D2D]/60 leading-relaxed">{item.answer}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* CTA Final */}
        <section className="bg-gradient-to-br from-[#2D2D2D] to-[#0C6B58]">
          <div className="container py-12 lg:py-16">
            <div className="max-w-xl mx-auto text-center">
              <Star className="w-8 h-8 text-[#D4A843] mx-auto mb-4" />
              <h2
                className="text-2xl lg:text-3xl text-white mb-3"
                style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
              >
                Junte-se ao Golden Club
              </h2>
              <p className="text-white/60 text-sm mb-6">
                Gratuito. Sem spam. Cancelamento a qualquer momento.
              </p>
              <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-6">
                <GoldenClubForm source="golden-club-cta" />
              </div>
              <div className="mt-6 flex items-center justify-center gap-4 text-xs text-white/40">
                <Link href="/politica-de-privacidade" className="hover:text-white/60 transition-colors no-underline">
                  Política de Privacidade
                </Link>
                <span>·</span>
                <Link href="/termos-de-uso" className="hover:text-white/60 transition-colors no-underline">
                  Termos de Uso
                </Link>
                <span>·</span>
                <Link href="/como-fazemos" className="hover:text-white/60 transition-colors no-underline flex items-center gap-1">
                  Como Funciona <ArrowRight className="w-3 h-3" />
                </Link>
              </div>
            </div>
          </div>
        </section>

      </main>

      <Footer />
    </div>
  );
}
