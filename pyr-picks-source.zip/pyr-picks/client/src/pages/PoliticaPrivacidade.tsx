/*
 * Política de Privacidade — Pyr Picks
 * Conformidade LGPD (Lei 13.709/2018)
 */
import { useEffect } from "react";
import { Link } from "wouter";
import { ChevronLeft, Shield } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function PoliticaPrivacidade() {
  useEffect(() => {
    document.title = "Política de Privacidade | Pyr Picks";
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
      <Header />
      <main className="flex-1">
        <div className="container py-10 lg:py-16 max-w-3xl mx-auto">
          {/* Breadcrumb */}
          <Link href="/" className="flex items-center gap-2 text-sm text-[#0C6B58] hover:underline no-underline mb-8">
            <ChevronLeft className="w-4 h-4" />
            Voltar para home
          </Link>

          {/* Header */}
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-full bg-[#0C6B58]/10 flex items-center justify-center flex-shrink-0">
              <Shield className="w-5 h-5 text-[#0C6B58]" />
            </div>
            <div>
              <h1
                className="text-3xl lg:text-4xl text-[#2D2D2D]"
                style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
              >
                Política de Privacidade
              </h1>
              <p className="text-sm text-[#2D2D2D]/50 mt-1">Última atualização: março de 2026</p>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-[#D1CCC5]/30 p-8 lg:p-10 space-y-8 text-[#2D2D2D]/80 leading-relaxed">

            <section>
              <h2 className="text-xl font-semibold text-[#2D2D2D] mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                1. Quem somos
              </h2>
              <p className="text-sm">
                O <strong>Pyr Picks</strong> é uma publicação editorial de reviews independentes operada pela <strong>Macuco GROUP</strong>. Nosso site é acessível em <a href="https://pyrpicks-eoegx4rq.manus.space" className="text-[#0C6B58] hover:underline">pyrpicks.com.br</a>. Para questões sobre privacidade, entre em contato pelo e-mail <a href="mailto:pyrpicks@macuco.group" className="text-[#0C6B58] hover:underline">pyrpicks@macuco.group</a>.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-[#2D2D2D] mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                2. Dados que coletamos
              </h2>
              <p className="text-sm mb-3">
                Coletamos apenas os dados estritamente necessários para o funcionamento do serviço:
              </p>
              <div className="space-y-3 text-sm">
                <div className="flex gap-3">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#0C6B58] flex-shrink-0 mt-1.5" />
                  <div>
                    <strong>E-mail (Golden Club):</strong> quando você se inscreve na nossa newsletter, coletamos seu endereço de e-mail para envio de comunicações editoriais. Você pode cancelar a inscrição a qualquer momento.
                  </div>
                </div>
                <div className="flex gap-3">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#0C6B58] flex-shrink-0 mt-1.5" />
                  <div>
                    <strong>Dados de autenticação (opcional):</strong> se você criar uma conta via login social (Manus OAuth), coletamos nome de exibição e identificador único. Não armazenamos senhas.
                  </div>
                </div>
                <div className="flex gap-3">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#0C6B58] flex-shrink-0 mt-1.5" />
                  <div>
                    <strong>Dados de uso (analytics):</strong> coletamos dados agregados e anonimizados de navegação (páginas visitadas, tempo de sessão) para melhorar o conteúdo editorial. Não identificamos usuários individualmente.
                  </div>
                </div>
                <div className="flex gap-3">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#0C6B58] flex-shrink-0 mt-1.5" />
                  <div>
                    <strong>Cookies técnicos:</strong> utilizamos cookies de sessão estritamente necessários para o funcionamento do site. Não utilizamos cookies de rastreamento de terceiros para publicidade.
                  </div>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-[#2D2D2D] mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                3. Como usamos seus dados
              </h2>
              <p className="text-sm">
                Seus dados são utilizados exclusivamente para: (a) envio da newsletter Pyr Picks Weekly, se você optou por se inscrever; (b) melhoria da experiência editorial com base em métricas agregadas; (c) comunicações transacionais relacionadas à sua conta, quando aplicável. <strong>Não vendemos, alugamos ou compartilhamos seus dados pessoais com terceiros para fins comerciais.</strong>
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-[#2D2D2D] mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                4. Base legal (LGPD)
              </h2>
              <p className="text-sm">
                O tratamento de dados pessoais no Pyr Picks é realizado com base nas seguintes hipóteses previstas na Lei Geral de Proteção de Dados (Lei 13.709/2018): <strong>consentimento</strong> (para envio de newsletter e comunicações de marketing); <strong>legítimo interesse</strong> (para analytics agregado e melhoria do serviço editorial); e <strong>execução de contrato</strong> (para funcionalidades de conta de usuário).
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-[#2D2D2D] mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                5. Seus direitos
              </h2>
              <p className="text-sm mb-3">
                Nos termos da LGPD, você tem direito a:
              </p>
              <div className="grid md:grid-cols-2 gap-2 text-sm">
                {[
                  "Confirmar a existência de tratamento dos seus dados",
                  "Acessar os dados que temos sobre você",
                  "Corrigir dados incompletos, inexatos ou desatualizados",
                  "Solicitar a anonimização ou exclusão dos seus dados",
                  "Revogar o consentimento a qualquer momento",
                  "Portabilidade dos dados a outro fornecedor",
                ].map((right) => (
                  <div key={right} className="flex gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#D4A843] flex-shrink-0 mt-1.5" />
                    <span>{right}</span>
                  </div>
                ))}
              </div>
              <p className="text-sm mt-3">
                Para exercer qualquer desses direitos, envie um e-mail para <a href="mailto:pyrpicks@macuco.group" className="text-[#0C6B58] hover:underline">pyrpicks@macuco.group</a> com o assunto "LGPD — [seu direito]". Responderemos em até 15 dias úteis.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-[#2D2D2D] mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                6. Retenção de dados
              </h2>
              <p className="text-sm">
                Mantemos seus dados pelo tempo necessário para a finalidade para a qual foram coletados, ou pelo prazo exigido por lei. Dados de newsletter são mantidos enquanto você permanecer inscrito. Após o cancelamento da inscrição, seus dados são excluídos em até 30 dias.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-[#2D2D2D] mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                7. Segurança
              </h2>
              <p className="text-sm">
                Adotamos medidas técnicas e organizacionais adequadas para proteger seus dados contra acesso não autorizado, perda ou destruição. O site utiliza HTTPS, autenticação via JWT assinado e não armazena senhas em texto claro.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-[#2D2D2D] mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                8. Alterações nesta política
              </h2>
              <p className="text-sm">
                Esta política pode ser atualizada periodicamente. Alterações significativas serão comunicadas por e-mail aos inscritos no Golden Club. A data da última atualização está sempre indicada no topo desta página.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-[#2D2D2D] mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                9. Contato
              </h2>
              <p className="text-sm">
                Dúvidas, solicitações ou reclamações relacionadas à privacidade podem ser enviadas para <a href="mailto:pyrpicks@macuco.group" className="text-[#0C6B58] hover:underline">pyrpicks@macuco.group</a>. Você também pode contatar a Autoridade Nacional de Proteção de Dados (ANPD) em <a href="https://www.gov.br/anpd" target="_blank" rel="noopener noreferrer" className="text-[#0C6B58] hover:underline">gov.br/anpd</a>.
              </p>
            </section>

          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
