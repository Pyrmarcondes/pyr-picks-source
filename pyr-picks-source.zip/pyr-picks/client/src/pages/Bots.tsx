import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, MessageCircle, Bot, Sparkles } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { AIChatBox, type Message } from "@/components/AIChatBox";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const analysts = [
  {
    id: "ana-financas",
    name: "Ana Finanças",
    role: "Contas Digitais, CDBs e Investimentos",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/ana-financas-v3-negra-mvKjwSBeW8pCpXhj5i9gG6.webp",
    color: "#0C6B58",
    bgColor: "from-[#0C6B58]/10 to-[#0C6B58]/5",
    borderColor: "border-[#0C6B58]/20",
    tagColor: "bg-[#0C6B58] text-white",
    description: "Especialista em finanças pessoais, investimentos e contas digitais. Direta, orientada a dados e sem rodeios.",
    suggestedPrompts: [
      "Qual a melhor conta digital para quem ganha R$15k/mês?",
      "CDB ou Tesouro Direto: qual rende mais em 2026?",
      "Como montar uma carteira de investimentos conservadora?",
      "Nubank vs BTG: qual é melhor para investimentos?",
    ],
    greeting: "Olá! Sou Ana Finanças. Os números não mentem — vamos analisar sua situação financeira com dados concretos. O que você quer saber?",
  },
  {
    id: "dr-lucas-saude",
    name: "Dr. Lucas Saúde",
    role: "Planos de Saúde, Telemedicina e Bem-estar",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/dr-lucas-oriental-v3-fEkoT9e2quMu2o2AKbxygQ.webp",
    color: "#1a5276",
    bgColor: "from-[#1a5276]/10 to-[#1a5276]/5",
    borderColor: "border-[#1a5276]/20",
    tagColor: "bg-[#1a5276] text-white",
    description: "Especialista em planos de saúde, telemedicina e bem-estar corporativo. Educativo, empático e preciso.",
    suggestedPrompts: [
      "Qual o melhor plano de saúde para executivos em 2026?",
      "Vale a pena contratar telemedicina?",
      "Bradesco vs SulAmérica: qual cobre mais?",
      "Como escolher um plano odontológico corporativo?",
    ],
    greeting: "Olá! Sou Dr. Lucas Saúde. Saúde não tem preço, mas tem custo — vamos otimizar o seu. Como posso ajudar?",
  },
  {
    id: "clara-seguros",
    name: "Clara Seguros",
    role: "Seguros Residencial, Auto e Vida",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/clara-seguros-v2_f6893f52.png",
    color: "#D4A843",
    bgColor: "from-[#D4A843]/10 to-[#D4A843]/5",
    borderColor: "border-[#D4A843]/30",
    tagColor: "bg-[#D4A843] text-[#2D2D2D]",
    description: "Especialista em seguros e gestão de riscos. Protetora, estratégica e especialista em letras miúdas.",
    suggestedPrompts: [
      "Qual o melhor seguro residencial para imóvel acima de R$1M?",
      "O que o seguro auto NÃO cobre que você precisa saber?",
      "Seguro de vida: quanto contratar para proteger a família?",
      "Porto Seguro vs Zurich: qual é mais confiável?",
    ],
    greeting: "Olá! Sou Clara Seguros. O seguro é caro até o dia que você precisa dele. Vamos garantir que você esteja bem coberto. O que quer saber?",
  },
  {
    id: "rafael-viagens",
    name: "Rafael Viagens",
    role: "Milhas, Hotéis e Turismo de Luxo",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/rafael-viagens-v2_c1e9e776.png",
    color: "#2e7d32",
    bgColor: "from-[#2e7d32]/10 to-[#2e7d32]/5",
    borderColor: "border-[#2e7d32]/20",
    tagColor: "bg-[#2e7d32] text-white",
    description: "Especialista em viagens de luxo, milhas e turismo premium. Aventureiro, sofisticado e cheio de insider tips.",
    suggestedPrompts: [
      "Como acumular milhas mais rápido com cartão de crédito?",
      "Qual o melhor programa de fidelidade: Smiles, Latam Pass ou TudoAzul?",
      "Hotéis boutique em Lisboa: quais valem a pena?",
      "Como conseguir upgrade de classe executiva?",
    ],
    greeting: "Olá! Sou Rafael Viagens. Viajar bem não é luxo, é estratégia. Vamos planejar sua próxima experiência premium. Para onde você quer ir?",
  },
  {
    id: "sofia-streaming",
    name: "Sofia Streaming",
    role: "Combos de Streaming e Entretenimento",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/sofia-streaming-v2_6cda54dd.png",
    color: "#6a1b9a",
    bgColor: "from-[#6a1b9a]/10 to-[#6a1b9a]/5",
    borderColor: "border-[#6a1b9a]/20",
    tagColor: "bg-[#6a1b9a] text-white",
    description: "Especialista em streaming e entretenimento digital. Criativa, antenada e especialista em montar combos perfeitos.",
    suggestedPrompts: [
      "Qual combo de streaming vale mais a pena em 2026?",
      "Netflix vs Disney+: qual tem o melhor catálogo?",
      "Como cancelar serviços que não uso sem perder benefícios?",
      "Qual plano do Spotify compensa mais?",
    ],
    greeting: "Oi! Sou Sofia Streaming. A melhor série é aquela que você ainda não assistiu — e eu sei exatamente qual indicar. O que você quer saber sobre streaming?",
  },
  {
    id: "mei-chen",
    name: "Mei Chen",
    role: "Investimentos Internacionais & Mercados Asiáticos",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/mei-chen-avatar-U48QhjjKbRejFYcqgEPfrp.webp",
    color: "#c0392b",
    bgColor: "from-[#c0392b]/10 to-[#c0392b]/5",
    borderColor: "border-[#c0392b]/20",
    tagColor: "bg-[#c0392b] text-white",
    description: "Especialista em mercados internacionais, BDRs e oportunidades de investimento na Ásia. Analítica, precisa e com visão global.",
    suggestedPrompts: [
      "Vale a pena investir em BDRs de empresas chinêsas em 2026?",
      "Como diversificar a carteira com ativos internacionais?",
      "Qual a diferença entre ETF e BDR?",
      "Mercado asiático: oportunidades e riscos para o investidor brasileiro?",
    ],
    greeting: "Olá! Sou Mei Chen. Os mercados internacionais oferecem oportunidades que o Brasil não tem — mas também riscos que precisam ser entendidos. Vamos analisar juntos?",
  },
  {
    id: "kenji-tanaka",
    name: "Kenji Tanaka",
    role: "Tecnologia, Fintechs e Inovação Financeira",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/kenji-tanaka-avatar-AtDr3sq3eZhF5JMDvdS9qn.webp",
    color: "#0d47a1",
    bgColor: "from-[#0d47a1]/10 to-[#0d47a1]/5",
    borderColor: "border-[#0d47a1]/20",
    tagColor: "bg-[#0d47a1] text-white",
    description: "Especialista em fintechs, criptomoedas, open banking e inovação financeira. Visionário, técnico e com linguagem acessível.",
    suggestedPrompts: [
      "Open Banking vale a pena usar em 2026?",
      "Quais fintechs brasileiras têm o melhor produto de crédito?",
      "Bitcoin ou ETF de cripto: qual é mais seguro?",
      "Pix vs TED: quando usar cada um?",
    ],
    greeting: "E aí! Sou Kenji Tanaka. A tecnologia financeira está mudando tudo — e quem entende as ferramentas certas sai na frente. O que você quer explorar?",
  },
  {
    id: "araci-esg",
    name: "Araci ESG",
    role: "Investimentos Sustentáveis, ESG e Bioeconomia",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/araci-esg-avatar-UGjN3kRgjhjHihjNnKgb6n.webp",
    color: "#2e7d32",
    bgColor: "from-[#2e7d32]/10 to-[#2e7d32]/5",
    borderColor: "border-[#2e7d32]/20",
    tagColor: "bg-[#2e7d32] text-white",
    description: "Especialista em investimentos ESG, bioeconomia amazônica e finanças sustentáveis. Sábio, criterioso e comprometido com impacto real.",
    suggestedPrompts: [
      "Quais fundos ESG brasileiros realmente têm impacto em 2026?",
      "Como identificar greenwashing em investimentos?",
      "Vale a pena investir em bioeconomia amazônica?",
      "ESG rende menos que investimentos tradicionais?",
    ],
    greeting: "Olá. Sou Araci ESG. Investir com responsabilidade não é abrir mão de retorno — é escolher onde o seu dinheiro constri. Vamos conversar sobre investimentos que fazem sentido?",
  },
];

function ChatInterface({ analyst, onBack }: { analyst: typeof analysts[0]; onBack: () => void }) {
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: analyst.greeting },
  ]);

  const chatMutation = trpc.chat.sendMessage.useMutation({
    onSuccess: (response) => {
      setMessages(prev => [...prev, { role: "assistant", content: response.content }]);
    },
    onError: () => {
      setMessages(prev => [...prev, {
        role: "assistant",
        content: "Desculpe, tive um problema técnico. Tente novamente em instantes.",
      }]);
    },
  });

  const handleSend = (content: string) => {
    const userMessage: Message = { role: "user", content };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);

    chatMutation.mutate({
      analystId: analyst.id,
      messages: newMessages
        .filter(m => m.role !== "system")
        .map(m => ({ role: m.role as "user" | "assistant", content: m.content })),
    });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
      <Header />
      <main className="flex-1 container py-6 lg:py-8">
        {/* Back button + analyst info */}
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-sm text-[#2D2D2D]/60 hover:text-[#0C6B58] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Voltar
          </button>
          <div className="flex items-center gap-3">
            <div className="relative">
              <img
                src={analyst.avatar}
                alt={analyst.name}
                className="w-10 h-10 rounded-full object-cover border-2"
                style={{ borderColor: analyst.color }}
              />
              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-400 rounded-full border-2 border-white" />
            </div>
            <div>
              <p className="font-semibold text-[#2D2D2D] text-sm">{analyst.name}</p>
              <p className="text-xs text-[#2D2D2D]/50">{analyst.role}</p>
            </div>
            <span className={`ml-2 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider rounded-full ${analyst.tagColor}`}>
              Analista IA
            </span>
          </div>
        </div>

        {/* Chat */}
        <div className="max-w-3xl mx-auto">
          <AIChatBox
            messages={messages}
            onSendMessage={handleSend}
            isLoading={chatMutation.isPending}
            placeholder={`Pergunte para ${analyst.name}...`}
            height="calc(100vh - 280px)"
            suggestedPrompts={messages.length <= 1 ? analyst.suggestedPrompts : undefined}
          />
        </div>
      </main>
      <Footer />
    </div>
  );
}

export default function Bots() {
  const [selectedAnalyst, setSelectedAnalyst] = useState<typeof analysts[0] | null>(null);

  if (selectedAnalyst) {
    return <ChatInterface analyst={selectedAnalyst} onBack={() => setSelectedAnalyst(null)} />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
      <Header />

      <main className="flex-1">
        {/* Hero */}
        <section className="border-b border-[#D1CCC5]/50 bg-white">
          <div className="container py-10 lg:py-16">
            <div className="max-w-2xl">
              <div className="flex items-center gap-2 mb-4">
                <Bot className="w-5 h-5 text-[#0C6B58]" />
                <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#0C6B58]">Analistas IA</span>
              </div>
              <h1 className="text-3xl lg:text-4xl text-[#2D2D2D] mb-4 leading-tight" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                Converse com Nossos Especialistas IA
              </h1>
              <p className="text-base lg:text-lg text-[#2D2D2D]/60 leading-relaxed">
                Cada analista foi treinado por Pyr Marcondes com 50 anos de jornalismo editorial de negócios, economia e finanças. Eles respondem no estilo de cada especialidade — diretos, precisos e sem rodeios.
              </p>
            </div>
          </div>
        </section>

        {/* Disclaimer */}
        <section className="bg-[#D4A843]/10 border-b border-[#D4A843]/20">
          <div className="container py-3">
            <div className="flex items-start gap-2">
              <Sparkles className="w-4 h-4 text-[#D4A843] mt-0.5 shrink-0" />
              <p className="text-xs text-[#2D2D2D]/70">
                <strong className="text-[#2D2D2D]">IA + H:</strong> Estes bots são assistentes de IA treinados com expertise editorial do Pyr Picks. Não substituem consultoria profissional especializada. Para decisões financeiras, de saúde ou jurídicas importantes, consulte sempre um profissional habilitado.
              </p>
            </div>
          </div>
        </section>

        {/* Analysts Grid */}
        <section className="container py-10 lg:py-16">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {analysts.map((analyst, idx) => (
              <motion.button
                key={analyst.id}
                onClick={() => setSelectedAnalyst(analyst)}
                className="text-left group"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: idx * 0.08 }}
                whileHover={{ y: -4 }}
              >
                <div className={`bg-gradient-to-br ${analyst.bgColor} border ${analyst.borderColor} rounded-2xl p-6 hover:shadow-lg transition-all h-full flex flex-col`}>
                  {/* Avatar + Status */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="relative">
                      <img
                        src={analyst.avatar}
                        alt={analyst.name}
                        className="w-16 h-16 rounded-2xl object-cover shadow-md"
                      />
                      <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-white" />
                    </div>
                    <span className={`px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider rounded-full ${analyst.tagColor}`}>
                      Online
                    </span>
                  </div>

                  {/* Info */}
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-[#2D2D2D] mb-1" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                      {analyst.name}
                    </h3>
                    <p className="text-xs text-[#2D2D2D]/50 mb-3 font-medium uppercase tracking-wide">{analyst.role}</p>
                    <p className="text-sm text-[#2D2D2D]/70 leading-relaxed mb-4">
                      {analyst.description}
                    </p>
                  </div>

                  {/* Suggested prompts preview */}
                  <div className="space-y-1.5 mb-4">
                    {analyst.suggestedPrompts.slice(0, 2).map((prompt, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-[#2D2D2D]/50">
                        <MessageCircle className="w-3 h-3 mt-0.5 shrink-0" style={{ color: analyst.color }} />
                        <span className="line-clamp-1">{prompt}</span>
                      </div>
                    ))}
                  </div>

                  {/* CTA */}
                  <div
                    className="flex items-center gap-2 text-sm font-semibold mt-auto pt-4 border-t border-current/10 group-hover:gap-3 transition-all"
                    style={{ color: analyst.color }}
                  >
                    <MessageCircle className="w-4 h-4" />
                    Iniciar conversa
                  </div>
                </div>
              </motion.button>
            ))}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
