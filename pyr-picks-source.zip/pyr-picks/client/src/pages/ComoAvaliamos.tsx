/*
 * Como Avaliamos — Pyr Picks
 * Exemplo concreto do processo de avaliação amostral IA + H
 * Caso: Contas Digitais Premium 2026 (BTG vs Itaú Personnalité vs XP vs Nubank Ultra vs C6 Carbon)
 */
import { useEffect } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  ChevronLeft,
  Database,
  Calculator,
  UserCheck,
  CheckCircle,
  AlertTriangle,
  ExternalLink,
  ArrowRight,
  FlaskConical,
  Globe,
  FileText,
  Star,
} from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const PYR_PHOTO =
  "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/pyr-marcondes-editor_53a6a2c4.jpeg";

const steps = [
  {
    number: "01",
    icon: Database,
    color: "#0C6B58",
    title: "Coleta de Dados Públicos",
    duration: "2–4 horas",
    description:
      "O analista IA varre fontes públicas: sites oficiais dos bancos, regulatórios do Banco Central, comparadores como Reclame Aqui, Procon e Bacen, além de simuladores de rendimento. Nenhum dado é inventado — tudo tem fonte verificável.",
    sources: [
      "Sites oficiais dos bancos (tarifas, regulamentos)",
      "Banco Central — comparador de tarifas bancárias",
      "Reclame Aqui — índice de resolução de reclamações",
      "Procon — histórico de autuações",
      "Simuladores de rendimento (CDI, CDB, LCI)",
    ],
    limitation:
      "Dados de atendimento e experiência do usuário são coletados de fontes secundárias (reviews, fóruns, pesquisas de satisfação públicas), não de testes diretos com contas abertas.",
    aeoNote:
      "Nossa seleção de fontes é orientada por princípios AEO/GEO: priorizamos fontes que os próprios motores de resposta (ChatGPT, Gemini, Perplexity) reconhecem como de alta autoridade — regulatórios oficiais, índices públicos e pesquisas com metodologia explícita. Fontes sem autoria ou sem rastreabilidade são descartadas.",
  },
  {
    number: "02",
    icon: Calculator,
    color: "#D4A843",
    title: "Simulações Amostrais",
    duration: "1–2 horas",
    description:
      "Com os dados coletados, o analista IA executa simulações para um perfil-alvo definido. No caso das contas premium, o perfil foi: executivo com renda de R$20k/mês, patrimônio de R$300k, 3 transações internacionais/mês e uso intenso de crédito.",
    sources: [
      "Simulação de rendimento: R$50k aplicados por 12 meses em cada banco",
      "Cálculo de custo total: anuidade + tarifas + câmbio em 3 viagens/ano",
      "Comparação de limite de crédito: critérios públicos de aprovação",
      "Índice de cobertura de seguros inclusos",
      "Tempo médio de atendimento: dados de pesquisas públicas",
    ],
    limitation:
      "Simulações são baseadas em condições médias e no perfil-alvo descrito. Resultados individuais variam conforme histórico de crédito, relacionamento com o banco e condições de mercado na data da contratação.",
  },
  {
    number: "03",
    icon: FlaskConical,
    color: "#1a5276",
    title: "Matriz de Critérios",
    duration: "1 hora",
    description:
      "Os produtos são pontuados em 6 dimensões, com pesos definidos pela equipe editorial antes da análise (para evitar viés retroativo). Os pesos refletem o que importa para o perfil-alvo.",
    sources: [
      "Rendimento e taxas (peso 30%)",
      "Atendimento e suporte (peso 25%)",
      "Benefícios e seguros inclusos (peso 20%)",
      "Experiência digital (peso 15%)",
      "Reputação e solidez (peso 10%)",
    ],
    limitation: null,
  },
  {
    number: "04",
    icon: UserCheck,
    color: "#6a1b9a",
    title: "Curadoria e Validação Humana",
    duration: "2–3 horas",
    description:
      "Pyr Marcondes revisa todo o material produzido pela IA: confere as fontes, questiona simulações que parecem fora do padrão, consulta especialistas quando necessário e decide o \"One Best Pick\". Nenhuma publicação sai sem essa etapa.",
    sources: [
      "Revisão linha a linha dos dados coletados",
      "Consulta a especialistas do setor quando há dúvida",
      "Verificação de atualidade (dados podem mudar rapidamente)",
      "Decisão final sobre o vencedor — 100% editorial",
      "Redação do texto de análise com linguagem jornalística",
    ],
    limitation: null,
  },
];

const scoreTable = [
  { bank: "Itaú Personnalité", rendimento: 9.2, atendimento: 9.5, beneficios: 9.0, digital: 7.8, reputacao: 9.3, total: 9.1 },
  { bank: "BTG Conta Digital", rendimento: 9.8, atendimento: 8.2, beneficios: 8.5, digital: 9.5, reputacao: 8.8, total: 8.9 },
  { bank: "XP Investimentos", rendimento: 9.5, atendimento: 8.0, beneficios: 8.0, digital: 9.2, reputacao: 8.5, total: 8.7 },
  { bank: "Nubank Ultra", rendimento: 8.8, atendimento: 9.0, beneficios: 7.5, digital: 9.8, reputacao: 9.0, total: 8.6 },
  { bank: "C6 Carbon", rendimento: 8.5, atendimento: 7.8, beneficios: 8.8, digital: 8.5, reputacao: 8.0, total: 8.3 },
];

const sources = [
  { label: "Banco Central — Comparador de Tarifas", url: "https://www.bcb.gov.br/cidadaniafinanceira/comparativos" },
  { label: "Reclame Aqui — Ranking de Bancos 2026", url: "https://www.reclameaqui.com.br/ranking/" },
  { label: "Sites oficiais de cada banco (tarifas e regulamentos)", url: null },
  { label: "Pesquisa Febraban de Tecnologia Bancária 2025", url: null },
  { label: "Procon-SP — Cadastro de Reclamações Fundamentadas", url: "https://www.procon.sp.gov.br" },
];

export default function ComoAvaliamos() {
  useEffect(() => {
    document.title = "Como Avaliamos | Pyr Picks — Metodologia Amostral IA + H";
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
      <Header />
      <main className="flex-1">

        {/* Hero */}
        <section className="bg-white border-b border-[#D1CCC5]/50">
          <div className="container py-10 lg:py-14">
            <Link href="/como-fazemos" className="flex items-center gap-2 text-sm text-[#0C6B58] hover:underline no-underline mb-6">
              <ChevronLeft className="w-4 h-4" />
              Como Fazemos
            </Link>
            <div className="max-w-3xl">
              <div className="flex items-center gap-2 mb-4">
                <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#D4A843] bg-[#D4A843]/10 px-2.5 py-1 rounded-full">
                  Transparência Editorial
                </span>
              </div>
              <h1
                className="text-3xl lg:text-5xl text-[#2D2D2D] mb-4 leading-tight"
                style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
              >
                Como Avaliamos um Produto
              </h1>
              <p className="text-lg text-[#2D2D2D]/60 leading-relaxed">
                Um exemplo real e completo: como o Pyr Picks avaliou as{" "}
                <strong className="text-[#2D2D2D]">contas digitais premium</strong> para executivos em 2026 — do primeiro dado coletado até a escolha do "One Best Pick".
              </p>
            </div>
          </div>
        </section>

        {/* Aviso de metodologia amostral */}
        <section className="bg-[#D4A843]/5 border-b border-[#D4A843]/20">
          <div className="container py-4">
            <div className="flex items-start gap-3 max-w-4xl">
              <AlertTriangle className="w-4 h-4 text-[#D4A843] flex-shrink-0 mt-0.5" />
              <p className="text-sm text-[#2D2D2D]/70">
                <strong className="text-[#2D2D2D]">Avaliações amostrais, não laboratoriais.</strong>{" "}
                O Pyr Picks não abre contas em todos os bancos nem realiza testes com dinheiro real. Nossas análises são baseadas em dados públicos, simulações e fontes verificáveis, com curadoria e validação humana de Pyr Marcondes antes de qualquer publicação.{" "}
                <Link href="/termos-de-uso" className="text-[#0C6B58] hover:underline no-underline font-medium">
                  Ver Termos de Uso
                </Link>
              </p>
            </div>
          </div>
        </section>

        {/* O caso: Contas Digitais Premium */}
        <section className="container py-10 lg:py-14">
          <div className="max-w-4xl">
            <div className="flex items-center gap-3 mb-6">
              <span className="w-6 h-[2px] bg-[#0C6B58]" />
              <h2
                className="text-xl lg:text-2xl text-[#2D2D2D]"
                style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
              >
                O Caso: Contas Digitais Premium 2026
              </h2>
            </div>

            <div className="bg-white rounded-xl border border-[#D1CCC5]/30 p-6 lg:p-8 mb-10">
              <div className="grid md:grid-cols-3 gap-6 mb-6">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-[#2D2D2D]/40 mb-1">Analista IA</p>
                  <p className="text-sm font-semibold text-[#2D2D2D]">Ana Finanças</p>
                </div>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-[#2D2D2D]/40 mb-1">Perfil-alvo</p>
                  <p className="text-sm font-semibold text-[#2D2D2D]">Executivo, renda R$20k+/mês</p>
                </div>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-[#2D2D2D]/40 mb-1">Produtos avaliados</p>
                  <p className="text-sm font-semibold text-[#2D2D2D]">5 contas digitais premium</p>
                </div>
              </div>
              <p className="text-sm text-[#2D2D2D]/60 leading-relaxed">
                A pergunta editorial era: <em>"Qual conta digital premium oferece o melhor custo-benefício real para um executivo com renda acima de R$20k/mês, considerando rendimento, atendimento, benefícios e experiência digital?"</em>
              </p>
            </div>

            {/* Steps */}
            <div className="space-y-8">
              {steps.map((step, i) => (
                <motion.div
                  key={step.number}
                  className="bg-white rounded-xl border border-[#D1CCC5]/30 overflow-hidden"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.1 }}
                >
                  <div className="flex items-center gap-4 p-6 border-b border-[#D1CCC5]/30">
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: `${step.color}15` }}
                    >
                      <step.icon className="w-5 h-5" style={{ color: step.color }} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <span className="text-xs font-bold text-[#2D2D2D]/30 tracking-wider">{step.number}</span>
                        <h3 className="text-base lg:text-lg font-semibold text-[#2D2D2D]">{step.title}</h3>
                      </div>
                    </div>
                    <span className="text-xs text-[#2D2D2D]/40 bg-[#F8F6F3] px-2.5 py-1 rounded-full flex-shrink-0">
                      {step.duration}
                    </span>
                  </div>
                  <div className="p-6">
                    <p className="text-sm text-[#2D2D2D]/70 leading-relaxed mb-4">{step.description}</p>
                    <div className="space-y-1.5 mb-4">
                      {step.sources.map((src) => (
                        <div key={src} className="flex items-start gap-2 text-sm text-[#2D2D2D]/60">
                          <CheckCircle className="w-3.5 h-3.5 text-[#0C6B58] flex-shrink-0 mt-0.5" />
                          <span>{src}</span>
                        </div>
                      ))}
                    </div>
                    {step.limitation && (
                      <div className="flex items-start gap-2 bg-[#D4A843]/5 border border-[#D4A843]/20 rounded-lg p-3 mb-3">
                        <AlertTriangle className="w-3.5 h-3.5 text-[#D4A843] flex-shrink-0 mt-0.5" />
                        <p className="text-xs text-[#2D2D2D]/60 leading-relaxed">
                          <strong className="text-[#2D2D2D]">Limitação desta etapa:</strong> {step.limitation}
                        </p>
                      </div>
                    )}
                    {(step as any).aeoNote && (
                      <div className="flex items-start gap-2 bg-[#0C6B58]/5 border border-[#0C6B58]/15 rounded-lg p-3">
                        <span className="flex-shrink-0 mt-0.5 text-[10px] font-black text-[#0C6B58] tracking-wider">AEO</span>
                        <p className="text-xs text-[#2D2D2D]/60 leading-relaxed">
                          {(step as any).aeoNote}
                        </p>
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Tabela de pontuações */}
        <section className="bg-white border-t border-[#D1CCC5]/50">
          <div className="container py-10 lg:py-14">
            <div className="max-w-4xl">
              <div className="flex items-center gap-3 mb-6">
                <span className="w-6 h-[2px] bg-[#D4A843]" />
                <h2
                  className="text-xl lg:text-2xl text-[#2D2D2D]"
                  style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
                >
                  Resultado: Matriz de Pontuação
                </h2>
              </div>
              <p className="text-sm text-[#2D2D2D]/60 mb-6">
                Pontuação de 0 a 10 em cada critério, ponderada pelos pesos editoriais. Nota final calculada antes da curadoria humana — Pyr pode ajustar a escolha final com base em fatores qualitativos não capturados pelos dados.
              </p>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-[#D1CCC5]/50">
                      <th className="text-left py-3 pr-4 text-xs font-semibold uppercase tracking-wider text-[#2D2D2D]/40">Banco</th>
                      <th className="text-center py-3 px-3 text-xs font-semibold uppercase tracking-wider text-[#2D2D2D]/40">Rendimento<br/><span className="font-normal normal-case">(30%)</span></th>
                      <th className="text-center py-3 px-3 text-xs font-semibold uppercase tracking-wider text-[#2D2D2D]/40">Atendimento<br/><span className="font-normal normal-case">(25%)</span></th>
                      <th className="text-center py-3 px-3 text-xs font-semibold uppercase tracking-wider text-[#2D2D2D]/40">Benefícios<br/><span className="font-normal normal-case">(20%)</span></th>
                      <th className="text-center py-3 px-3 text-xs font-semibold uppercase tracking-wider text-[#2D2D2D]/40">Digital<br/><span className="font-normal normal-case">(15%)</span></th>
                      <th className="text-center py-3 px-3 text-xs font-semibold uppercase tracking-wider text-[#2D2D2D]/40">Reputação<br/><span className="font-normal normal-case">(10%)</span></th>
                      <th className="text-center py-3 pl-3 text-xs font-semibold uppercase tracking-wider text-[#0C6B58]">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {scoreTable.map((row, i) => (
                      <tr
                        key={row.bank}
                        className={`border-b border-[#D1CCC5]/30 ${i === 0 ? "bg-[#0C6B58]/3" : ""}`}
                      >
                        <td className="py-3 pr-4">
                          <div className="flex items-center gap-2">
                            {i === 0 && <Star className="w-3.5 h-3.5 text-[#D4A843] flex-shrink-0" />}
                            <span className={`font-medium ${i === 0 ? "text-[#0C6B58]" : "text-[#2D2D2D]"}`}>
                              {row.bank}
                            </span>
                            {i === 0 && (
                              <span className="text-[9px] font-bold uppercase tracking-wider text-[#D4A843] bg-[#D4A843]/10 px-1.5 py-0.5 rounded-full">
                                One Best Pick
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="text-center py-3 px-3 text-[#2D2D2D]/70">{row.rendimento.toFixed(1)}</td>
                        <td className="text-center py-3 px-3 text-[#2D2D2D]/70">{row.atendimento.toFixed(1)}</td>
                        <td className="text-center py-3 px-3 text-[#2D2D2D]/70">{row.beneficios.toFixed(1)}</td>
                        <td className="text-center py-3 px-3 text-[#2D2D2D]/70">{row.digital.toFixed(1)}</td>
                        <td className="text-center py-3 px-3 text-[#2D2D2D]/70">{row.reputacao.toFixed(1)}</td>
                        <td className={`text-center py-3 pl-3 font-bold ${i === 0 ? "text-[#0C6B58]" : "text-[#2D2D2D]"}`}>
                          {row.total.toFixed(1)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="text-xs text-[#2D2D2D]/40 mt-3">
                * Pontuações baseadas em dados coletados em março de 2026. Podem variar com mudanças nos produtos.
              </p>
            </div>
          </div>
        </section>

        {/* Decisão final de Pyr */}
        <section className="bg-[#F8F6F3] border-t border-[#D1CCC5]/50">
          <div className="container py-10 lg:py-14">
            <div className="max-w-4xl">
              <div className="flex items-center gap-3 mb-6">
                <span className="w-6 h-[2px] bg-[#D4A843]" />
                <h2
                  className="text-xl lg:text-2xl text-[#2D2D2D]"
                  style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
                >
                  A Decisão Final de Pyr
                </h2>
              </div>

              <div className="bg-white rounded-xl border border-[#D1CCC5]/30 p-6 lg:p-8">
                <div className="flex items-start gap-4 mb-6">
                  <img
                    src={PYR_PHOTO}
                    alt="Pyr Marcondes"
                    className="w-14 h-14 rounded-full object-cover object-top border-2 border-[#D4A843] flex-shrink-0"
                  />
                  <div>
                    <p className="font-semibold text-[#2D2D2D]">Pyr Marcondes</p>
                    <p className="text-xs text-[#D4A843] font-semibold uppercase tracking-wide">Editor in Chief</p>
                    <p className="text-xs text-[#2D2D2D]/40 mt-0.5">50 anos de jornalismo editorial de negócios, economia e finanças</p>
                  </div>
                </div>
                <blockquote className="text-sm text-[#2D2D2D]/70 leading-relaxed border-l-2 border-[#D4A843] pl-4 mb-6 italic">
                  "A matriz apontou o Itaú Personnalité como líder, e eu concordo — mas por razões que os dados sozinhos não capturam completamente. O Personnalité tem 30 anos de relacionamento com o segmento executivo. Isso se traduz em crédito mais fácil, gerentes que conhecem o cliente de verdade e uma rede de agências físicas que ainda importa para quem movimenta patrimônio relevante. O BTG tem rendimento superior, mas é uma plataforma de investimentos que virou banco — o atendimento para necessidades do dia a dia ainda é inferior. Para o perfil descrito nesta análise, o Personnalité é a escolha certa."
                </blockquote>
                <div className="flex items-center gap-3">
                  <Link
                    href="/review/melhor-conta-digital-premium-2026"
                    className="inline-flex items-center gap-2 text-sm font-semibold text-[#0C6B58] hover:underline no-underline"
                  >
                    Ver o review completo
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Fontes */}
        <section className="bg-white border-t border-[#D1CCC5]/50">
          <div className="container py-10 lg:py-14">
            <div className="max-w-4xl">
              <div className="flex items-center gap-3 mb-6">
                <span className="w-6 h-[2px] bg-[#2D2D2D]/20" />
                <h2
                  className="text-lg text-[#2D2D2D]"
                  style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
                >
                  Fontes Utilizadas nesta Análise
                </h2>
              </div>
              <div className="space-y-2">
                {sources.map((src) => (
                  <div key={src.label} className="flex items-center gap-2 text-sm text-[#2D2D2D]/60">
                    {src.url ? (
                      <>
                        <Globe className="w-3.5 h-3.5 text-[#0C6B58] flex-shrink-0" />
                        <a
                          href={src.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[#0C6B58] hover:underline"
                        >
                          {src.label}
                          <ExternalLink className="inline w-3 h-3 ml-1" />
                        </a>
                      </>
                    ) : (
                      <>
                        <FileText className="w-3.5 h-3.5 text-[#2D2D2D]/30 flex-shrink-0" />
                        <span>{src.label}</span>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* CTA final */}
        <section className="bg-gradient-to-br from-[#0C6B58]/5 to-[#D4A843]/5 border-t border-[#D1CCC5]/50">
          <div className="container py-10 lg:py-14 text-center">
            <h2
              className="text-2xl lg:text-3xl text-[#2D2D2D] mb-3"
              style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
            >
              Quer ver mais análises?
            </h2>
            <p className="text-sm text-[#2D2D2D]/60 mb-6 max-w-lg mx-auto">
              Aplicamos o mesmo processo rigoroso em todas as categorias — saúde, seguros, viagens, streaming e mais.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Link
                href="/"
                className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#0C6B58] text-white text-sm font-semibold rounded-full hover:bg-[#0C6B58]/90 transition-colors no-underline"
              >
                Ver todos os reviews
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                href="/como-fazemos"
                className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-white border border-[#D1CCC5] text-[#2D2D2D] text-sm font-semibold rounded-full hover:border-[#0C6B58]/30 transition-colors no-underline"
              >
                Metodologia completa
              </Link>
            </div>
          </div>
        </section>

      </main>
      <Footer />
    </div>
  );
}
