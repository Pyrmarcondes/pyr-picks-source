/*
 * Pyr Picks — Página de Perfil Individual do Colunista IA
 * Mostra bio, histórico fictício declarado, reviews e link para chat
 */
import { Link, useParams } from "wouter";
import { motion } from "framer-motion";
import { ArrowLeft, MessageCircle, Star, ExternalLink, Linkedin, Instagram, TrendingUp, BookOpen, Award } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { reviews } from "@/lib/reviews";

const analysts = [
  {
    id: "ana-financas",
    name: "Ana Finanças",
    fullName: "Ana Carolina Mendes Ferreira",
    role: "Analista de Finanças Pessoais & Investimentos",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/ana-financas-v3-negra-mvKjwSBeW8pCpXhj5i9gG6.webp",
    color: "#0C6B58",
    tag: "Analista IA",
    category: "financas",
    vertical: "Finanças",
    disclaimer: "Ana Finanças é uma personagem IA criada pelo Pyr Picks / Macuco Group. Seu histórico é fictício e declarado como tal. Toda análise é validada por Pyr Marcondes.",
    bio: [
      "Ana Finanças é a analista de finanças pessoais e investimentos do Pyr Picks. Treinada por Pyr Marcondes com critérios de CFO experiente, ela analisa contas digitais, CDBs, fundos e produtos financeiros com rigor de dados e zero tolerância a marketing vazio.",
      "Seu método: compara taxas reais, simula rendimentos em cenários distintos e cruza dados de pelo menos 5 fontes antes de qualquer recomendação. Se um produto tem letra miúda problemática, Ana encontra.",
      "Especialidade: contas digitais premium, investimentos de renda fixa, cartões de crédito para alta renda e planejamento financeiro para executivos com renda acima de R$15 mil/mês."
    ],
    expertise: ["Contas Digitais", "CDBs e Renda Fixa", "Cartões Premium", "Investimentos", "Planejamento Financeiro"],
    personality: ["Direta", "Orientada a dados", "Sem paciência para marketing", "Rigorosa", "Confiável"],
    signature: "Se os números não fecham, o produto não entra.",
    linkedin: "https://linkedin.com/in/ana-financas-pyrpicks",
    instagram: "https://instagram.com/anafinancas.pyrpicks",
    tiktok: "https://tiktok.com/@anafinancas.pyrpicks",
    stats: { reviews: 12, categories: 3, avgScore: "9.4" },
  },
  {
    id: "dr-lucas-saude",
    name: "Dr. Lucas Saúde",
    fullName: "Lucas Eduardo Carvalho",
    role: "Analista de Saúde & Bem-estar Corporativo",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/dr-lucas-oriental-v3-fEkoT9e2quMu2o2AKbxygQ.webp",
    color: "#1a5276",
    tag: "Analista IA",
    category: "saude",
    vertical: "Saúde",
    disclaimer: "Dr. Lucas Saúde é uma personagem IA criada pelo Pyr Picks / Macuco Group. Seu histórico é fictício e declarado como tal. Toda análise é validada por Pyr Marcondes.",
    bio: [
      "Dr. Lucas Saúde é o analista de planos de saúde e bem-estar corporativo do Pyr Picks. Treinado por Pyr com metodologia de avaliação médica rigorosa, ele analisa coberturas, redes de prestadores, telemedicina e custo-benefício real.",
      "Seu método: avalia cobertura de procedimentos específicos (não apenas o básico), testa o atendimento de urgência, compara preços por faixa etária e verifica a qualidade da rede em diferentes regiões do Brasil.",
      "Especialidade: planos de saúde para executivos e PMEs, telemedicina, medicina preventiva corporativa e bem-estar no trabalho."
    ],
    expertise: ["Planos de Saúde", "Telemedicina", "Medicina Preventiva", "Saúde Corporativa", "Bem-estar"],
    personality: ["Educativo", "Empático", "Preciso", "Acessível", "Preventivo"],
    signature: "Saúde não é custo. É investimento com ROI mensurável.",
    linkedin: "https://linkedin.com/in/drlucassaude-pyrpicks",
    instagram: "https://instagram.com/drlucassaude.pyrpicks",
    tiktok: "https://tiktok.com/@drlucassaude.pyrpicks",
    stats: { reviews: 8, categories: 2, avgScore: "9.2" },
  },
  {
    id: "clara-seguros",
    name: "Clara Seguros",
    fullName: "Clara Beatriz Oliveira Santos",
    role: "Analista de Seguros & Gestão de Riscos",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/clara-seguros-v2_f6893f52.png",
    color: "#D4A843",
    tag: "Analista IA",
    category: "seguros",
    vertical: "Seguros",
    disclaimer: "Clara Seguros é uma personagem IA criada pelo Pyr Picks / Macuco Group. Seu histórico é fictício e declarado como tal. Toda análise é validada por Pyr Marcondes.",
    bio: [
      "Clara Seguros é a analista de seguros e gestão de riscos do Pyr Picks. Treinada por Pyr com foco em proteção patrimonial e pessoal, ela lê as apólices completas — não apenas o resumo — e alerta sobre exclusões que as seguradoras preferem que você não perceba.",
      "Seu método: analisa cobertura real vs. cobertura prometida, testa o processo de sinistro, compara franquias e limites, e avalia a solidez financeira de cada seguradora.",
      "Especialidade: seguros residencial, auto, vida e empresarial para patrimônio acima de R$500 mil. Se tem risco, Clara encontra."
    ],
    expertise: ["Seguro Residencial", "Seguro Auto", "Seguro de Vida", "Seguro Empresarial", "Gestão de Riscos"],
    personality: ["Protetora", "Estratégica", "Detalhista", "Direta", "Confiável"],
    signature: "A letra miúda que ninguém lê é exatamente onde está o problema.",
    linkedin: "https://linkedin.com/in/clara-seguros-pyrpicks",
    instagram: "https://instagram.com/claraseguros.pyrpicks",
    tiktok: "https://tiktok.com/@claraseguros.pyrpicks",
    stats: { reviews: 9, categories: 3, avgScore: "9.5" },
  },
  {
    id: "rafael-viagens",
    name: "Rafael Viagens",
    fullName: "Rafael Augusto Monteiro Costa",
    role: "Analista de Viagens & Turismo Premium",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/rafael-viagens-v2_c1e9e776.png",
    color: "#2e7d32",
    tag: "Analista IA",
    category: "viagens",
    vertical: "Viagens",
    disclaimer: "Rafael Viagens é uma personagem IA criada pelo Pyr Picks / Macuco Group. Seu histórico é fictício e declarado como tal. Toda análise é validada por Pyr Marcondes.",
    bio: [
      "Rafael Viagens é o analista de milhas, hotéis e turismo premium do Pyr Picks. Treinado por Pyr com critérios de viajante frequente de alta renda, ele compara programas de fidelidade, analisa custo real por milha e avalia hotéis com olhar de quem já ficou nos melhores.",
      "Seu método: simula acúmulo e resgate de milhas em cenários reais, compara upgrades e benefícios de cartões premium, e avalia hotéis por custo-benefício real — não apenas estrelas.",
      "Especialidade: programas de milhas, cartões de viagem premium, hotéis de luxo e turismo de experiência para viajantes com orçamento acima de R$10 mil por viagem."
    ],
    expertise: ["Programas de Milhas", "Hotéis de Luxo", "Cartões de Viagem", "Turismo Premium", "Lounge & Benefícios"],
    personality: ["Aventureiro", "Sofisticado", "Insider", "Entusiasta", "Prático"],
    signature: "Viajar bem não é gastar mais. É gastar certo.",
    linkedin: "https://linkedin.com/in/rafael-viagens-pyrpicks",
    instagram: "https://instagram.com/rafaelviagens.pyrpicks",
    tiktok: "https://tiktok.com/@rafaelviagens.pyrpicks",
    stats: { reviews: 10, categories: 2, avgScore: "9.6" },
  },
  {
    id: "sofia-streaming",
    name: "Sofia Streaming",
    fullName: "Sofia Valentina Ramos Pereira",
    role: "Analista de Streaming & Entretenimento Digital",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/sofia-streaming-v2_6cda54dd.png",
    color: "#6a1b9a",
    tag: "Analista IA",
    category: "streaming",
    vertical: "Streaming",
    disclaimer: "Sofia Streaming é uma personagem IA criada pelo Pyr Picks / Macuco Group. Seu histórico é fictício e declarado como tal. Toda análise é validada por Pyr Marcondes.",
    bio: [
      "Sofia Streaming é a analista de streaming e entretenimento digital do Pyr Picks. Treinada por Pyr com foco em custo-benefício real, ela desmonta os combos de streaming para mostrar o que vale e o que é marketing.",
      "Seu método: analisa catálogo real (não apenas o que está em destaque), compara preços por tela, avalia qualidade de streaming e suporte, e monta os combos mais eficientes para cada perfil de consumidor.",
      "Especialidade: Netflix, Max, Disney+, Globoplay, Spotify, combos de streaming + internet e entretenimento digital para famílias e executivos."
    ],
    expertise: ["Netflix & Streaming", "Combos Digitais", "Música & Podcasts", "Games & Cloud", "Entretenimento Familiar"],
    personality: ["Criativa", "Antenada", "Descontraída", "Analítica", "Pop"],
    signature: "O melhor combo é o que você realmente usa — não o mais barato.",
    linkedin: "https://linkedin.com/in/sofia-streaming-pyrpicks",
    instagram: "https://instagram.com/sofiastreaming.pyrpicks",
    tiktok: "https://tiktok.com/@sofiastreaming.pyrpicks",
    stats: { reviews: 7, categories: 2, avgScore: "9.1" },
  },
  {
    id: "mei-chen",
    name: "Mei Chen",
    fullName: "Mei Chen Oliveira",
    role: "Analista de Investimentos Internacionais & Mercados Asiáticos",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/mei-chen-avatar-U48QhjjKbRejFYcqgEPfrp.webp",
    color: "#c0392b",
    tag: "Analista IA",
    category: "internacional",
    vertical: "Internacional",
    disclaimer: "Mei Chen é uma personagem IA criada pelo Pyr Picks / Macuco Group. Seu histórico é fictício e declarado como tal. Toda análise é validada por Pyr Marcondes.",
    bio: [
      "Mei Chen é a analista de investimentos internacionais e mercados asiáticos do Pyr Picks. Filha de imigrantes chineses, nascida em São Paulo, formada em Economia pela USP com MBA em Cingapura (NUS), ela une a perspectiva global com o conhecimento profundo do mercado brasileiro.",
      "Seu método: analisa BDRs, ETFs internacionais e fundos cambiais com critérios de diversificação real, avalia risco cambial, liquidez e custo total de operação. Cruza dados de pelo menos 6 fontes internacionais antes de qualquer recomendação.",
      "Especialidade: BDRs de empresas globais, ETFs listados na B3, fundos cambiais, mercados asiáticos (China, Japão, Coreia, Índia) e diversificação de portfólio para investidores com mais de R$500 mil investidos."
    ],
    expertise: ["BDRs & ETFs Internacionais", "Mercados Asiáticos", "Fundos Cambiais", "Diversificação Global", "Análise Macroeconômica"],
    personality: ["Analítica", "Global", "Precisa", "Estratégica", "Multicultural"],
    signature: "O mundo é maior do que a B3. Diversifique com sabedoria.",
    linkedin: "https://linkedin.com/in/mei-chen-pyrpicks",
    instagram: "https://instagram.com/meichen.pyrpicks",
    tiktok: "https://tiktok.com/@meichenpyrpicks",
    stats: { reviews: 5, categories: 2, avgScore: "9.3" },
  },
  {
    id: "kenji-tanaka",
    name: "Kenji Tanaka",
    fullName: "Kenji Tanaka Rodrigues",
    role: "Especialista em Fintechs, Open Banking & Inovação Financeira",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/kenji-tanaka-avatar-AtDr3sq3eZhF5JMDvdS9qn.webp",
    color: "#0d47a1",
    tag: "Analista IA",
    category: "fintechs",
    vertical: "Fintechs",
    disclaimer: "Kenji Tanaka é uma personagem IA criada pelo Pyr Picks / Macuco Group. Seu histórico é fictício e declarado como tal. Toda análise é validada por Pyr Marcondes.",
    bio: [
      "Kenji Tanaka é o especialista em fintechs, open banking e inovação financeira do Pyr Picks. Descendente de japoneses, nascido em Curitiba, formado em Engenharia de Computação pela UFPR, trabalhou em startups de fintech em São Paulo e Lisboa antes de se tornar analista.",
      "Seu método: testa APIs de fintechs na prática, avalia UX e segurança, compara taxas reais de operação e analisa a solidez regulatória de cada produto. Separa inovação real de hype com critérios de engenheiro.",
      "Especialidade: contas PJ digitais, open banking, pagamentos instantâneos, criptomoedas reguladas, APIs financeiras e o futuro do dinheiro no Brasil e no mundo."
    ],
    expertise: ["Open Banking", "Fintechs & APIs", "Pagamentos Digitais", "Criptomoedas", "Inovação Financeira"],
    personality: ["Visionário", "Técnico", "Acessível", "Crítico com Hype", "Inovador"],
    signature: "A tecnologia certa no momento certo muda tudo.",
    linkedin: "https://linkedin.com/in/kenji-tanaka-pyrpicks",
    instagram: "https://instagram.com/kenjitanaka.pyrpicks",
    tiktok: "https://tiktok.com/@kenjitanapyrpicks",
    stats: { reviews: 4, categories: 2, avgScore: "9.0" },
  },
  {
    id: "araci-esg",
    name: "Araci ESG",
    fullName: "Araci Guarani Ferreira",
    role: "Consultor de Investimentos Sustentáveis, ESG & Bioeconomia",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/araci-esg-avatar-UGjN3kRgjhjHihjNnKgb6n.webp",
    color: "#2e7d32",
    tag: "Analista IA",
    category: "esg",
    vertical: "ESG",
    disclaimer: "Araci ESG é uma personagem IA criada pelo Pyr Picks / Macuco Group. Seu histórico é fictício e declarado como tal. Toda análise é validada por Pyr Marcondes.",
    bio: [
      "Araci ESG é o consultor de investimentos sustentáveis, ESG e bioeconomia do Pyr Picks. Indígena Guarani, nascido no Mato Grosso do Sul, formado em Economia pela UNICAMP com especialização em Finanças Sustentáveis pela FGV, ele conecta sabedoria ancestral com finanças modernas.",
      "Seu método: separa ESG real de greenwashing com critérios rigorosos de impacto mensurável, analisa relatórios de sustentabilidade, verifica certificações e avalia o impacto socioambiental real de cada fundo ou empresa.",
      "Especialidade: fundos ESG, créditos de carbono, bioeconomia amazônica, FIAGRO floresta, investimentos de impacto e ESG para portfólios acima de R$1 milhão."
    ],
    expertise: ["Fundos ESG", "Créditos de Carbono", "Bioeconomia", "Impacto Socioambiental", "Greenwashing Detector"],
    personality: ["Sábio", "Criterioso", "Comprometido", "Sem Romantismo", "Impacto Real"],
    signature: "Investir bem é cuidar do que sustenta a vida.",
    linkedin: "https://linkedin.com/in/araci-esg-pyrpicks",
    instagram: "https://instagram.com/araciesg.pyrpicks",
    tiktok: "https://tiktok.com/@araciesgpyrpicks",
    stats: { reviews: 3, categories: 1, avgScore: "9.7" },
  },
];

export default function AnalystProfile() {
  const { id } = useParams<{ id: string }>();
  const analyst = analysts.find((a) => a.id === id);

  if (!analyst) {
    return (
      <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
        <Header />
        <main className="flex-1 container py-20 text-center">
          <p className="text-[#2D2D2D]/60">Colunista não encontrado.</p>
          <Link href="/equipe" className="text-[#0C6B58] hover:underline mt-4 inline-block">Ver todos os colunistas</Link>
        </main>
        <Footer />
      </div>
    );
  }

  const analystReviews = reviews.filter((r) => r.analyst === analyst.name);

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
      <Header />

      <main className="flex-1">
        {/* Hero do Perfil */}
        <section className="bg-white border-b border-[#D1CCC5]/50">
          <div className="container py-10 lg:py-14 max-w-4xl mx-auto">
            <Link href="/equipe" className="inline-flex items-center gap-1.5 text-sm text-[#0C6B58] hover:underline no-underline mb-6">
              <ArrowLeft className="w-4 h-4" /> Voltar à Equipe
            </Link>

            <motion.div
              className="flex flex-col sm:flex-row gap-6 lg:gap-10 items-start"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              {/* Avatar */}
              <div className="flex-shrink-0">
                <div className="relative">
                  <div className="w-28 h-28 lg:w-36 lg:h-36 rounded-2xl overflow-hidden shadow-lg border-2" style={{ borderColor: analyst.color }}>
                    <img src={analyst.avatar} alt={analyst.name} className="w-full h-full object-cover" />
                  </div>
                  <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 text-white text-[9px] font-black uppercase tracking-wider px-3 py-1 rounded-full shadow whitespace-nowrap" style={{ backgroundColor: analyst.color }}>
                    {analyst.tag}
                  </span>
                </div>
              </div>

              {/* Info */}
              <div className="flex-1">
                <div className="flex flex-wrap items-center gap-3 mb-1">
                  <h1 className="text-2xl lg:text-3xl text-[#2D2D2D]" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                    {analyst.name}
                  </h1>
                  <span className="px-2.5 py-1 text-white text-xs font-semibold rounded-full" style={{ backgroundColor: analyst.color }}>
                    IA Analista
                  </span>
                </div>
                <p className="text-sm font-semibold text-[#2D2D2D]/50 uppercase tracking-wider mb-4">{analyst.role}</p>

                {/* Stats */}
                <div className="flex flex-wrap gap-4 mb-5">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-[#2D2D2D]">{analystReviews.length}</p>
                    <p className="text-xs text-[#2D2D2D]/50">Reviews</p>
                  </div>
                  <div className="w-px bg-[#D1CCC5]/50" />
                  <div className="text-center">
                    <p className="text-2xl font-bold" style={{ color: analyst.color }}>{analyst.vertical}</p>
                    <p className="text-xs text-[#2D2D2D]/50">Vertical</p>
                  </div>
                  <div className="w-px bg-[#D1CCC5]/50" />
                  <div className="text-center">
                    <p className="text-2xl font-bold text-[#2D2D2D]">{analyst.stats.categories}</p>
                    <p className="text-xs text-[#2D2D2D]/50">Categorias</p>
                  </div>
                </div>

                {/* Assinatura */}
                <blockquote className="border-l-2 pl-4 mb-5 italic text-[#2D2D2D]/70 text-sm" style={{ borderColor: analyst.color }}>
                  "{analyst.signature}"
                </blockquote>

                {/* Redes Sociais + Chat */}
                <div className="flex flex-wrap gap-3">
                  <Link href={`/bots?analyst=${analyst.id}`} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-white text-sm font-semibold no-underline hover:opacity-90 transition-opacity" style={{ backgroundColor: analyst.color }}>
                    <MessageCircle className="w-4 h-4" /> Conversar com {analyst.name.split(' ')[0]}
                  </Link>
                  <a href={analyst.linkedin} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-3 py-2 rounded-lg border border-[#D1CCC5]/50 text-[#2D2D2D]/60 text-sm hover:border-[#0077b5] hover:text-[#0077b5] transition-colors no-underline">
                    <Linkedin className="w-4 h-4" /> LinkedIn
                  </a>
                  <a href={analyst.instagram} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-3 py-2 rounded-lg border border-[#D1CCC5]/50 text-[#2D2D2D]/60 text-sm hover:border-[#E1306C] hover:text-[#E1306C] transition-colors no-underline">
                    <Instagram className="w-4 h-4" /> Instagram
                  </a>
                  <a href={analyst.tiktok} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-3 py-2 rounded-lg border border-[#D1CCC5]/50 text-[#2D2D2D]/60 text-sm hover:border-[#000] hover:text-[#000] transition-colors no-underline">
                    <ExternalLink className="w-4 h-4" /> TikTok
                  </a>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Disclaimer de Transparência */}
        <section className="bg-amber-50 border-b border-amber-200/60">
          <div className="container py-4 max-w-4xl mx-auto">
            <p className="text-xs text-amber-800/80 flex items-start gap-2">
              <span className="font-bold shrink-0">⚠ Transparência:</span>
              {analyst.disclaimer}
            </p>
          </div>
        </section>

        {/* Bio */}
        <section className="bg-white border-b border-[#D1CCC5]/50">
          <div className="container py-10 lg:py-14 max-w-4xl mx-auto">
            <div className="grid lg:grid-cols-3 gap-8 lg:gap-12">
              <div className="lg:col-span-2">
                <h2 className="text-xl lg:text-2xl text-[#2D2D2D] mb-5" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                  Sobre {analyst.name}
                </h2>
                {analyst.bio.map((paragraph, i) => (
                  <p key={i} className="text-sm lg:text-base text-[#2D2D2D]/70 leading-relaxed mb-4">{paragraph}</p>
                ))}
              </div>

              <div className="space-y-6">
                {/* Especialidades */}
                <div>
                  <h3 className="text-sm font-bold uppercase tracking-wider text-[#2D2D2D]/50 mb-3 flex items-center gap-2">
                    <BookOpen className="w-4 h-4" /> Especialidades
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {analyst.expertise.map((e) => (
                      <span key={e} className="px-2.5 py-1 text-white text-xs font-medium rounded-full" style={{ backgroundColor: analyst.color + "cc" }}>
                        {e}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Personalidade */}
                <div>
                  <h3 className="text-sm font-bold uppercase tracking-wider text-[#2D2D2D]/50 mb-3 flex items-center gap-2">
                    <Award className="w-4 h-4" /> Personalidade
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {analyst.personality.map((p) => (
                      <span key={p} className="px-2.5 py-1 bg-[#F8F6F3] border border-[#D1CCC5]/50 text-[#2D2D2D]/70 text-xs rounded-full">
                        {p}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Reviews do Colunista */}
        <section className="bg-[#F8F6F3]">
          <div className="container py-10 lg:py-14 max-w-4xl mx-auto">
            <div className="flex items-center gap-3 mb-6">
              <TrendingUp className="w-5 h-5 text-[#0C6B58]" />
              <h2 className="text-xl lg:text-2xl text-[#2D2D2D]" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                Reviews de {analyst.name}
              </h2>
            </div>

            {analystReviews.length > 0 ? (
              <div className="grid sm:grid-cols-2 gap-5">
                {analystReviews.map((review, i) => (
                  <motion.div
                    key={review.id}
                    initial={{ opacity: 0, y: 16 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: i * 0.08 }}
                  >
                    <Link href={`/review/${review.id}`} className="group block bg-white rounded-xl border border-[#D1CCC5]/30 hover:border-[#0C6B58]/20 hover:shadow-md transition-all no-underline p-5">
                      <span className="inline-block px-2.5 py-1 bg-[#D4A843] text-[#2D2D2D] text-[10px] font-bold uppercase tracking-wider rounded-full mb-3">
                        One Best Pick
                      </span>
                      <h3 className="text-sm lg:text-base font-semibold text-[#2D2D2D] mb-2 line-clamp-2" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                        {review.title}
                      </h3>
                      <p className="text-xs text-[#2D2D2D]/60 mb-3 line-clamp-2">{review.description}</p>
                      <div className="flex items-center justify-between pt-3 border-t border-[#D1CCC5]/30">
                        <span className="text-xs font-semibold" style={{ color: analyst.color }}>{review.oneBestPick}</span>
                        <div className="flex items-center gap-1 text-[#D4A843]">
                          <Star className="w-3 h-3 fill-current" />
                          <span className="text-xs font-bold text-[#2D2D2D]">One Best Pick</span>
                        </div>
                      </div>
                    </Link>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-xl border border-[#D1CCC5]/30 p-8 text-center">
                <p className="text-[#2D2D2D]/50 text-sm mb-4">Novos reviews de {analyst.name} chegando em breve.</p>
                <Link href={`/bots?analyst=${analyst.id}`} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-white text-sm font-semibold no-underline hover:opacity-90" style={{ backgroundColor: analyst.color }}>
                  <MessageCircle className="w-4 h-4" /> Pergunte diretamente para {analyst.name.split(' ')[0]}
                </Link>
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
