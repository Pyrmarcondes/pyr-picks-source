/*
 * Termos de Uso — Pyr Picks
 * Inclui disclaimer editorial sobre metodologia amostral IA + H
 */
import { useEffect } from "react";
import { Link } from "wouter";
import { ChevronLeft, FileText } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function TermosUso() {
  useEffect(() => {
    document.title = "Termos de Uso | Pyr Picks";
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
      <Header />
      <main className="flex-1">
        <div className="container py-10 lg:py-16 max-w-3xl mx-auto">
          {/* Breadcrumb */}
          <Link href="/" className="flex items-center gap-2 text-sm text-[#0C6B58] hover:underline no-underline mb-8">
            <ChevronLeft className="w-4 h-4" />
            Voltar para home
          </Link>

          {/* Header */}
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-full bg-[#D4A843]/10 flex items-center justify-center flex-shrink-0">
              <FileText className="w-5 h-5 text-[#D4A843]" />
            </div>
            <div>
              <h1
                className="text-3xl lg:text-4xl text-[#2D2D2D]"
                style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
              >
                Termos de Uso
              </h1>
              <p className="text-sm text-[#2D2D2D]/50 mt-1">Última atualização: março de 2026</p>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-[#D1CCC5]/30 p-8 lg:p-10 space-y-8 text-[#2D2D2D]/80 leading-relaxed">

            <section>
              <h2 className="text-xl font-semibold text-[#2D2D2D] mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                1. Aceitação dos Termos
              </h2>
              <p className="text-sm">
                Ao acessar e utilizar o <strong>Pyr Picks</strong> (pyrpicks.com.br), você concorda com estes Termos de Uso. Se não concordar com qualquer parte destes termos, por favor não utilize o site.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-[#2D2D2D] mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                2. Natureza do Conteúdo Editorial
              </h2>
              {/* Bloco de destaque sobre metodologia */}
              <div className="bg-[#D4A843]/5 border border-[#D4A843]/20 rounded-xl p-5 mb-4">
                <p className="text-sm font-semibold text-[#2D2D2D] mb-2">Metodologia IA + H — Avaliações Amostrais</p>
                <p className="text-sm text-[#2D2D2D]/70">
                  As análises publicadas no Pyr Picks são produzidas por meio de uma metodologia híbrida denominada <strong>IA + H</strong>: os analistas IA do Pyr Picks realizam pesquisa, coleta de dados públicos, comparações e simulações amostrais; sobre esses insumos, <strong>Pyr Marcondes</strong> — com 50 anos de jornalismo editorial de negócios, economia e finanças — e especialistas convidados aplicam curadoria, validação e análise humana antes de qualquer publicação.
                </p>
              </div>
              <p className="text-sm mb-3">
                Em razão dessa metodologia, o usuário deve ter ciência de que:
              </p>
              <div className="space-y-3 text-sm">
                <div className="flex gap-3">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#2D2D2D]/30 flex-shrink-0 mt-1.5" />
                  <span>As avaliações são baseadas em <strong>amostras de dados públicos</strong> disponíveis na data da análise, não em testes laboratoriais exaustivos ou contratos comerciais com as empresas avaliadas.</span>
                </div>
                <div className="flex gap-3">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#2D2D2D]/30 flex-shrink-0 mt-1.5" />
                  <span>Os resultados podem variar conforme o perfil individual do consumidor, condições de mercado e alterações nos produtos avaliados após a data de publicação.</span>
                </div>
                <div className="flex gap-3">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#2D2D2D]/30 flex-shrink-0 mt-1.5" />
                  <span>O "One Best Pick" representa a melhor opção identificada para o perfil-alvo descrito em cada análise, não necessariamente a melhor opção para todos os perfis de consumidor.</span>
                </div>
                <div className="flex gap-3">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#2D2D2D]/30 flex-shrink-0 mt-1.5" />
                  <span>O conteúdo tem caráter <strong>informativo e jornalístico</strong>, não constituindo aconselhamento financeiro, jurídico, médico ou de qualquer outra natureza profissional regulamentada.</span>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-[#2D2D2D] mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                3. Independência Editorial
              </h2>
              <p className="text-sm">
                O Pyr Picks opera com total independência editorial. <strong>Não recebemos pagamento de empresas para publicar reviews positivos</strong> (prática conhecida como "payola"). <strong>Não monetizamos nenhum clique nos reviews</strong>. Nosso único modelo de receita é a newsletter Golden Club, onde ofertas premium são apresentadas aos assinantes que optaram por recebê-las. A escolha do "One Best Pick" é determinada exclusivamente pelos critérios editoriais da equipe, sem influência comercial.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-[#2D2D2D] mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                4. Propriedade Intelectual
              </h2>
              <p className="text-sm">
                Todo o conteúdo do Pyr Picks — textos, análises, imagens, marcas e identidade visual — é propriedade da Macuco GROUP ou licenciado por ela. É vedada a reprodução, distribuição ou uso comercial sem autorização prévia por escrito. Citações jornalísticas com atribuição são permitidas nos termos da legislação vigente.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-[#2D2D2D] mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                5. Links para Terceiros
              </h2>
              <p className="text-sm">
                O Pyr Picks pode conter links para sites de terceiros para fins de referência editorial. Não somos responsáveis pelo conteúdo, práticas de privacidade ou disponibilidade desses sites. A presença de um link não implica endosso comercial ao site vinculado e não gera receita para o Pyr Picks.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-[#2D2D2D] mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                6. Limitação de Responsabilidade
              </h2>
              <p className="text-sm">
                O Pyr Picks não se responsabiliza por decisões tomadas com base no conteúdo publicado. As análises são de caráter informativo e jornalístico. Recomendamos que decisões financeiras, de saúde, jurídicas ou de qualquer outra natureza relevante sejam tomadas com o apoio de profissionais habilitados.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-[#2D2D2D] mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                7. Conduta do Usuário
              </h2>
              <p className="text-sm">
                Ao utilizar o Pyr Picks, você concorda em não: (a) utilizar o site para fins ilegais; (b) tentar acessar áreas restritas sem autorização; (c) reproduzir ou distribuir conteúdo sem autorização; (d) enviar spam ou conteúdo malicioso por meio dos formulários do site.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-[#2D2D2D] mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                8. Lei Aplicável
              </h2>
              <p className="text-sm">
                Estes Termos são regidos pelas leis da República Federativa do Brasil. Fica eleito o foro da Comarca de São Paulo/SP para dirimir quaisquer controvérsias decorrentes destes Termos.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-[#2D2D2D] mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                9. Contato
              </h2>
              <p className="text-sm">
                Dúvidas sobre estes Termos podem ser enviadas para <a href="mailto:pyrpicks@macuco.group" className="text-[#0C6B58] hover:underline">pyrpicks@macuco.group</a>.
              </p>
            </section>

          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
