/*
 * Pyr Picks — Página "Sobre Pyr"
 * História de Pyr Marcondes, filosofia editorial e o modelo IA + H
 * Design: "Curated Intelligence" — Sofisticação Discreta com DNA Digital
 */
import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowLeft, BookOpen, Award, Users, Sparkles, Shield, TrendingUp, Quote } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const PYR_PHOTO = "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/pyr-marcondes-editor_53a6a2c4.jpeg";

const milestones = [
  {
    year: "1970s",
    title: "Início da carreira",
    description: "Primeiros passos no jornalismo econômico brasileiro, cobrindo a industrialização acelerada e o milagre econômico.",
  },
  {
    year: "1980s",
    title: "Cobertura da crise da dívida",
    description: "Reportagens sobre a hiperinflação e as negociações da dívida externa. Entrevistas com ministros da Fazenda e presidentes do Banco Central.",
  },
  {
    year: "1990s",
    title: "Plano Real e abertura econômica",
    description: "Cobertura em primeira mão do Plano Real, privatizações e a transformação do sistema financeiro brasileiro.",
  },
  {
    year: "2000s",
    title: "Fundação de veículos de referência",
    description: "Fundou e dirigiu publicações especializadas em economia, finanças e negócios, formando gerações de jornalistas econômicos.",
  },
  {
    year: "2010s",
    title: "Era digital e inovação",
    description: "Adaptação ao jornalismo digital, cobertura da ascensão das fintechs brasileiras e do ecossistema de startups.",
  },
  {
    year: "2026",
    title: "Pyr Picks: IA + H",
    description: "Fundação do Pyr Picks com o modelo IA + H (Human in the Loop): velocidade de IA com 50 anos de jornalismo editorial de negócios, economia e finanças.",
  },
];

const values = [
  {
    icon: Shield,
    title: "Independência Editorial Total",
    description: "Nunca recebemos pagamento por reviews positivos. Nenhum parceiro comercial influencia nossas escolhas. O 'One Best Pick' é sempre a melhor opção real. Não monetizamos nenhum clique nos reviews.",
    color: "#0C6B58",
  },
  {
    icon: TrendingUp,
    title: "Rigor de Dados",
    description: "Cada análise cruza dados oficiais, simulações rigorosas e pelo menos 6 fontes independentes. Usamos os mesmos critérios que um executivo experiente usaria antes de tomar uma decisão financeira importante.",
    color: "#D4A843",
  },
  {
    icon: Sparkles,
    title: "IA + H: Velocidade com Responsabilidade",
    description: "A IA pesquisa, compara e organiza em horas o que levaria semanas. Mas nada é publicado sem a curadoria final de Pyr. Cada 'One Best Pick' é uma recomendação pessoal — com nome e reputação em jogo.",
    color: "#1a5276",
  },
  {
    icon: BookOpen,
    title: "Transparência Radical",
    description: "Declaramos abertamente que usamos IA. Explicamos nossa metodologia. Nosso modelo de negócio é exclusivamente a newsletter Golden Club — onde ofertas premium chegam aos assinantes. Nenhum clique neste site gera receita para nós.",
    color: "#8B6914",
  },
];

const analysts = [
  { name: "Ana Finanças", vertical: "Finanças", id: "ana-financas" },
  { name: "Dr. Lucas Saúde", vertical: "Saúde", id: "dr-lucas-saude" },
  { name: "Clara Seguros", vertical: "Seguros", id: "clara-seguros" },
  { name: "Rafael Viagens", vertical: "Viagens", id: "rafael-viagens" },
  { name: "Sofia Streaming", vertical: "Streaming", id: "sofia-streaming" },
  { name: "Mei Chen", vertical: "Internacional", id: "mei-chen" },
  { name: "Kenji Tanaka", vertical: "Fintechs", id: "kenji-tanaka" },
  { name: "Araci ESG", vertical: "ESG", id: "araci-esg" },
];

export default function Sobre() {
  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
      <Header />
      <main className="flex-1">
        {/* Breadcrumb */}
        <div className="border-b border-[#D1CCC5]/50 bg-white">
          <div className="container py-3">
            <Link href="/" className="inline-flex items-center gap-1.5 text-xs text-[#2D2D2D]/50 hover:text-[#0C6B58] transition-colors no-underline">
              <ArrowLeft className="w-3 h-3" /> Início
            </Link>
          </div>
        </div>

        {/* Hero — Pyr Marcondes */}
        <section className="bg-gradient-to-br from-[#2D2D2D] to-[#1a1a1a] text-white">
          <div className="container py-12 lg:py-20 max-w-5xl mx-auto">
            <motion.div
              className="grid lg:grid-cols-[auto_1fr] gap-8 lg:gap-12 items-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              {/* Foto */}
              <div className="flex-shrink-0 mx-auto lg:mx-0">
                <div className="relative">
                  <div className="w-36 h-36 lg:w-48 lg:h-48 rounded-2xl overflow-hidden border-2 border-[#D4A843] shadow-2xl">
                    <img
                      src={PYR_PHOTO}
                      alt="Pyr Marcondes — Editor in Chief do Pyr Picks"
                      className="w-full h-full object-cover object-top"
                    />
                  </div>
                  <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-[#D4A843] text-[#2D2D2D] text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-full shadow whitespace-nowrap">
                    ★ Editor in Chief
                  </span>
                </div>
              </div>

              {/* Bio */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#D4A843] bg-[#D4A843]/20 px-2.5 py-1 rounded-full">
                    Fundador & Partner Editor in Chief
                  </span>
                </div>
                <h1 className="text-3xl lg:text-5xl text-white mb-2" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                  Pyr Marcondes
                </h1>
                <p className="text-base lg:text-lg text-white/60 mb-5">
                  Jornalista econômico. 50+ anos de carreira. Fundador do Pyr Picks.
                </p>
                <p className="text-sm lg:text-base text-white/80 leading-relaxed mb-4">
                  Pyr Marcondes é um dos jornalistas econômicos mais experientes do Brasil. Ao longo de cinco décadas, cobriu os principais ciclos econômicos do país, entrevistou presidentes, ministros e CEOs das maiores empresas brasileiras, e fundou veículos de referência no jornalismo de negócios.
                </p>
                <p className="text-sm lg:text-base text-white/80 leading-relaxed">
                  No Pyr Picks, ele aplica o mesmo rigor que usou em décadas de cobertura econômica para validar cada análise. Cada "One Best Pick" é uma recomendação pessoal — com nome e reputação em jogo.
                </p>
                <div className="flex flex-wrap gap-2 mt-5">
                  <span className="px-2.5 py-1 bg-[#0C6B58]/20 text-[#4ade80] text-xs font-medium rounded-full">50 anos de jornalismo editorial</span>
                  <span className="px-2.5 py-1 bg-[#D4A843]/20 text-[#D4A843] text-xs font-medium rounded-full">Negócios, Economia & Finanças</span>
                  <span className="px-2.5 py-1 bg-white/10 text-white/60 text-xs font-medium rounded-full">Macuco Group</span>
                  <span className="px-2.5 py-1 bg-white/10 text-white/60 text-xs font-medium rounded-full">IA + H</span>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Citação */}
        <section className="bg-[#D4A843]/10 border-y border-[#D4A843]/20">
          <div className="container py-8 lg:py-10 max-w-3xl mx-auto text-center">
            <Quote className="w-8 h-8 text-[#D4A843]/40 mx-auto mb-4" />
            <blockquote className="text-lg lg:text-2xl text-[#2D2D2D] leading-relaxed italic mb-4" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
              "Jornalismo econômico de qualidade sempre foi caro e lento. A IA resolve o custo e a velocidade. Eu resolvo o julgamento."
            </blockquote>
            <cite className="text-sm text-[#2D2D2D]/50 not-italic">— Pyr Marcondes, fundador do Pyr Picks</cite>
          </div>
        </section>

        {/* O que é o Pyr Picks */}
        <section className="bg-white border-b border-[#D1CCC5]/50">
          <div className="container py-10 lg:py-16 max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <div className="flex items-center gap-3 mb-6">
                <span className="w-6 h-[2px] bg-[#0C6B58]" />
                <h2 className="text-xl lg:text-2xl text-[#2D2D2D]" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                  O que é o Pyr Picks?
                </h2>
              </div>
              <div className="prose prose-sm lg:prose-base max-w-none text-[#2D2D2D]/70 space-y-4">
                <p className="text-base lg:text-lg leading-relaxed">
                  O Pyr Picks é um site de reviews editoriais independentes para serviços financeiros, saúde, seguros, viagens, streaming e investimentos. Nossa missão é simples: ajudar brasileiros a tomar decisões melhores em categorias onde a diferença entre a escolha certa e a errada pode custar milhares de reais por ano.
                </p>
                <p className="text-sm lg:text-base leading-relaxed">
                  Inspirado no modelo do Wirecutter americano, o Pyr Picks usa o conceito de "One Best Pick" — uma única recomendação clara, baseada em análise rigorosa, sem a confusão de listas intermináveis. Para cada categoria, temos um analista IA especializado que pesquisa, compara e gera rascunhos. Pyr revisa, valida e assina.
                </p>
                <p className="text-sm lg:text-base leading-relaxed">
                  Também publicamos os "Guias Sem Fim" — conteúdo educacional atemporal sobre como investir, escolher planos de saúde, proteger patrimônio e navegar no mundo financeiro digital. São guias sem produtos específicos, focados em princípios que valem para sempre.
                </p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Valores Editoriais */}
        <section className="bg-[#F8F6F3] border-b border-[#D1CCC5]/50">
          <div className="container py-10 lg:py-16 max-w-4xl mx-auto">
            <div className="flex items-center gap-3 mb-8">
              <span className="w-6 h-[2px] bg-[#D4A843]" />
              <h2 className="text-xl lg:text-2xl text-[#2D2D2D]" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                Nossos Valores Editoriais
              </h2>
            </div>
            <div className="grid sm:grid-cols-2 gap-5 lg:gap-6">
              {values.map((value, i) => (
                <motion.div
                  key={i}
                  className="bg-white rounded-xl border border-[#D1CCC5]/30 p-5 lg:p-6"
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.08 }}
                >
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${value.color}15` }}>
                      <value.icon className="w-4 h-4" style={{ color: value.color }} />
                    </div>
                    <h3 className="text-sm lg:text-base font-semibold text-[#2D2D2D]">{value.title}</h3>
                  </div>
                  <p className="text-xs lg:text-sm text-[#2D2D2D]/60 leading-relaxed">{value.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Trajetória */}
        <section className="bg-white border-b border-[#D1CCC5]/50">
          <div className="container py-10 lg:py-16 max-w-4xl mx-auto">
            <div className="flex items-center gap-3 mb-8">
              <span className="w-6 h-[2px] bg-[#0C6B58]" />
              <h2 className="text-xl lg:text-2xl text-[#2D2D2D]" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                Uma Trajetória de 50 Anos
              </h2>
            </div>
            <div className="relative">
              {/* Linha vertical */}
              <div className="absolute left-[18px] top-0 bottom-0 w-[2px] bg-[#D1CCC5]/50 hidden sm:block" />
              <div className="space-y-6">
                {milestones.map((m, i) => (
                  <motion.div
                    key={i}
                    className="flex gap-4 sm:gap-6 items-start"
                    initial={{ opacity: 0, x: -16 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: i * 0.07 }}
                  >
                    <div className="flex-shrink-0 w-9 h-9 rounded-full bg-[#0C6B58] flex items-center justify-center text-white text-[10px] font-bold shadow-sm z-10">
                      {i + 1}
                    </div>
                    <div className="flex-1 bg-[#F8F6F3] rounded-xl p-4 border border-[#D1CCC5]/30">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-[#D4A843]">{m.year}</span>
                      </div>
                      <h3 className="text-sm font-semibold text-[#2D2D2D] mb-1">{m.title}</h3>
                      <p className="text-xs text-[#2D2D2D]/60 leading-relaxed">{m.description}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Equipe de Analistas IA */}
        <section className="bg-[#F8F6F3] border-b border-[#D1CCC5]/50">
          <div className="container py-10 lg:py-16 max-w-4xl mx-auto">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <span className="w-6 h-[2px] bg-[#D4A843]" />
                <h2 className="text-xl lg:text-2xl text-[#2D2D2D]" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                  Os 8 Analistas IA
                </h2>
              </div>
              <Link href="/equipe" className="text-xs font-semibold text-[#0C6B58] hover:underline no-underline">
                Ver equipe completa →
              </Link>
            </div>
            <p className="text-sm text-[#2D2D2D]/60 mb-6 max-w-2xl">
              Cada vertical tem um analista IA especializado, treinado por Pyr com critérios editoriais rigorosos. Eles pesquisam, comparam e geram rascunhos. Pyr valida e assina.
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {analysts.map((a, i) => (
                <Link
                  key={i}
                  href={`/colunista/${a.id}`}
                  className="group bg-white rounded-xl border border-[#D1CCC5]/30 hover:border-[#0C6B58]/20 hover:shadow-sm transition-all p-3 text-center no-underline"
                >
                  <p className="text-xs font-semibold text-[#2D2D2D] group-hover:text-[#0C6B58] transition-colors mb-0.5">{a.name}</p>
                  <p className="text-[10px] text-[#2D2D2D]/40">{a.vertical}</p>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="bg-gradient-to-br from-[#0C6B58] to-[#0a5a49] text-white">
          <div className="container py-10 lg:py-14 max-w-3xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <Award className="w-10 h-10 text-[#D4A843] mx-auto mb-4" />
              <h2 className="text-2xl lg:text-3xl text-white mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                Conheça Nossa Metodologia
              </h2>
              <p className="text-sm lg:text-base text-white/70 mb-6 max-w-xl mx-auto">
                Entenda em detalhes como funciona o modelo IA + H, como escolhemos o "One Best Pick" e como garantimos independência editorial.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Link
                  href="/como-fazemos"
                  className="inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-[#D4A843] text-[#2D2D2D] text-sm font-semibold rounded-lg hover:bg-[#c49a3c] transition-colors no-underline"
                >
                  <BookOpen className="w-4 h-4" /> Como Fazemos
                </Link>
                <Link
                  href="/equipe"
                  className="inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-white/10 text-white text-sm font-semibold rounded-lg hover:bg-white/20 transition-colors no-underline"
                >
                  <Users className="w-4 h-4" /> Conhecer a Equipe
                </Link>
              </div>
            </motion.div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
