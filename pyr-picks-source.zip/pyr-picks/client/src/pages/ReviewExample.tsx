/*
 * Design: "Curated Intelligence"
 * Página de Review — Template completo com One Best Pick, tabela comparativa, FAQ AEO/GEO
 * Este é o template padrão para todos os reviews do Pyr Picks
 */
import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowLeft, Star, Clock, Calendar, CheckCircle2, XCircle, ExternalLink, Sparkles, Shield, ChevronDown, ChevronUp } from "lucide-react";
import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const competitors = [
  { name: "BTG Premium", rendimento: "102% CDI", anuidade: "Zero", atendimento: "24h VIP", protecao: "Sim (full)", nota: "9.8", winner: true },
  { name: "XP Investimentos", rendimento: "100% CDI", anuidade: "Zero", atendimento: "Bom", protecao: "Parcial", nota: "9.2", winner: false },
  { name: "Itaú Personnalité", rendimento: "98% CDI", anuidade: "R$ 500/ano", atendimento: "Excelente", protecao: "Sim", nota: "8.7", winner: false },
  { name: "Nubank Ultra", rendimento: "100% CDI", anuidade: "Zero", atendimento: "Digital", protecao: "Não", nota: "8.5", winner: false },
  { name: "C6 Carbon", rendimento: "99% CDI", anuidade: "R$ 300/ano", atendimento: "Bom", protecao: "Parcial", nota: "8.2", winner: false },
];

const pros = [
  "Rendimento real mais alto do mercado (102% CDI)",
  "App mais intuitivo e completo para investidores",
  "Proteção patrimonial completa sem custo extra",
  "Cashback em compras internacionais",
  "Atendimento VIP 24h com gerente dedicado",
];

const cons = [
  "Exige investimento mínimo de R$ 50 mil para conta premium",
  "Cartão físico demora até 15 dias para chegar",
  "Programa de pontos menos competitivo que concorrentes",
];

const faqs = [
  { q: "Qual a melhor conta digital para investir em 2026?", a: "Segundo nossa análise, a BTG Conta Digital Premium é a melhor opção para quem ganha acima de R$15k/mês, oferecendo 102% CDI, proteção patrimonial completa e atendimento VIP 24h." },
  { q: "Posso ter conta em mais de um banco digital?", a: "Sim. Na verdade, recomendamos ter pelo menos duas contas: uma principal (BTG para investimentos) e uma secundária (Nubank Ultra para gastos do dia a dia)." },
  { q: "Conta digital premium é segura?", a: "Sim. Todas as contas analisadas são protegidas pelo FGC até R$ 250 mil por CPF. A BTG ainda oferece proteção patrimonial adicional." },
  { q: "Qual banco digital rende mais em 2026?", a: "O BTG oferece 102% do CDI em CDB com liquidez diária, o maior rendimento entre as contas premium analisadas." },
  { q: "Vale a pena pagar anuidade de conta premium?", a: "Depende. BTG e XP não cobram anuidade. Itaú Personnalité cobra R$ 500/ano mas oferece atendimento presencial. Se você não precisa de agência, BTG é melhor." },
  { q: "Como funciona a proteção patrimonial do BTG?", a: "O BTG oferece seguro patrimonial integrado que cobre investimentos, imóveis e bens móveis. É ativado automaticamente para contas premium sem custo adicional." },
];

export default function ReviewExample() {
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
      <Header />

      <main className="flex-1">
        {/* Article Header */}
        <section className="bg-white border-b border-[#D1CCC5]/50">
          <div className="container py-8 lg:py-12">
            <div className="max-w-3xl">
              <Link href="/" className="inline-flex items-center gap-1.5 text-sm text-[#0C6B58] hover:underline no-underline mb-6">
                <ArrowLeft className="w-4 h-4" /> Voltar ao início
              </Link>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <span className="text-xs font-semibold uppercase tracking-wider text-[#0C6B58]">Finanças</span>

                <h1 className="text-3xl lg:text-4xl text-[#2D2D2D] mt-2 mb-4 leading-tight" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                  Melhor Conta Digital para Quem Ganha Acima de R$15k/mês em 2026
                </h1>

                {/* Byline */}
                <div className="flex items-center gap-4 mb-4">
                  <div className="flex items-center gap-2">
                    <img
                      src="https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/ana-financas-v3-negra-mvKjwSBeW8pCpXhj5i9gG6.webp"
                      alt="Ana Finanças"
                      className="w-8 h-8 rounded-full object-cover"
                    />
                    <div>
                      <p className="text-sm font-medium text-[#2D2D2D]">
                        Por <span className="text-[#0C6B58]">Ana Finanças</span> (IA) e <span className="text-[#D4A843]">Pyr</span> (Curadoria)
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-xs text-[#2D2D2D]/40">
                  <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" /> Atualizado em Março 2026</span>
                  <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> 7 min de leitura</span>
                </div>

                {/* IA + H bar */}
                <div className="mt-4 flex items-center gap-3">
                  <div className="flex-1 max-w-xs h-2 bg-[#F8F6F3] rounded-full overflow-hidden">
                    <div className="h-full flex">
                      <div className="w-[70%] bg-[#0C6B58] rounded-l-full" />
                      <div className="w-[30%] bg-[#D4A843] rounded-r-full" />
                    </div>
                  </div>
                  <span className="text-[10px] text-[#2D2D2D]/30">Pesquisa IA 70% | Curadoria Pyr 30%</span>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Article Content */}
        <div className="container py-8 lg:py-12">
          <div className="grid lg:grid-cols-[1fr_280px] gap-8 lg:gap-12">
            {/* Main content */}
            <div className="max-w-3xl">
              {/* One Best Pick - Answer First (AEO/GEO) */}
              <motion.div
                className="bg-[#D4A843]/5 border-2 border-[#D4A843]/30 rounded-xl p-6 lg:p-8 mb-10"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <div className="flex items-center gap-2 mb-3">
                  <Star className="w-5 h-5 text-[#D4A843] fill-[#D4A843]" />
                  <span className="text-sm font-bold uppercase tracking-wider text-[#D4A843]">One Best Pick</span>
                </div>
                <h2 className="text-2xl text-[#2D2D2D] mb-2" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                  BTG Conta Digital Premium
                </h2>
                <p className="text-sm text-[#2D2D2D]/60 leading-relaxed mb-4">
                  A única que realmente entrega tudo em 2026: rendimento de 102% CDI, proteção patrimonial completa, atendimento VIP 24h e zero anuidade. Para quem ganha acima de R$15k/mês e quer o melhor sem pagar mais por isso.
                </p>
                <div className="flex items-center gap-2 mb-4">
                  <span className="text-3xl font-bold text-[#0C6B58]" style={{ fontFamily: "'Fira Code', monospace" }}>9.8</span>
                  <span className="text-xs text-[#2D2D2D]/40">/10</span>
                </div>
                <a
                  href="#"
                  className="inline-flex items-center gap-2 px-6 py-3 bg-[#0C6B58] text-white text-sm font-semibold rounded-lg hover:bg-[#0C6B58]/90 transition-colors no-underline"
                >
                  Ver Oferta no BTG <ExternalLink className="w-4 h-4" />
                </a>

              </motion.div>

              {/* Methodology */}
              <div className="mb-10">
                <h2 className="text-xl text-[#2D2D2D] mb-4" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                  Metodologia
                </h2>
                <p className="text-sm text-[#2D2D2D]/70 leading-relaxed">
                  Testamos pessoalmente (e com a máquina de IA) as principais contas premium durante 30 dias: BTG, XP, Itaú Personnalité, Nubank Ultra e C6 Carbon. Critérios: rendimento real após imposto, taxa zero, app, atendimento 24h, proteção patrimonial e benefícios executivos. Dados cruzados com fontes oficiais (Anbima, Bacen, sites dos bancos) e feedbacks de 200+ usuários premium.
                </p>
              </div>

              {/* Comparison Table */}
              <div className="mb-10">
                <h2 className="text-xl text-[#2D2D2D] mb-4" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                  Tabela Comparativa
                </h2>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b-2 border-[#D1CCC5]">
                        <th className="text-left py-3 pr-4 text-xs font-semibold uppercase tracking-wider text-[#2D2D2D]/40" style={{ fontFamily: "'DM Sans', sans-serif" }}>Conta</th>
                        <th className="text-left py-3 pr-4 text-xs font-semibold uppercase tracking-wider text-[#2D2D2D]/40" style={{ fontFamily: "'DM Sans', sans-serif" }}>Rendimento</th>
                        <th className="text-left py-3 pr-4 text-xs font-semibold uppercase tracking-wider text-[#2D2D2D]/40" style={{ fontFamily: "'DM Sans', sans-serif" }}>Anuidade</th>
                        <th className="text-left py-3 pr-4 text-xs font-semibold uppercase tracking-wider text-[#2D2D2D]/40" style={{ fontFamily: "'DM Sans', sans-serif" }}>Atendimento</th>
                        <th className="text-left py-3 pr-4 text-xs font-semibold uppercase tracking-wider text-[#2D2D2D]/40" style={{ fontFamily: "'DM Sans', sans-serif" }}>Proteção</th>
                        <th className="text-right py-3 text-xs font-semibold uppercase tracking-wider text-[#2D2D2D]/40" style={{ fontFamily: "'DM Sans', sans-serif" }}>Nota</th>
                      </tr>
                    </thead>
                    <tbody>
                      {competitors.map((comp, i) => (
                        <tr
                          key={i}
                          className={`border-b border-[#D1CCC5]/30 ${comp.winner ? "bg-[#D4A843]/5" : ""}`}
                        >
                          <td className="py-3 pr-4 font-medium text-[#2D2D2D]">
                            {comp.winner && <Star className="inline w-3 h-3 text-[#D4A843] fill-[#D4A843] mr-1" />}
                            {comp.name}
                          </td>
                          <td className="py-3 pr-4 text-[#2D2D2D]/70" style={{ fontFamily: "'Fira Code', monospace" }}>{comp.rendimento}</td>
                          <td className="py-3 pr-4 text-[#2D2D2D]/70">{comp.anuidade}</td>
                          <td className="py-3 pr-4 text-[#2D2D2D]/70">{comp.atendimento}</td>
                          <td className="py-3 pr-4 text-[#2D2D2D]/70">{comp.protecao}</td>
                          <td className="py-3 text-right font-bold" style={{ fontFamily: "'Fira Code', monospace", color: comp.winner ? "#0C6B58" : "#2D2D2D" }}>
                            {comp.nota}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Why BTG Won */}
              <div className="mb-10">
                <h2 className="text-xl text-[#2D2D2D] mb-4" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                  Por que o BTG ganhou
                </h2>
                <p className="text-sm text-[#2D2D2D]/70 leading-relaxed mb-6">
                  O BTG Conta Digital Premium se destacou em todos os critérios que realmente importam para quem ganha acima de R$15k/mês. O rendimento de 102% do CDI é o mais alto entre as contas premium, o app é intuitivo e completo para investidores, e a proteção patrimonial integrada é um diferencial que nenhum concorrente oferece sem custo adicional.
                </p>

                {/* Pros */}
                <div className="mb-6">
                  <h3 className="text-sm font-semibold uppercase tracking-wider text-[#0C6B58] mb-3" style={{ fontFamily: "'DM Sans', sans-serif" }}>
                    Prós
                  </h3>
                  <div className="space-y-2">
                    {pros.map((pro, i) => (
                      <div key={i} className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-[#0C6B58] flex-shrink-0 mt-0.5" />
                        <span className="text-sm text-[#2D2D2D]/70">{pro}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Cons */}
                <div>
                  <h3 className="text-sm font-semibold uppercase tracking-wider text-red-600/70 mb-3" style={{ fontFamily: "'DM Sans', sans-serif" }}>
                    Contras
                  </h3>
                  <div className="space-y-2">
                    {cons.map((con, i) => (
                      <div key={i} className="flex items-start gap-2">
                        <XCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                        <span className="text-sm text-[#2D2D2D]/70">{con}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* FAQ (AEO/GEO) */}
              <div className="mb-10">
                <h2 className="text-xl text-[#2D2D2D] mb-4" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                  Perguntas Frequentes
                </h2>
                <div className="space-y-2">
                  {faqs.map((faq, i) => (
                    <div key={i} className="bg-white rounded-xl border border-[#D1CCC5]/30 overflow-hidden">
                      <button
                        onClick={() => setExpandedFaq(expandedFaq === i ? null : i)}
                        className="w-full flex items-center justify-between p-4 text-left"
                      >
                        <span className="text-sm font-medium text-[#2D2D2D] pr-4">{faq.q}</span>
                        {expandedFaq === i ? (
                          <ChevronUp className="w-4 h-4 text-[#2D2D2D]/30 flex-shrink-0" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-[#2D2D2D]/30 flex-shrink-0" />
                        )}
                      </button>
                      {expandedFaq === i && (
                        <div className="px-4 pb-4">
                          <p className="text-sm text-[#2D2D2D]/60 leading-relaxed">{faq.a}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Transparency Box */}
              <div className="bg-[#0C6B58]/5 border border-[#0C6B58]/10 rounded-xl p-6 mb-10">
                <div className="flex items-center gap-2 mb-3">
                  <Shield className="w-4 h-4 text-[#0C6B58]" />
                  <span className="text-xs font-semibold uppercase tracking-wider text-[#0C6B58]">Transparência</span>
                </div>
                <p className="text-sm text-[#2D2D2D]/60 leading-relaxed">
                  100% editorial. Não recebemos pagamento por reviews positivos. Este review foi gerado por Ana Finanças (IA) e revisado pessoalmente por Pyr (50 anos de jornalismo editorial de negócios, economia e finanças).
                </p>
                <Link href="/como-fazemos" className="inline-flex items-center gap-1 mt-3 text-xs font-medium text-[#0C6B58] hover:underline no-underline">
                  Entenda nosso método completo →
                </Link>
              </div>

              {/* Golden Club CTA */}
              <div className="bg-gradient-to-r from-[#0C6B58] to-[#0C6B58]/80 rounded-xl p-6 lg:p-8 text-white">
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="w-5 h-5 text-[#D4A843]" />
                  <span className="text-xs font-semibold uppercase tracking-wider text-[#D4A843]">Deal Exclusivo Golden Club</span>
                </div>
                <h3 className="text-xl text-white mb-2" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                  Taxa extra de 0,3% nos primeiros 3 meses
                </h3>
                <p className="text-sm text-white/70 mb-4">
                  Cadastre-se no Golden Club Pyr Picks e ganhe condições exclusivas negociadas por Pyr.
                </p>
                <button className="px-6 py-3 bg-white text-[#0C6B58] text-sm font-semibold rounded-lg hover:bg-white/90 transition-colors">
                  Quero o Deal Exclusivo
                </button>
              </div>
            </div>

            {/* Sidebar - Table of Contents */}
            <aside className="hidden lg:block">
              <div className="sticky top-36">
                <div className="bg-white rounded-xl border border-[#D1CCC5]/30 p-5">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-[#2D2D2D]/40 mb-4" style={{ fontFamily: "'DM Sans', sans-serif" }}>
                    Neste Review
                  </h4>
                  <nav className="space-y-2.5">
                    {["One Best Pick", "Metodologia", "Tabela Comparativa", "Por que o BTG ganhou", "Perguntas Frequentes"].map((item, i) => (
                      <a key={i} href="#" className="block text-sm text-[#2D2D2D]/60 hover:text-[#0C6B58] transition-colors no-underline">
                        {item}
                      </a>
                    ))}
                  </nav>
                </div>

                {/* Related reviews */}
                <div className="mt-6 bg-white rounded-xl border border-[#D1CCC5]/30 p-5">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-[#2D2D2D]/40 mb-4" style={{ fontFamily: "'DM Sans', sans-serif" }}>
                    Relacionados
                  </h4>
                  <div className="space-y-3">
                    <Link href="#" className="block text-sm text-[#2D2D2D]/70 hover:text-[#0C6B58] transition-colors no-underline leading-snug">
                      Os 3 CDBs que Realmente Rendem Mais em 2026
                    </Link>
                    <Link href="#" className="block text-sm text-[#2D2D2D]/70 hover:text-[#0C6B58] transition-colors no-underline leading-snug">
                      Melhor Corretora para Investidores Acima de R$500k
                    </Link>
                    <Link href="#" className="block text-sm text-[#2D2D2D]/70 hover:text-[#0C6B58] transition-colors no-underline leading-snug">
                      Melhor Cartão Black Sem Anuidade Escondida
                    </Link>
                  </div>
                </div>

                {/* Analyst card */}
                <div className="mt-6 bg-white rounded-xl border border-[#D1CCC5]/30 p-5 text-center">
                  <img
                    src="https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/ana-financas-v3-negra-mvKjwSBeW8pCpXhj5i9gG6.webp"
                    alt="Ana Finanças"
                    className="w-16 h-16 rounded-full object-cover mx-auto mb-3"
                  />
                  <h4 className="text-sm font-semibold text-[#2D2D2D]" style={{ fontFamily: "'DM Sans', sans-serif" }}>Ana Finanças</h4>
                  <p className="text-[11px] text-[#0C6B58] mb-1">Analista IA — Finanças</p>
                  <p className="text-[11px] text-[#2D2D2D]/40">Treinada por Pyr. 12 reviews publicados.</p>
                </div>
              </div>
            </aside>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
