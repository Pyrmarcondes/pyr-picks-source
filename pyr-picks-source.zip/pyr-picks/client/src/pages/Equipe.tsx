/*
 * Design: "Curated Intelligence"
 * Página Equipe — Apresentação dos 10 robôs colunistas com personalidade
 */
import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowLeft, Bot, MessageCircle, Sparkles } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const analysts = [
  {
    name: "Ana Finanças",
    profileId: "ana-financas",
    role: "Contas Digitais, CDBs e Investimentos",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/ana-financas-v3-negra-mvKjwSBeW8pCpXhj5i9gG6.webp",
    color: "#0C6B58",
    personality: "Analítica e focada em rentabilidade. Não aceita taxas escondidas e sempre calcula o rendimento líquido real.",
    expertise: ["Contas digitais premium", "CDBs e renda fixa", "Investimentos em ações e ETFs", "Corretoras para alta renda"],
    reviews: 12,
  },
  {
    name: "Dr. Lucas Saúde",
    profileId: "dr-lucas-saude",
    role: "Planos Executivos e Telemedicina",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/dr-lucas-oriental-v3-fEkoT9e2quMu2o2AKbxygQ.webp",
    color: "#1a5276",
    personality: "Cuidadoso e metódico. Foca em rede credenciada real, tempo de reembolso e cobertura de emergência.",
    expertise: ["Planos de saúde executivos", "Telemedicina premium", "Saúde preventiva", "Check-up executivo"],
    reviews: 8,
  },
  {
    name: "Clara Seguros",
    profileId: "clara-seguros",
    role: "Patrimonial, Vida e Auto",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/clara-seguros-v2_f6893f52.png",
    color: "#D4A843",
    personality: "Preventiva e detalhista. Lê as letras miúdas que ninguém lê e expõe exclusões que fazem diferença.",
    expertise: ["Seguro patrimonial", "Seguro de vida premium", "Seguro auto para carros de luxo", "Proteção financeira"],
    reviews: 10,
  },
  {
    name: "Rafael Viagens",
    profileId: "rafael-viagens",
    role: "Milhas, Hotéis e Turismo de Luxo",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/rafael-viagens-v2_c1e9e776.png",
    color: "#2e7d32",
    personality: "Aspiracional mas realista. Calcula o custo-benefício real de milhas e encontra hotéis boutique que valem cada centavo.",
    expertise: ["Programas de milhas", "Hotéis boutique", "Viagens de luxo", "Turismo executivo"],
    reviews: 6,
  },
  {
    name: "Sofia Streaming",
    profileId: "sofia-streaming",
    role: "Combos de Streaming e Entretenimento",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/sofia-streaming-v2_6cda54dd.png",
    color: "#6a1b9a",
    personality: "Dinâmica e prática. Testa catálogos, qualidade de stream e custo real de cada combo. Sem enrolação.",
    expertise: ["Combos de streaming", "Plataformas de vídeo", "Música e podcasts premium", "Gaming e entretenimento"],
    reviews: 5,
  },
  {
    name: "Mei Chen",
    profileId: "mei-chen",
    role: "Investimentos Internacionais & Mercados Asiáticos",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/mei-chen-avatar-U48QhjjKbRejFYcqgEPfrp.webp",
    color: "#c0392b",
    personality: "Analítica e global. Filha de imigrantes chineses, formada na USP e com MBA em Cingapura. Especialista em BDRs, ETFs internacionais e diversificação de carteira.",
    expertise: ["BDRs e ETFs internacionais", "Mercados asiáticos", "Fundos cambiais", "Diversificação global"],
    reviews: 4,
  },
  {
    name: "Kenji Tanaka",
    profileId: "kenji-tanaka",
    role: "Tecnologia, Fintechs e Inovação Financeira",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/kenji-tanaka-avatar-AtDr3sq3eZhF5JMDvdS9qn.webp",
    color: "#0d47a1",
    personality: "Visionário e técnico. Descendente de japoneses, ex-engenheiro de produto em fintech. Apaixonado por open banking, cripto e o futuro do dinheiro.",
    expertise: ["Fintechs e neobancos", "Open banking", "Criptomoedas e DeFi", "Pagamentos digitais"],
    reviews: 3,
  },
  {
    name: "Araci ESG",
    profileId: "araci-esg",
    role: "Investimentos Sustentáveis, ESG e Bioeconomia",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/araci-esg-avatar-UGjN3kRgjhjHihjNnKgb6n.webp",
    color: "#2e7d32",
    personality: "Sábio e criterioso. Indígena Guarani, economista pela UNICAMP. Conecta sabedoria ancestral com finanças modernas. Especialista em separar ESG real de greenwashing.",
    expertise: ["Fundos ESG verificados", "Bioeconomia amazônica", "Créditos de carbono", "Impacto socioambiental"],
    reviews: 2,
  },
];

const upcomingAnalysts = [
  { name: "Mateus Cartões", role: "Cartões premium, pontos e cashback", color: "#c62828" },
  { name: "Laura Imóveis", role: "Investimentos imobiliários e sucessão", color: "#4e342e" },
  { name: "Pedro Educação", role: "MBAs, cursos executivos e SaaS", color: "#1565c0" },
  { name: "Marina Luxo", role: "Joias, relógios e lifestyle premium", color: "#880e4f" },
  { name: "Theo Proteção", role: "Planejamento patrimonial e proteção financeira", color: "#37474f" },
];

export default function Equipe() {
  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
      <Header />

      <main className="flex-1">
        {/* Hero */}
        <section className="bg-white border-b border-[#D1CCC5]/50">
          <div className="container py-12 lg:py-16 max-w-4xl mx-auto">
            <Link href="/" className="inline-flex items-center gap-1.5 text-sm text-[#0C6B58] hover:underline no-underline mb-8">
              <ArrowLeft className="w-4 h-4" /> Voltar ao início
            </Link>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="flex items-center gap-2 mb-4">
                <Bot className="w-5 h-5 text-[#0C6B58]" />
                <span className="text-xs font-semibold uppercase tracking-wider text-[#0C6B58]">IA + H: Human in the Loop</span>
              </div>

              <h1 className="text-3xl lg:text-4xl text-[#2D2D2D] mb-4" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                Nossos Analistas IA
              </h1>

              <p className="text-lg text-[#2D2D2D]/60 leading-relaxed max-w-2xl">
                Cada vertical do Pyr Picks tem um analista IA especializado, treinado por Pyr. Eles pesquisam, comparam e geram rascunhos 24 horas por dia. Pyr valida, assina e garante a independência de cada "One Best Pick".
              </p>

              <div className="mt-6 inline-flex items-center gap-2 px-4 py-2 bg-[#D4A843]/10 border border-[#D4A843]/20 rounded-lg">
                <Sparkles className="w-4 h-4 text-[#D4A843]" />
                <span className="text-xs text-[#2D2D2D]/60">
                  Todos os analistas são declaradamente IA. Nunca fingimos ser humanos.
                </span>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Active Analysts */}
        <section className="border-b border-[#D1CCC5]/50">
          <div className="container py-12 lg:py-16 max-w-4xl mx-auto">
            <h2 className="text-xl text-[#2D2D2D] mb-8" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
              Analistas Ativos
            </h2>

            <div className="space-y-6">
              {analysts.map((analyst, i) => (
                <motion.article
                  key={i}
                  className="bg-white rounded-xl border border-[#D1CCC5]/30 overflow-hidden hover:shadow-md transition-shadow"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.08 }}
                >
                  <div className="flex flex-col md:flex-row">
                    {/* Avatar */}
                    <div className="md:w-48 flex-shrink-0 p-6 flex items-center justify-center bg-[#F8F6F3]">
                      <div className="relative">
                        <img
                          src={analyst.avatar}
                          alt={analyst.name}
                          className="w-28 h-28 md:w-32 md:h-32 rounded-full object-cover"
                        />
                        <span
                          className="absolute -bottom-1 -right-1 px-2 py-0.5 rounded-full text-white text-[10px] font-bold"
                          style={{ backgroundColor: analyst.color }}
                        >
                          IA
                        </span>
                      </div>
                    </div>

                    {/* Info */}
                    <div className="flex-1 p-6">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="text-lg font-semibold text-[#2D2D2D]" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                            {analyst.name}
                          </h3>
                          <p className="text-sm text-[#0C6B58] font-medium">{analyst.role}</p>
                        </div>
                        <span className="text-xs px-2.5 py-1 bg-[#F8F6F3] text-[#2D2D2D]/40 rounded-full" style={{ fontFamily: "'Fira Code', monospace" }}>
                          {analyst.reviews} reviews
                        </span>
                      </div>

                      <p className="text-sm text-[#2D2D2D]/60 leading-relaxed mb-4 italic">
                        "{analyst.personality}"
                      </p>

                      <div className="flex flex-wrap gap-2">
                        {analyst.expertise.map((exp, j) => (
                          <span key={j} className="text-[11px] px-2.5 py-1 bg-[#F8F6F3] text-[#2D2D2D]/50 rounded-full">
                            {exp}
                          </span>
                        ))}
                      </div>

                      <div className="mt-4 pt-4 border-t border-[#D1CCC5]/30 flex flex-wrap items-center gap-3">
                        <Link
                          href={`/colunista/${analyst.profileId}`}
                          className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg text-white no-underline hover:opacity-90 transition-opacity"
                          style={{ backgroundColor: analyst.color }}
                        >
                          Ver Perfil Completo
                        </Link>
                        <Link
                          href={`/bots?analyst=${analyst.profileId}`}
                          className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg border border-[#D1CCC5]/50 text-[#2D2D2D]/60 no-underline hover:border-[#0C6B58]/30 hover:text-[#0C6B58] transition-colors"
                        >
                          <MessageCircle className="w-3 h-3" /> Conversar
                        </Link>
                        <span className="text-[11px] text-[#2D2D2D]/30">
                          Treinado por Pyr — responde com dados validados
                        </span>
                      </div>
                    </div>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        {/* Upcoming Analysts */}
        <section className="bg-white">
          <div className="container py-12 lg:py-16 max-w-4xl mx-auto">
            <h2 className="text-xl text-[#2D2D2D] mb-2" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
              Em Breve
            </h2>
            <p className="text-sm text-[#2D2D2D]/50 mb-8">Novos analistas em treinamento para as próximas ondas de reviews.</p>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {upcomingAnalysts.map((analyst, i) => (
                <motion.div
                  key={i}
                  className="bg-[#F8F6F3] rounded-xl p-4 text-center border border-[#D1CCC5]/20"
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.3, delay: i * 0.05 }}
                >
                  <div
                    className="w-14 h-14 mx-auto rounded-full flex items-center justify-center text-white text-lg font-bold mb-3 opacity-60"
                    style={{ backgroundColor: analyst.color, fontFamily: "'DM Serif Display', Georgia, serif" }}
                  >
                    {analyst.name.charAt(0)}
                  </div>
                  <h4 className="text-xs font-semibold text-[#2D2D2D]/60" style={{ fontFamily: "'DM Sans', sans-serif" }}>
                    {analyst.name}
                  </h4>
                  <p className="text-[10px] text-[#2D2D2D]/30 mt-1">{analyst.role}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
