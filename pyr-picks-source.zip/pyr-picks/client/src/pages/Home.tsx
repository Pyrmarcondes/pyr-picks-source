/*
 * Pyr Picks - Premium Reviews Platform
 * Design: "Curated Intelligence" — Sofisticação Discreta com DNA Digital
 * Homepage: Layout magazine spread com hero, grid de reviews, colunistas IA, deals
 * Paleta: teal (#0C6B58), âmbar (#D4A843), cream (#F8F6F3), grafite (#2D2D2D)
 */
import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, Star, TrendingUp, Shield, Clock, Sparkles, BookOpen } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import GoldenClubForm from "@/components/GoldenClubForm";
import { reviews } from "@/lib/reviews";

const HERO_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/hero-banner-DKmQtPAAfT6SuExPZxkfmP.webp";
const PYR_PHOTO = "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/pyr-marcondes-editor_53a6a2c4.jpeg";

const analysts = [
  {
    id: "ana-financas",
    name: "Ana Finanças",
    role: "Contas Digitais, CDBs e Investimentos",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/ana-financas-v3-negra-mvKjwSBeW8pCpXhj5i9gG6.webp",
    tag: "Analista IA",
    color: "#0C6B58",
  },
  {
    id: "dr-lucas-saude",
    name: "Dr. Lucas Saúde",
    role: "Planos de Saúde, Telemedicina e Bem-estar",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/dr-lucas-oriental-v3-fEkoT9e2quMu2o2AKbxygQ.webp",
    tag: "Analista IA",
    color: "#1a5276",
  },
  {
    id: "clara-seguros",
    name: "Clara Seguros",
    role: "Seguros Residencial, Auto e Vida",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/clara-seguros-v2_f6893f52.png",
    tag: "Analista IA",
    color: "#D4A843",
  },
  {
    id: "rafael-viagens",
    name: "Rafael Viagens",
    role: "Milhas, Hotéis e Turismo de Luxo",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/rafael-viagens-v2_c1e9e776.png",
    tag: "Analista IA",
    color: "#2e7d32",
  },
  {
    id: "sofia-streaming",
    name: "Sofia Streaming",
    role: "Combos de Streaming e Entretenimento",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/sofia-streaming-v2_6cda54dd.png",
    tag: "Analista IA",
    color: "#6a1b9a",
  },
  {
    id: "mei-chen",
    name: "Mei Chen",
    role: "Investimentos Internacionais",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/mei-chen-avatar-U48QhjjKbRejFYcqgEPfrp.webp",
    tag: "Analista IA",
    color: "#c0392b",
  },
  {
    id: "kenji-tanaka",
    name: "Kenji Tanaka",
    role: "Fintechs e Inovação Financeira",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/kenji-tanaka-avatar-AtDr3sq3eZhF5JMDvdS9qn.webp",
    tag: "Analista IA",
    color: "#0d47a1",
  },
  {
    id: "araci-esg",
    name: "Araci ESG",
    role: "Investimentos Sustentáveis & ESG",
    avatar: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/araci-esg-avatar-UGjN3kRgjhjHihjNnKgb6n.webp",
    tag: "Analista IA",
    color: "#2e7d32",
  },
];

// Reviews dinâmicos: os 3 mais recentes por data
const CATEGORY_IMAGES: Record<string, string> = {
  financas: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/review-card-financas-kDXT7YKtTtd2xJ6UPJLk6b.webp",
  saude: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/review-card-saude-kDXT7YKtTtd2xJ6UPJLk6b.webp",
  seguros: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/review-card-seguros-kDXT7YKtTtd2xJ6UPJLk6b.webp",
  viagens: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/review-card-financas-kDXT7YKtTtd2xJ6UPJLk6b.webp",
  streaming: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/review-card-financas-kDXT7YKtTtd2xJ6UPJLk6b.webp",
  esg: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/review-card-financas-kDXT7YKtTtd2xJ6UPJLk6b.webp",
  fintechs: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/review-card-financas-kDXT7YKtTtd2xJ6UPJLk6b.webp",
  internacional: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/review-card-financas-kDXT7YKtTtd2xJ6UPJLk6b.webp",
};

const CATEGORY_LABELS: Record<string, string> = {
  financas: "Finanças",
  saude: "Saúde",
  seguros: "Seguros",
  viagens: "Viagens",
  streaming: "Streaming",
  esg: "ESG",
  fintechs: "Fintechs",
  internacional: "Internacional",
};

const featuredReviews = [...reviews]
  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
  .slice(0, 3)
  .map(r => ({
    slug: r.id,
    category: CATEGORY_LABELS[r.category] ?? r.category,
    title: r.title,
    excerpt: r.subtitle,
    bestPick: r.oneBestPick,
    analyst: r.analyst,
    date: new Date(r.date).toLocaleDateString('pt-BR', { month: 'short', year: 'numeric' }),
    readTime: "5 min",
    score: "9.5",
    image: r.image || CATEGORY_IMAGES[r.category] || CATEGORY_IMAGES.financas,
  }));


const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5, ease: "easeOut" },
};

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
      <Header />

      <main className="flex-1">

        {/* ===== FAIXA DE COLUNISTAS — primeira tela ===== */}
        <section className="bg-white border-b border-[#D1CCC5]/50">
          <div className="container py-3 lg:py-4">
            <div className="flex items-center gap-3 lg:gap-4 overflow-x-auto scrollbar-hide">
              {/* Pyr — Editor in Chief */}
              <Link
                href="/como-fazemos"
                className="flex-shrink-0 flex flex-col items-center gap-1.5 group no-underline"
              >
                <div className="relative">
                  <div className="w-12 h-12 lg:w-14 lg:h-14 rounded-full overflow-hidden border-2 border-[#D4A843] ring-2 ring-[#D4A843]/20 group-hover:ring-[#D4A843]/50 transition-all">
                    <img
                      src={PYR_PHOTO}
                      alt="Pyr Marcondes"
                      className="w-full h-full object-cover object-top"
                    />
                  </div>
                  <span className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-[#D4A843] rounded-full border-2 border-white flex items-center justify-center">
                    <span className="text-[7px] font-black text-[#2D2D2D]">★</span>
                  </span>
                </div>
                <div className="text-center">
                  <p className="text-[10px] lg:text-xs font-bold text-[#2D2D2D] whitespace-nowrap leading-tight">Pyr</p>
                  <p className="text-[8px] lg:text-[9px] text-[#D4A843] font-semibold uppercase tracking-wide whitespace-nowrap">Editor in Chief</p>
                </div>
              </Link>

              {/* Divisor */}
              <div className="w-px h-10 bg-[#D1CCC5]/70 flex-shrink-0" />

              {/* Colunistas IA */}
              {analysts.map((analyst) => (
                <Link
                  key={analyst.name}
                  href={`/colunista/${analyst.id}`}
                  className="flex-shrink-0 flex flex-col items-center gap-1.5 group no-underline"
                >
                  <div className="relative">
                    <div
                      className="w-12 h-12 lg:w-14 lg:h-14 rounded-full overflow-hidden border-2 group-hover:scale-105 transition-all"
                      style={{ borderColor: analyst.color }}
                    >
                      <img
                        src={analyst.avatar}
                        alt={analyst.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-green-400 rounded-full border-2 border-white" />
                  </div>
                  <div className="text-center">
                    <p className="text-[10px] lg:text-xs font-semibold text-[#2D2D2D] whitespace-nowrap leading-tight">
                      {analyst.name.split(" ")[0]}
                    </p>
                    <p className="text-[8px] lg:text-[9px] text-[#2D2D2D]/40 font-medium uppercase tracking-wide whitespace-nowrap">IA</p>
                  </div>
                </Link>
              ))}

              {/* Ver todos */}
              <Link
                href="/bots"
                className="flex-shrink-0 flex flex-col items-center gap-1.5 group no-underline ml-1"
              >
                <div className="w-12 h-12 lg:w-14 lg:h-14 rounded-full border-2 border-dashed border-[#0C6B58]/30 flex items-center justify-center bg-[#0C6B58]/5 group-hover:bg-[#0C6B58]/10 group-hover:border-[#0C6B58]/60 transition-all">
                  <ArrowRight className="w-4 h-4 text-[#0C6B58]/60 group-hover:text-[#0C6B58] transition-colors" />
                </div>
                <p className="text-[10px] lg:text-xs font-medium text-[#0C6B58]/60 group-hover:text-[#0C6B58] whitespace-nowrap transition-colors">Ver todos</p>
              </Link>
            </div>
          </div>
        </section>

        {/* ===== BANNER DE METODOLOGIA — logo após os colunistas ===== */}
        <section className="bg-[#0C6B58]/5 border-b border-[#0C6B58]/15">
          <div className="container py-3 lg:py-3.5">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
              <div className="flex items-start sm:items-center gap-2.5">
                <Shield className="w-3.5 h-3.5 text-[#0C6B58] flex-shrink-0 mt-0.5 sm:mt-0" />
                <p className="text-xs text-[#2D2D2D]/70 leading-relaxed">
                  <span className="font-semibold text-[#2D2D2D]">Como funcionam nossas avaliações:</span>{" "}
                  os analistas IA pesquisam dados públicos e fazem simulações amostrais. Sobre esses insumos, <span className="font-medium text-[#2D2D2D]">Pyr Marcondes</span> e especialistas aplicam análise humana e validam cada "One Best Pick" antes da publicação.
                </p>
              </div>
              <Link
                href="/como-fazemos"
                className="text-xs font-semibold text-[#0C6B58] hover:underline no-underline whitespace-nowrap flex-shrink-0"
              >
                Entender a metodologia →
              </Link>
            </div>
          </div>
        </section>

        {/* Guias Sem Fim — destaque TOPO */}
        <section className="border-b border-[#D1CCC5]/50 bg-gradient-to-r from-[#D4A843]/8 via-[#F8F6F3] to-[#0C6B58]/8">
          <div className="container py-5 lg:py-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              {/* Texto compacto */}
              <div className="flex items-center gap-4">
                <div className="flex -space-x-2 flex-shrink-0">
                  {[
                    "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-investir-melhor-v2-hHVgmay6qogDs6nGFaAjse.webp",
                    "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-plano-saude-v2-knKVNyDMbUqNJcC7NMZjWa.webp",
                    "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-viajar-melhor-v2-WfmUy2ZCMZiwYMNo2FQJXg.webp",
                    "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-proteger-patrimonio-v2-WPAfMVwoMe6gx6sJfCs3hX.webp",
                    "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-mundo-digital-v3-mQSiKpAdNiuGdWqWKmSD2R.webp",
                    "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-esg-araci-v2-T2mGR6JFxJmFCG8FnwV8J6.webp",
                  ].map((img, i) => (
                    <div key={i} className="w-9 h-12 lg:w-10 lg:h-14 rounded-md overflow-hidden border-2 border-white shadow-sm flex-shrink-0">
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </div>
                  ))}
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-0.5">
                    <BookOpen className="w-3.5 h-3.5 text-[#D4A843]" />
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#D4A843]">Novo</span>
                  </div>
                  <p className="text-sm lg:text-base font-semibold text-[#2D2D2D]" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                    Guias Sem Fim
                  </p>
                  <p className="text-xs text-[#2D2D2D]/60 hidden sm:block">
                    Educação financeira que nunca termina — 5 guias, novas dicas a cada clique
                  </p>
                </div>
              </div>
              {/* CTA */}
              <Link
                href="/guias"
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#D4A843] hover:bg-[#D4A843]/90 text-[#2D2D2D] text-sm font-semibold rounded-full transition-colors no-underline flex-shrink-0"
              >
                <BookOpen className="w-4 h-4" />
                Explorar os Guias
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </section>

        {/* Hero Section */}
        <section className="relative overflow-hidden">
          <div className="container py-6 lg:py-12">
            <div className="grid lg:grid-cols-[1fr_2fr_1fr] gap-4 lg:gap-8">
              {/* Left sidebar - What we do */}
              <motion.div
                className="hidden lg:flex flex-col gap-6"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
              >
                <div className="bg-gradient-to-br from-[#D4A843]/10 to-[#D4A843]/5 border border-[#D4A843]/20 rounded-xl p-4 lg:p-5">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#D4A843] bg-[#D4A843]/20 px-2 py-0.5 rounded-full">Premium Reviews</span>
                  </div>
                  <p className="text-xs lg:text-sm text-[#2D2D2D]/70 leading-relaxed mb-3">
                    Reviews independentes e rigorosas para executivos e tomadores de decisão. Cada análise é validada por Pyr, com 50 anos de jornalismo editorial de negócios, economia e finanças.
                  </p>
                  <div className="space-y-1.5 text-[10px] lg:text-xs text-[#2D2D2D]/60">
                    <div className="flex items-center gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#0C6B58]" />
                      <span>IA + H: Pesquisa + Curadoria</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#0C6B58]" />
                      <span>100% Editorial, Sem Payola</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#0C6B58]" />
                      <span>Dados Oficiais + Simulações</span>
                    </div>
                  </div>
                </div>

                {/* Deals Exclusivos - em breve */}
                <div className="bg-[#D4A843]/5 border border-[#D4A843]/20 rounded-xl p-4 lg:p-5">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-6 h-[2px] bg-[#D4A843]" />
                    <h3 className="text-xs lg:text-sm font-semibold uppercase tracking-wider text-[#2D2D2D]/40" style={{ fontFamily: "'DM Sans', sans-serif" }}>
                      Deals Exclusivos
                    </h3>
                  </div>
                  <p className="text-[10px] lg:text-xs text-[#2D2D2D]/60 mb-3 leading-relaxed">
                    Ofertas negociadas por Pyr com parceiros selecionados — exclusivas para membros do Golden Club.
                  </p>
                  <p className="text-[10px] text-[#D4A843] font-semibold uppercase tracking-wider">
                    Em breve
                  </p>
                </div>

                {/* Golden Club CTA */}
                <div className="bg-gradient-to-br from-[#0C6B58]/10 to-[#D4A843]/5 border border-[#0C6B58]/20 rounded-xl p-4 lg:p-5">
                  <h4 className="text-base lg:text-lg text-[#2D2D2D] mb-2 font-semibold" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                    Golden Club
                  </h4>
                  <p className="text-xs lg:text-sm text-[#2D2D2D]/60 mb-4">
                    Deals exclusivos, newsletter premium e benefícios negociados por Pyr.
                  </p>
                  <GoldenClubForm />
                </div>
              </motion.div>

              {/* Center - Hero Image */}
              <motion.div
                className="relative h-64 lg:h-auto"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: 0.1 }}
              >
                <img
                  src={HERO_IMG}
                  alt="Pyr Picks - Premium Reviews"
                  className="w-full h-full object-cover rounded-xl shadow-lg"
                />
              </motion.div>

              {/* Right sidebar - Key metrics */}
              <motion.div
                className="hidden lg:flex flex-col gap-6"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <div className="bg-white rounded-xl border border-[#D1CCC5]/50 p-4 lg:p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <Sparkles className="w-4 h-4 text-[#D4A843]" />
                    <h3 className="text-xs font-bold uppercase tracking-wider text-[#2D2D2D]">One Best Pick</h3>
                  </div>
                  <p className="text-sm lg:text-base font-bold text-[#0C6B58] mb-2">BTG Conta Digital Premium</p>
                  <p className="text-[10px] lg:text-xs text-[#2D2D2D]/60">Melhor conta digital premium para executivos com renda acima de R$15k/mês — Mar 2026</p>
                </div>

                <div className="bg-white rounded-xl border border-[#D1CCC5]/50 p-4 lg:p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <TrendingUp className="w-4 h-4 text-[#0C6B58]" />
                    <h3 className="text-xs font-bold uppercase tracking-wider text-[#2D2D2D]">Análises Recentes</h3>
                  </div>
                  <div className="space-y-2">
                    <p className="text-xs text-[#2D2D2D]/70">Planos de Saúde Premium</p>
                    <p className="text-xs text-[#2D2D2D]/70">Seguros Residencial Luxo</p>
                    <p className="text-xs text-[#2D2D2D]/70">Streaming Combos 2026</p>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-[#0C6B58]/5 to-[#D4A843]/5 border border-[#0C6B58]/10 rounded-xl p-4 lg:p-5">
                  <div className="flex items-center gap-2 mb-2">
                    <Shield className="w-4 h-4 text-[#0C6B58]" />
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#0C6B58]">Transparência</span>
                  </div>
                  <p className="text-[10px] lg:text-xs text-[#2D2D2D]/60">IA + H: Pesquisa + Curadoria de Pyr. 100% editorial, sem payola. Nenhum clique gera receita.</p>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Why Pyr Picks - Premium Differentiator */}
        <section className="border-t border-[#D1CCC5]/50 bg-gradient-to-b from-[#D4A843]/5 to-white">
          <div className="container py-8 lg:py-16">
            <div className="text-center mb-8 lg:mb-10">
              <h2 className="text-2xl lg:text-3xl text-[#2D2D2D] mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                Por que Pyr Picks?
              </h2>
              <p className="text-base lg:text-lg text-[#2D2D2D]/60">
                Premium Reviews para Decisões Importantes
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
              <motion.div
                className="bg-white rounded-xl border border-[#D1CCC5]/30 p-6 lg:p-8 text-center"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <div className="w-12 h-12 rounded-full bg-[#0C6B58]/10 flex items-center justify-center mx-auto mb-4">
                  <Star className="w-6 h-6 text-[#0C6B58]" />
                </div>
                <h3 className="text-lg font-semibold text-[#2D2D2D] mb-2">100% Editorial</h3>
                <p className="text-sm text-[#2D2D2D]/60">Sem payola. Sem pagamento por reviews positivos. <strong className="text-[#2D2D2D]/80">Nenhum clique neste site gera receita para nós.</strong> A escolha do One Best Pick é 100% independente.</p>
              </motion.div>

              <motion.div
                className="bg-white rounded-xl border border-[#D1CCC5]/30 p-6 lg:p-8 text-center"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                <div className="w-12 h-12 rounded-full bg-[#D4A843]/10 flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="w-6 h-6 text-[#D4A843]" />
                </div>
                <h3 className="text-lg font-semibold text-[#2D2D2D] mb-2">Dados Públicos + Simulações</h3>
                <p className="text-sm text-[#2D2D2D]/60">Avaliações amostrais com dados oficiais e públicos, simulações rigorosas e cruzamento de fontes. Critérios de executivo.</p>
              </motion.div>

              <motion.div
                className="bg-white rounded-xl border border-[#D1CCC5]/30 p-6 lg:p-8 text-center"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <div className="w-12 h-12 rounded-full bg-[#1a5276]/10 flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-6 h-6 text-[#1a5276]" />
                </div>
                <h3 className="text-lg font-semibold text-[#2D2D2D] mb-2">IA + H: Análise Humana</h3>
                <p className="text-sm text-[#2D2D2D]/60">IA pesquisa e simula. Pyr Marcondes e especialistas validam, corrigem e assinam cada "One Best Pick". Nenhuma publicação sem curadoria humana.</p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* IA + H: Human in the Loop */}
        <section className="border-t border-[#D1CCC5]/50 bg-white">
          <div className="container py-8 lg:py-16">
            <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <h2 className="text-2xl lg:text-3xl text-[#2D2D2D] mb-4" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                  IA + H: Human in the Loop
                </h2>
                <p className="text-base text-[#2D2D2D]/70 mb-4 leading-relaxed">
                  Nossas avaliações são <strong>amostrais</strong>: os analistas IA coletam dados públicos, fazem simulações e comparam produtos com base em critérios editoriais. Sobre esses insumos, <strong>Pyr Marcondes</strong> — com 50 anos de jornalismo editorial de negócios, economia e finanças — e especialistas convidados aplicam análise humana, validam cada número e escolhem o “One Best Pick” antes de qualquer publicação.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-[#0C6B58] flex items-center justify-center text-white text-sm font-bold">1</div>
                    <div>
                      <p className="font-semibold text-[#2D2D2D]">Pesquisa IA (70%)</p>
                      <p className="text-sm text-[#2D2D2D]/60">Análise de dados, comparação de preços, simulações</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-[#D4A843] flex items-center justify-center text-[#2D2D2D] text-sm font-bold">2</div>
                    <div>
                      <p className="font-semibold text-[#2D2D2D]">Curadoria Pyr (30%)</p>
                      <p className="text-sm text-[#2D2D2D]/60">Validação, escolha do vencedor, assinatura</p>
                    </div>
                  </div>
                </div>
              </motion.div>

              <motion.div
                className="bg-gradient-to-br from-[#0C6B58]/5 to-[#D4A843]/5 border border-[#0C6B58]/10 rounded-xl p-6 lg:p-8"
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <h3 className="text-lg font-semibold text-[#2D2D2D] mb-4">Nossos Analistas IA</h3>
                <p className="text-sm text-[#2D2D2D]/70 mb-6">
                  Cada vertical tem um analista IA especializado, treinado por Pyr. Eles pesquisam, comparam e geram rascunhos. Pyr valida e assina.
                </p>
                <Link href="/equipe" className="inline-flex items-center gap-2 text-sm font-semibold text-[#0C6B58] hover:underline no-underline">
                  Conhecer a equipe <ArrowRight className="w-4 h-4" />
                </Link>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Featured Reviews Grid */}
        <section className="bg-white border-t border-[#D1CCC5]/50">
          <div className="container py-8 lg:py-16">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-6 lg:mb-8">
              <div className="flex items-center gap-3">
                <span className="w-6 h-[2px] bg-[#0C6B58]" />
                <h2 className="text-xl lg:text-2xl text-[#2D2D2D]" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                  Reviews em Destaque
                </h2>
              </div>
              <Link href="/categoria/financas" className="flex items-center gap-1 text-xs lg:text-sm font-medium text-[#0C6B58] hover:underline no-underline">
                Ver todos <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredReviews.map((review, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: idx * 0.1 }}
                >
                  <Link href={`/review/${review.slug}`} className="group block bg-white rounded-xl overflow-hidden border border-[#D1CCC5]/30 hover:border-[#0C6B58]/20 hover:shadow-lg transition-all no-underline h-full flex flex-col">
                    {/* Image */}
                    <div className="relative h-48 overflow-hidden bg-[#F8F6F3]">
                      <img
                        src={review.image}
                        alt={review.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>

                    {/* Content */}
                    <div className="p-5 lg:p-6 flex flex-col flex-1">
                      <div className="flex items-center gap-2 mb-3">
                        <span className="inline-block px-2.5 py-1 bg-[#D4A843] text-[#2D2D2D] text-[10px] font-bold uppercase tracking-wider rounded-full">
                          One Best Pick
                        </span>
                        <span className="inline-block px-2 py-0.5 bg-[#0C6B58]/10 text-[#0C6B58] text-[9px] font-semibold uppercase tracking-wider rounded">
                          {review.analyst}
                        </span>
                      </div>

                      <h3 className="text-base lg:text-lg font-semibold text-[#2D2D2D] mb-2 line-clamp-2" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                        {review.title}
                      </h3>

                      <p className="text-xs lg:text-sm text-[#2D2D2D]/60 mb-4 flex-1">
                        {review.excerpt}
                      </p>

                      <div className="flex items-center justify-between pt-4 border-t border-[#D1CCC5]/30">
                        <span className="text-xs font-semibold text-[#0C6B58]">
                          {review.bestPick}
                        </span>
                        <ArrowRight className="w-4 h-4 text-[#0C6B58] group-hover:translate-x-1 transition-transform" />
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Transparência Total */}
        <section className="border-t border-[#D1CCC5]/50 bg-gradient-to-b from-white to-[#F8F6F3]">
          <div className="container py-8 lg:py-16">
            <div className="text-center mb-8 lg:mb-10">
              <h2 className="text-2xl lg:text-3xl text-[#2D2D2D] mb-3" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                Transparência Total
              </h2>
              <p className="text-base lg:text-lg text-[#2D2D2D]/60">
                Como realmente funciona cada review
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
              <motion.div
                className="bg-white rounded-xl border border-[#D1CCC5]/30 p-6 lg:p-8"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <h3 className="text-lg font-semibold text-[#2D2D2D] mb-3">IA + H: Como realmente funciona</h3>
                <p className="text-sm text-[#2D2D2D]/70 mb-4">
                  Usamos IA de ponta para pesquisar, organizar tabelas e gerar rascunhos em velocidade que nenhum humano conseguiria sozinho. Mas nada é publicado sem a curadoria final de Pyr.
                </p>
                <Link href="/como-fazemos" className="inline-flex items-center gap-1 text-sm font-semibold text-[#0C6B58] hover:underline no-underline">
                  Leia nosso método completo <ArrowRight className="w-4 h-4" />
                </Link>
              </motion.div>

              <motion.div
                className="bg-white rounded-xl border border-[#D1CCC5]/30 p-6 lg:p-8"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                <h3 className="text-lg font-semibold text-[#2D2D2D] mb-3">Nossa independência editorial</h3>
                <p className="text-sm text-[#2D2D2D]/70 mb-4">
                  Nunca recebemos pagamento por reviews positivos. Se um produto é ruim, nós dizemos. A escolha do One Best Pick é 100% editorial.
                </p>
                <Link href="/como-fazemos" className="inline-flex items-center gap-1 text-sm font-semibold text-[#0C6B58] hover:underline no-underline">
                  Saiba mais <ArrowRight className="w-4 h-4" />
                </Link>
              </motion.div>

              <motion.div
                className="bg-white rounded-xl border border-[#D1CCC5]/30 p-6 lg:p-8"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <h3 className="text-lg font-semibold text-[#2D2D2D] mb-3">O que "testado" significa</h3>
                <p className="text-sm text-[#2D2D2D]/70 mb-4">
                  Análise baseada em dados oficiais, simulações rigorosas e cruzamento de fontes. Usamos os mesmos critérios que um executivo usaria na vida real.
                </p>
                <Link href="/como-fazemos" className="inline-flex items-center gap-1 text-sm font-semibold text-[#0C6B58] hover:underline no-underline">
                  Entenda melhor <ArrowRight className="w-4 h-4" />
                </Link>
              </motion.div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
