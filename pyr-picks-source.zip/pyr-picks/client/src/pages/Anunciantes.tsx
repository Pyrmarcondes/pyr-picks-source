/*
 * Pyr Picks — Para Anunciantes e Parceiros Comerciais
 * Política clara: sem departamento comercial pró-ativo.
 * Apenas respondemos a demandas. Contato direto com Pyr.
 */
import { Link } from "wouter";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Mail, Shield, AlertCircle, ArrowRight } from "lucide-react";

export default function Anunciantes() {
  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
      <Header />

      <main className="flex-1">
        {/* Hero */}
        <section className="bg-[#2D2D2D] text-white">
          <div className="container py-14 lg:py-20">
            <div className="max-w-2xl">
              <span className="inline-block text-xs font-bold uppercase tracking-[0.2em] text-[#D4A843] bg-[#D4A843]/10 px-3 py-1 rounded-full mb-4">
                Parcerias Comerciais
              </span>
              <h1
                className="text-3xl lg:text-4xl text-white mb-4 leading-tight"
                style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
              >
                Para Anunciantes e Parceiros Comerciais
              </h1>
              <p className="text-base lg:text-lg text-white/60 leading-relaxed">
                O Pyr Picks não tem departamento comercial pró-ativo. Apenas respondemos a demandas.
                Se você tem interesse em uma parceria comercial, fale diretamente com Pyr.
              </p>
            </div>
          </div>
        </section>

        {/* Princípios editoriais */}
        <section className="border-b border-[#D1CCC5]/50">
          <div className="container py-12 lg:py-16">
            <div className="max-w-3xl">
              <h2
                className="text-2xl text-[#2D2D2D] mb-6"
                style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
              >
                O que você precisa saber antes de entrar em contato
              </h2>

              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-[#0C6B58]/10 flex items-center justify-center mt-0.5">
                    <Shield className="w-5 h-5 text-[#0C6B58]" />
                  </div>
                  <div>
                    <h3 className="text-base font-semibold text-[#2D2D2D] mb-1">
                      Reviews são 100% editoriais — sem negociação
                    </h3>
                    <p className="text-sm text-[#2D2D2D]/60 leading-relaxed">
                      Nenhuma empresa pode comprar, influenciar ou vetar um review do Pyr Picks.
                      A escolha do <strong>One Best Pick</strong> é feita exclusivamente com base em dados
                      públicos, simulações e curadoria editorial de Pyr. Isso não é negociável.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-[#D4A843]/10 flex items-center justify-center mt-0.5">
                    <AlertCircle className="w-5 h-5 text-[#D4A843]" />
                  </div>
                  <div>
                    <h3 className="text-base font-semibold text-[#2D2D2D] mb-1">
                      Nenhum clique no site gera receita para o Pyr Picks
                    </h3>
                    <p className="text-sm text-[#2D2D2D]/60 leading-relaxed">
                      Não operamos links de afiliados nos reviews. Nossa única fonte de receita
                      são as <strong>newsletters Golden Club</strong> com ofertas premium curadas —
                      e apenas quando há acordos comerciais formalizados e transparentes.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-[#1a5276]/10 flex items-center justify-center mt-0.5">
                    <Mail className="w-5 h-5 text-[#1a5276]" />
                  </div>
                  <div>
                    <h3 className="text-base font-semibold text-[#2D2D2D] mb-1">
                      Sem departamento comercial pró-ativo
                    </h3>
                    <p className="text-sm text-[#2D2D2D]/60 leading-relaxed">
                      O Pyr Picks não prospecta ativamente parceiros comerciais. Se você tem interesse
                      em uma parceria, a iniciativa precisa partir de você. Respondemos a todas as
                      demandas com atenção — mas não fazemos cold outreach.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* O que é possível */}
        <section className="bg-white border-b border-[#D1CCC5]/50">
          <div className="container py-12 lg:py-16">
            <div className="max-w-3xl">
              <h2
                className="text-2xl text-[#2D2D2D] mb-6"
                style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
              >
                O que pode ser discutido
              </h2>

              <div className="grid md:grid-cols-2 gap-4">
                {[
                  {
                    title: "Ofertas na Newsletter Golden Club",
                    desc: "Apresentação de ofertas exclusivas para os assinantes do Golden Club, com transparência total sobre a natureza comercial do conteúdo.",
                  },
                  {
                    title: "Conteúdo Patrocinado Identificado",
                    desc: "Conteúdo claramente identificado como patrocinado, separado dos reviews editoriais, com aprovação editorial de Pyr.",
                  },
                  {
                    title: "Presença em Guias Temáticos",
                    desc: "Participação em guias práticos (Guias Sem Fim) com identificação explícita de parceria comercial.",
                  },
                  {
                    title: "Outros Formatos",
                    desc: "Estamos abertos a discutir outros formatos de parceria que respeitem a independência editorial do Pyr Picks.",
                  },
                ].map((item) => (
                  <div
                    key={item.title}
                    className="bg-[#F8F6F3] rounded-xl border border-[#D1CCC5]/50 p-5"
                  >
                    <h3 className="text-sm font-semibold text-[#2D2D2D] mb-2">{item.title}</h3>
                    <p className="text-xs text-[#2D2D2D]/60 leading-relaxed">{item.desc}</p>
                  </div>
                ))}
              </div>

              <p className="text-xs text-[#2D2D2D]/40 mt-4 italic">
                * Toda parceria comercial é divulgada com transparência total para os leitores.
                A credibilidade editorial do Pyr Picks é o ativo mais valioso que temos — e o único
                que não está à venda.
              </p>
            </div>
          </div>
        </section>

        {/* CTA de contato */}
        <section className="bg-gradient-to-br from-[#0C6B58]/5 to-[#D4A843]/5">
          <div className="container py-14 lg:py-20">
            <div className="max-w-xl mx-auto text-center">
              <h2
                className="text-2xl lg:text-3xl text-[#2D2D2D] mb-4"
                style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
              >
                Fale diretamente com Pyr
              </h2>
              <p className="text-sm text-[#2D2D2D]/60 mb-8 leading-relaxed">
                Sem formulários, sem intermediários. Se você tem uma proposta séria,
                escreva diretamente para Pyr Marcondes.
              </p>
              <a
                href="mailto:pyr@macuco.digital"
                className="inline-flex items-center gap-2 bg-[#0C6B58] text-white px-8 py-3.5 rounded-lg font-semibold text-sm hover:bg-[#0a5a49] transition-colors no-underline"
              >
                <Mail className="w-4 h-4" />
                pyr@macuco.digital
              </a>
              <p className="text-xs text-[#2D2D2D]/30 mt-4">
                Respondemos a todas as mensagens. Sem auto-resposta.
              </p>
            </div>
          </div>
        </section>

        {/* Voltar */}
        <section className="border-t border-[#D1CCC5]/50 bg-white">
          <div className="container py-6">
            <Link
              href="/"
              className="inline-flex items-center gap-2 text-sm text-[#0C6B58] hover:text-[#0a5a49] no-underline"
            >
              <ArrowRight className="w-4 h-4 rotate-180" />
              Voltar para o Pyr Picks
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
