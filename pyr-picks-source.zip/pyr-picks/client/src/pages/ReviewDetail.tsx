import { useEffect } from 'react';
import { useParams, Link } from 'wouter';
import { motion } from 'framer-motion';
import { ChevronLeft, Check, X, ExternalLink } from 'lucide-react';
import { getReviewById } from '@/lib/reviews';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Streamdown } from "streamdown";

export default function ReviewDetail() {
  const { id } = useParams<{ id: string }>();
  const review = id ? getReviewById(id) : undefined;

  // Meta tags dinâmicas para AEO/GEO — invisíveis ao usuário
  useEffect(() => {
    if (!review) return;
    document.title = `${review.title} | Pyr Picks`;
    const setMeta = (name: string, content: string) => {
      let el = document.querySelector(`meta[name="${name}"]`) as HTMLMetaElement | null;
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute('name', name);
        document.head.appendChild(el);
      }
      el.setAttribute('content', content);
    };
    const setOg = (property: string, content: string) => {
      let el = document.querySelector(`meta[property="${property}"]`) as HTMLMetaElement | null;
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute('property', property);
        document.head.appendChild(el);
      }
      el.setAttribute('content', content);
    };
    setMeta('description', review.metaDescription ?? review.subtitle);
    setMeta('keywords', review.aeo);
    setMeta('geo.region', 'BR');
    setMeta('geo.placename', review.geo);
    setOg('og:title', `${review.title} | Pyr Picks`);
    setOg('og:description', review.subtitle);
    setOg('og:image', review.image);
    setOg('og:type', 'article');
    const canonical = `https://pyrpicks.com.br/review/${review.id}`;
    setOg('og:url', canonical);
    let canonicalLink = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
    if (!canonicalLink) {
      canonicalLink = document.createElement('link');
      canonicalLink.rel = 'canonical';
      document.head.appendChild(canonicalLink);
    }
    canonicalLink.href = canonical;

    // JSON-LD: Article + FAQPage
    const existingLd = document.getElementById('review-jsonld');
    if (existingLd) existingLd.remove();
    const script = document.createElement('script');
    script.id = 'review-jsonld';
    script.type = 'application/ld+json';
    const faqSchema = review.faq.length > 0 ? {
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      mainEntity: review.faq.map(f => ({
        '@type': 'Question',
        name: f.question,
        acceptedAnswer: { '@type': 'Answer', text: f.answer },
      })),
    } : null;
    const articleSchema = {
      '@context': 'https://schema.org',
      '@type': 'Article',
      headline: review.title,
      description: review.subtitle,
      image: review.image,
      author: { '@type': 'Person', name: review.authorName ?? 'Pyr Marcondes', description: review.authorBio ?? 'Editor responsável pelo Pyr Picks', jobTitle: 'Editor responsável', worksFor: { '@type': 'Organization', name: 'Pyr Picks' } },
      publisher: {
        '@type': 'Organization',
        name: 'Pyr Picks',
        logo: { '@type': 'ImageObject', url: 'https://pyrpicks-eoegx4rq.manus.space/favicon.ico' },
      },
      datePublished: review.date,
      keywords: review.aeo,
    };
    script.textContent = JSON.stringify(review.schemaJsonLd ?? (faqSchema ? [articleSchema, faqSchema] : articleSchema));
    document.head.appendChild(script);

    return () => {
      document.title = 'Pyr Picks — Reviews Premium por IA + Curadoria Humana';
      document.getElementById('review-jsonld')?.remove();
    };
  }, [review]);

  if (!review) {
    return (
      <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
        <Header />
        <main className="flex-1 flex flex-col items-center justify-center">
          <h1 className="text-2xl font-bold text-[#2D2D2D] mb-4">Review não encontrada</h1>
          <Link href="/" className="flex items-center gap-2 text-[#0C6B58] hover:underline no-underline">
            <ChevronLeft className="w-4 h-4" />
            Voltar para home
          </Link>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header />
      <main className="flex-1">
        {/* Breadcrumb */}
        <div className="container py-4">
          <Link href={`/categoria/${review.category}`} className="flex items-center gap-2 text-sm text-[#0C6B58] hover:underline no-underline">
            <ChevronLeft className="w-4 h-4" />
            Voltar para {review.category.charAt(0).toUpperCase() + review.category.slice(1)}
          </Link>
        </div>

        {/* Hero Section */}
        <section className="border-b border-[#D1CCC5]/50">
          <div className="container py-8 lg:py-12">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Main Content */}
              <div className="lg:col-span-2">
                <div className="flex items-center gap-2 mb-4">
                  <span className="inline-block px-3 py-1 bg-[#D4A843] text-[#2D2D2D] text-xs font-bold uppercase tracking-wider rounded-full">
                    One Best Pick
                  </span>
                  <span className="inline-block px-2.5 py-1 bg-[#0C6B58]/10 text-[#0C6B58] text-[9px] font-semibold uppercase tracking-wider rounded">
                    {review.analyst}
                  </span>
                </div>

                <h1 className="text-3xl lg:text-4xl text-[#2D2D2D] mb-4 leading-tight" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                  {review.title}
                </h1>

                <p className="text-base lg:text-lg text-[#2D2D2D]/60 mb-6">
                  {review.subtitle}
                </p>

                {/* Hero Image */}
                <div className="relative h-64 lg:h-96 rounded-xl overflow-hidden mb-8">
                  <img
                    src={review.image}
                    alt={review.title}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Description */}
                <div className="mb-8">
                  <p className="text-base text-[#2D2D2D]/70 leading-relaxed">
                    {review.description}
                  </p>
                </div>
              </div>

              {/* Sidebar */}
              <div className="hidden lg:flex flex-col gap-6">
                <div className="bg-gradient-to-br from-[#D4A843]/10 to-[#D4A843]/5 border border-[#D4A843]/20 rounded-xl p-6">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-[#D4A843] mb-3">One Best Pick</h3>
                  <p className="text-2xl font-bold text-[#2D2D2D] mb-3">{review.winner}</p>
                  <p className="text-sm text-[#2D2D2D]/60 mb-4">{review.winnerReason}</p>
                  {/* CTA newsletter — único canal de monetização */}
                  <div className="border-t border-[#D4A843]/20 pt-3 mt-1">
                    <p className="text-xs text-[#2D2D2D]/50 leading-relaxed">
                      Ofertas exclusivas sobre este produto chegam via <strong className="text-[#2D2D2D]/70">Golden Club</strong> — nossa newsletter premium. Não monetizamos nenhum clique nesta página.
                    </p>
                  </div>
                </div>

                <div className="bg-[#0C6B58]/5 border border-[#0C6B58]/10 rounded-xl p-6">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-[#0C6B58] mb-3">Testamos</h3>
                  <ul className="space-y-2">
                    {review.tested.map((item, idx) => (
                      <li key={idx} className="text-sm text-[#2D2D2D]/70 flex items-center gap-2">
                        <span className="w-1 h-1 rounded-full bg-[#0C6B58]" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Disclaimer IA + H */}
                <div className="bg-[#F8F6F3] border border-[#D1CCC5]/50 rounded-xl p-4">
                  <p className="text-[10px] text-[#2D2D2D]/50 leading-relaxed">
                    <strong>IA + H:</strong> Esta análise foi produzida por um analista IA e validada por Pyr Marcondes. 100% editorial — nunca recebemos pagamento por reviews positivos.
                  </p>
                </div>
              </div>

              {review.contentMarkdown && (
                <div className="prose prose-sm lg:prose-base max-w-none text-[#2D2D2D]/80 mb-8">
                  <Streamdown>{review.contentMarkdown}</Streamdown>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Pros and Cons */}
        <section className="border-b border-[#D1CCC5]/50">
          <div className="container py-8 lg:py-12">
            <h2 className="text-2xl lg:text-3xl text-[#2D2D2D] mb-8" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
              Prós e Contras
            </h2>

            <div className="grid md:grid-cols-2 gap-8">
              {/* Pros */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <h3 className="text-lg font-semibold text-[#0C6B58] mb-4 flex items-center gap-2">
                  <Check className="w-5 h-5" />
                  Prós
                </h3>
                <ul className="space-y-3">
                  {review.pros.map((pro, idx) => (
                    <li key={idx} className="flex gap-3 text-[#2D2D2D]/70">
                      <Check className="w-5 h-5 text-[#0C6B58] flex-shrink-0 mt-0.5" />
                      <span>{pro}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>

              {/* Cons */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <h3 className="text-lg font-semibold text-[#D4A843] mb-4 flex items-center gap-2">
                  <X className="w-5 h-5" />
                  Contras
                </h3>
                <ul className="space-y-3">
                  {review.cons.map((con, idx) => (
                    <li key={idx} className="flex gap-3 text-[#2D2D2D]/70">
                      <X className="w-5 h-5 text-[#D4A843] flex-shrink-0 mt-0.5" />
                      <span>{con}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            </div>
          </div>
        </section>

        {/* FAQ */}
        {review.faq.length > 0 && (
          <section className="border-b border-[#D1CCC5]/50">
            <div className="container py-8 lg:py-12">
              <h2 className="text-2xl lg:text-3xl text-[#2D2D2D] mb-8" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                Perguntas Frequentes
              </h2>

              <Accordion type="single" collapsible className="w-full">
                {review.faq.map((item, idx) => (
                  <AccordionItem key={idx} value={`faq-${idx}`} className="border-b border-[#D1CCC5]/30">
                    <AccordionTrigger className="text-base font-semibold text-[#2D2D2D] hover:text-[#0C6B58] py-4">
                      {item.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-[#2D2D2D]/70 pb-4">
                      {item.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </section>
        )}
      </main>
      <Footer />
    </div>
  );
}
