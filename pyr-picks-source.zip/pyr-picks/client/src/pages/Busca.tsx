/*
 * Página de busca — filtra reviews e guias pelo parâmetro ?q=
 */
import { useMemo } from "react";
import { Link, useSearch } from "wouter";
import { Search, ArrowRight } from "lucide-react";
import { reviews } from "@/lib/reviews";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function Busca() {
  const searchString = useSearch();
  const params = new URLSearchParams(searchString);
  const query = params.get("q")?.trim() ?? "";

  const results = useMemo(() => {
    if (!query) return [];
    const q = query.toLowerCase();
    return reviews.filter(
      (r) =>
        r.title.toLowerCase().includes(q) ||
        r.subtitle.toLowerCase().includes(q) ||
        r.description.toLowerCase().includes(q) ||
        r.winner.toLowerCase().includes(q) ||
        r.category.toLowerCase().includes(q) ||
        r.analyst.toLowerCase().includes(q)
    );
  }, [query]);

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
      <Header />
      <main className="flex-1">
        <div className="container py-10 lg:py-16">
          {/* Header da busca */}
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-2">
              <Search className="w-5 h-5 text-[#0C6B58]" />
              <h1
                className="text-2xl lg:text-3xl text-[#2D2D2D]"
                style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
              >
                {query ? `Resultados para "${query}"` : "Busca"}
              </h1>
            </div>
            {query && (
              <p className="text-sm text-[#2D2D2D]/50">
                {results.length === 0
                  ? "Nenhum review encontrado."
                  : `${results.length} review${results.length > 1 ? "s" : ""} encontrado${results.length > 1 ? "s" : ""}`}
              </p>
            )}
          </div>

          {/* Resultados */}
          {results.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {results.map((review) => (
                <Link
                  key={review.id}
                  href={`/review/${review.id}`}
                  className="group block bg-white rounded-xl overflow-hidden border border-[#D1CCC5]/30 hover:border-[#0C6B58]/20 hover:shadow-lg transition-all no-underline"
                >
                  <div className="relative h-40 overflow-hidden bg-[#F8F6F3]">
                    <img
                      src={review.image}
                      alt={review.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-3 left-3">
                      <span className="inline-block px-2 py-0.5 bg-[#D4A843] text-[#2D2D2D] text-[9px] font-bold uppercase tracking-wider rounded-full">
                        One Best Pick
                      </span>
                    </div>
                  </div>
                  <div className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-[9px] font-semibold uppercase tracking-wider text-[#0C6B58]/70">
                        {review.category}
                      </span>
                      <span className="text-[#D1CCC5]">·</span>
                      <span className="text-[9px] text-[#2D2D2D]/40">{review.analyst}</span>
                    </div>
                    <h3
                      className="text-sm font-semibold text-[#2D2D2D] mb-2 leading-snug group-hover:text-[#0C6B58] transition-colors line-clamp-2"
                      style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
                    >
                      {review.title}
                    </h3>
                    <p className="text-xs text-[#0C6B58] font-semibold flex items-center gap-1">
                      {review.winner}
                      <ArrowRight className="w-3 h-3" />
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          ) : query ? (
            <div className="text-center py-16">
              <div className="w-16 h-16 rounded-full bg-[#D1CCC5]/30 flex items-center justify-center mx-auto mb-4">
                <Search className="w-8 h-8 text-[#2D2D2D]/30" />
              </div>
              <h2
                className="text-xl text-[#2D2D2D] mb-2"
                style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
              >
                Nenhum resultado encontrado
              </h2>
              <p className="text-sm text-[#2D2D2D]/50 mb-6">
                Tente buscar por categoria, produto ou tema (ex: "plano de saúde", "streaming", "seguro").
              </p>
              <Link
                href="/"
                className="inline-flex items-center gap-2 text-sm font-semibold text-[#0C6B58] hover:underline no-underline"
              >
                <ArrowRight className="w-4 h-4 rotate-180" />
                Ver todos os reviews
              </Link>
            </div>
          ) : (
            <div className="text-center py-16">
              <p className="text-sm text-[#2D2D2D]/50">
                Use a barra de busca acima para encontrar reviews.
              </p>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}
