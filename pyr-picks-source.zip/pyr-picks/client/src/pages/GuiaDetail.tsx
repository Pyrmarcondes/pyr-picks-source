/**
 * Pyr Picks — Guia Sem Fim (página individual)
 * Exibe o histórico de dicas e permite gerar nova dica (2/semana, requer login)
 */
import { useParams, Link } from "wouter";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Sparkles, RefreshCw, Lock, BookOpen, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Streamdown } from "streamdown";

const COVER_IMAGES: Record<string, string> = {
  "como-investir-melhor": "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-investir-melhor-v2-hHVgmay6qogDs6nGFaAjse.webp",
  "como-escolher-plano-de-saude": "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-plano-saude-v2-knKVNyDMbUqNJcC7NMZjWa.webp",
  "como-viajar-melhor-gastando-menos": "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-viajar-melhor-v2-WfmUy2ZCMZiwYMNo2FQJXg.webp",
  "como-proteger-seu-patrimonio": "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-proteger-patrimonio-v2-WPAfMVwoMe6gx6sJfCs3hX.webp",
  "como-navegar-no-mundo-digital-financeiro": "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-mundo-digital-v3-mQSiKpAdNiuGdWqWKmSD2R.webp",
  "como-investir-com-criterio-esg": "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-esg-araci-v2-T2mGR6JFxJmFCG8FnwV8J6.webp",
};

export default function GuiaDetail() {
  const { slug } = useParams<{ slug: string }>();
  const { isAuthenticated } = useAuth();
  const [expandedEntry, setExpandedEntry] = useState<number | null>(null);
  const [generating, setGenerating] = useState(false);
  const [newEntryId, setNewEntryId] = useState<number | null>(null);

  const utils = trpc.useUtils();

  const { data, isLoading, error } = trpc.guides.getBySlug.useQuery(
    { slug: slug ?? "" },
    { enabled: !!slug }
  );

  const weeklyStatus = trpc.guides.myWeeklyStatus.useQuery(
    { guideId: data?.guide.id ?? 0 },
    { enabled: !!data?.guide.id && isAuthenticated }
  );

  const generateNext = trpc.guides.generateNext.useMutation({
    onSuccess: async (result) => {
      await utils.guides.getBySlug.invalidate({ slug: slug ?? "" });
      await utils.guides.myWeeklyStatus.invalidate({ guideId: data?.guide.id ?? 0 });
      setNewEntryId(result.entryNumber);
      setExpandedEntry(result.entryNumber);
      setGenerating(false);
    },
    onError: () => {
      setGenerating(false);
    },
  });

  const handleGenerateNext = () => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl();
      return;
    }
    if (!slug) return;
    setGenerating(true);
    generateNext.mutate({ guideSlug: slug });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
        <Header />
        <main className="flex-1 container py-12">
          <div className="animate-pulse space-y-4 max-w-2xl mx-auto">
            <div className="h-8 bg-[#F0EDE8] rounded w-2/3" />
            <div className="h-4 bg-[#F0EDE8] rounded w-full" />
            <div className="h-4 bg-[#F0EDE8] rounded w-5/6" />
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
        <Header />
        <main className="flex-1 container py-12 text-center">
          <p className="text-[#2D2D2D]/50">Guia não encontrado.</p>
          <Link href="/guias" className="text-[#0C6B58] text-sm mt-4 inline-block">
            ← Voltar aos Guias
          </Link>
        </main>
        <Footer />
      </div>
    );
  }

  const { guide, entries } = data;
  const coverImg = COVER_IMAGES[guide.slug] ?? guide.coverImage;
  const remaining = weeklyStatus.data?.remaining ?? 2;
  const canGenerate = isAuthenticated && remaining > 0;

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
      <Header />

      <main className="flex-1">
        {/* Hero com capa */}
        <section
          className="relative h-64 lg:h-80 overflow-hidden"
          style={{ backgroundColor: guide.color }}
        >
          <img
            src={coverImg}
            alt={guide.title}
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
          <div className="absolute inset-0 flex flex-col justify-end container pb-6">
            <Link
              href="/guias"
              className="inline-flex items-center gap-1 text-white/70 hover:text-white text-sm mb-3 no-underline w-fit transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Todos os Guias
            </Link>
            <h1
              className="text-2xl lg:text-4xl text-white font-semibold leading-tight"
              style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
            >
              {guide.title}
            </h1>
          </div>
        </section>

        <div className="container py-8 lg:py-12">
          <div className="max-w-3xl mx-auto">
            {/* Descrição e analista */}
            <div className="flex items-start gap-4 mb-8 bg-white rounded-xl p-5 border border-[#D1CCC5]/30">
              <img
                src={guide.analystAvatar}
                alt={guide.analystName}
                className="w-12 h-12 rounded-full object-cover flex-shrink-0"
              />
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-[#0C6B58] mb-1">
                  {guide.analystName} · Analista IA
                </p>
                <p className="text-sm text-[#2D2D2D]/70 leading-relaxed">{guide.description}</p>
              </div>
            </div>

            {/* Botão de gerar nova dica */}
            <div className="bg-gradient-to-r from-[#0C6B58]/5 to-[#D4A843]/5 border border-[#0C6B58]/20 rounded-xl p-5 mb-8">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                  <p className="text-sm font-semibold text-[#2D2D2D] mb-1">
                    Este guia tem <strong>{entries.length}</strong> dicas publicadas
                  </p>
                  {isAuthenticated ? (
                    <p className="text-xs text-[#2D2D2D]/60">
                      {remaining > 0
                        ? `Você pode solicitar mais ${remaining} dica${remaining > 1 ? "s" : ""} esta semana`
                        : "Você atingiu o limite de 2 dicas por semana. Volte na semana que vem."}
                    </p>
                  ) : (
                    <p className="text-xs text-[#2D2D2D]/60">
                      Faça login para solicitar novas dicas (2 por semana, gratuito)
                    </p>
                  )}
                </div>
                <Button
                  onClick={handleGenerateNext}
                  disabled={generating || (isAuthenticated && !canGenerate)}
                  className="flex-shrink-0 gap-2"
                  style={{ backgroundColor: canGenerate || !isAuthenticated ? guide.color : undefined }}
                >
                  {generating ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      Gerando dica...
                    </>
                  ) : !isAuthenticated ? (
                    <>
                      <Lock className="w-4 h-4" />
                      Login para nova dica
                    </>
                  ) : canGenerate ? (
                    <>
                      <Sparkles className="w-4 h-4" />
                      Próxima Dica
                    </>
                  ) : (
                    <>
                      <Lock className="w-4 h-4" />
                      Limite semanal atingido
                    </>
                  )}
                </Button>
              </div>
              {generateNext.error && (
                <p className="text-xs text-red-600 mt-2">{generateNext.error.message}</p>
              )}
            </div>

            {/* Lista de dicas */}
            {entries.length === 0 ? (
              <div className="text-center py-16">
                <BookOpen className="w-10 h-10 text-[#2D2D2D]/20 mx-auto mb-3" />
                <p className="text-[#2D2D2D]/40 text-sm">As dicas iniciais estão sendo preparadas.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {[...entries].reverse().map((entry) => {
                  const isNew = entry.entryNumber === newEntryId;
                  const isExpanded = expandedEntry === entry.entryNumber;

                  return (
                    <motion.div
                      key={entry.id}
                      initial={isNew ? { opacity: 0, y: -10, scale: 0.98 } : false}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      transition={{ duration: 0.4 }}
                      className={`bg-white rounded-xl border transition-all ${
                        isNew
                          ? "border-[#D4A843]/50 shadow-md shadow-[#D4A843]/10"
                          : "border-[#D1CCC5]/30 hover:border-[#0C6B58]/20"
                      }`}
                    >
                      <button
                        className="w-full text-left p-5 flex items-start justify-between gap-3"
                        onClick={() => setExpandedEntry(isExpanded ? null : entry.entryNumber)}
                      >
                        <div className="flex items-start gap-3 flex-1 min-w-0">
                          <span
                            className="flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white mt-0.5"
                            style={{ backgroundColor: guide.color }}
                          >
                            {entry.entryNumber}
                          </span>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h3 className="text-sm font-semibold text-[#2D2D2D]">{entry.title}</h3>
                              {isNew && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-[#D4A843]/15 text-[#D4A843] text-[10px] font-bold rounded-full">
                                  <Sparkles className="w-2.5 h-2.5" />
                                  Nova
                                </span>
                              )}
                            </div>
                            {entry.tip && !isExpanded && (
                              <p className="text-xs text-[#2D2D2D]/50 mt-1 line-clamp-1">{entry.tip}</p>
                            )}
                          </div>
                        </div>
                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4 text-[#2D2D2D]/40 flex-shrink-0 mt-1" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-[#2D2D2D]/40 flex-shrink-0 mt-1" />
                        )}
                      </button>

                      <AnimatePresence>
                        {isExpanded && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.25 }}
                            className="overflow-hidden"
                          >
                            <div className="px-5 pb-5 border-t border-[#D1CCC5]/30 pt-4">
                              <div className="prose prose-sm max-w-none text-[#2D2D2D]/80">
                                <Streamdown>{entry.content}</Streamdown>
                              </div>
                              {entry.tip && (
                                <div
                                  className="mt-4 p-3 rounded-lg border-l-4 text-sm text-[#2D2D2D]/70 bg-opacity-5"
                                  style={{ borderColor: guide.color, backgroundColor: guide.color + "10" }}
                                >
                                  <span className="font-semibold text-xs uppercase tracking-wider" style={{ color: guide.color }}>
                                    Dica Prática:
                                  </span>{" "}
                                  {entry.tip}
                                </div>
                              )}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
