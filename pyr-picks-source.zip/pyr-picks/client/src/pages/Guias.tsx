/**
 * Pyr Picks — Guias Sem Fim
 * Listagem dos 5 guias setoriais com conteúdo gerado por IA a cada clique
 */
import { Link } from "wouter";
import { motion } from "framer-motion";
import { BookOpen, Sparkles, RefreshCw, Lock } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { trpc } from "@/lib/trpc";

const COVER_IMAGES: Record<string, string> = {
  "como-investir-melhor": "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-investir-melhor-v2-hHVgmay6qogDs6nGFaAjse.webp",
  "como-escolher-plano-de-saude": "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-plano-saude-v2-knKVNyDMbUqNJcC7NMZjWa.webp",
  "como-viajar-melhor-gastando-menos": "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-viajar-melhor-v2-WfmUy2ZCMZiwYMNo2FQJXg.webp",
  "como-proteger-seu-patrimonio": "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-proteger-patrimonio-v2-WPAfMVwoMe6gx6sJfCs3hX.webp",
  "como-navegar-no-mundo-digital-financeiro": "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-mundo-digital-v3-mQSiKpAdNiuGdWqWKmSD2R.webp",
  "como-investir-com-criterio-esg": "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-esg-araci-v2-T2mGR6JFxJmFCG8FnwV8J6.webp",
};

export default function Guias() {
  const { data: guides, isLoading } = trpc.guides.list.useQuery();

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
      <Header />

      <main className="flex-1">
        {/* Hero da seção */}
        <section className="bg-gradient-to-br from-[#0C6B58] to-[#0a5546] text-white">
          <div className="container py-12 lg:py-16">
            <motion.div
              className="max-w-3xl"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="flex items-center gap-2 mb-4">
                <Sparkles className="w-5 h-5 text-[#D4A843]" />
                <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#D4A843]">
                  Novo
                </span>
              </div>
              <h1
                className="text-3xl lg:text-5xl text-white mb-4 leading-tight"
                style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
              >
                Guias Sem Fim
              </h1>
              <p className="text-lg text-white/80 mb-6 leading-relaxed">
                Guias setoriais que crescem a cada clique. Cada vez que você pede,
                nossos analistas IA geram uma nova dica educativa — atemporal, sem
                produtos específicos, focada em princípios que valem para sempre.
              </p>

              {/* Como funciona */}
              <div className="grid sm:grid-cols-3 gap-4">
                <div className="bg-white/10 rounded-xl p-4 border border-white/20">
                  <BookOpen className="w-5 h-5 text-[#D4A843] mb-2" />
                  <p className="text-sm font-semibold text-white mb-1">Leia o substrato</p>
                  <p className="text-xs text-white/70">Cada guia começa com dicas iniciais publicadas — leia sem precisar de conta.</p>
                </div>
                <div className="bg-white/10 rounded-xl p-4 border border-white/20">
                  <RefreshCw className="w-5 h-5 text-[#D4A843] mb-2" />
                  <p className="text-sm font-semibold text-white mb-1">Peça uma nova dica</p>
                  <p className="text-xs text-white/70">Com login, clique em "Próxima Dica" e a IA gera conteúdo novo na hora.</p>
                </div>
                <div className="bg-white/10 rounded-xl p-4 border border-white/20">
                  <Lock className="w-5 h-5 text-[#D4A843] mb-2" />
                  <p className="text-sm font-semibold text-white mb-1">2 dicas por semana</p>
                  <p className="text-xs text-white/70">Limite de 2 requests semanais por guia. O guia cresce para todos.</p>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Diferença editorial */}
        <section className="border-b border-[#D1CCC5]/50 bg-white">
          <div className="container py-6">
            <div className="flex flex-col sm:flex-row gap-6 items-start">
              <div className="flex-1 bg-[#0C6B58]/5 border border-[#0C6B58]/20 rounded-xl p-4">
                <p className="text-xs font-bold uppercase tracking-wider text-[#0C6B58] mb-1">Colunas (Reviews)</p>
                <p className="text-sm text-[#2D2D2D]/70">
                  <strong>"Pyr analisou. Pyr escolheu. Aqui está o vencedor."</strong><br />
                  Artigos longos com comparativos, metodologia e One Best Pick. Validados por Pyr Marcondes.
                </p>
              </div>
              <div className="flex-1 bg-[#D4A843]/5 border border-[#D4A843]/30 rounded-xl p-4">
                <p className="text-xs font-bold uppercase tracking-wider text-[#D4A843] mb-1">Guias Sem Fim</p>
                <p className="text-sm text-[#2D2D2D]/70">
                  <strong>"Você pergunta. A IA responde. O guia cresce."</strong><br />
                  Dicas atemporais sobre princípios e critérios. Sem produtos específicos. Educação financeira que não envelhece.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Grid de guias */}
        <section className="container py-10 lg:py-16">
          {isLoading ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="bg-white rounded-xl overflow-hidden border border-[#D1CCC5]/30 animate-pulse">
                  <div className="h-64 bg-[#F0EDE8]" />
                  <div className="p-5">
                    <div className="h-4 bg-[#F0EDE8] rounded mb-2 w-3/4" />
                    <div className="h-3 bg-[#F0EDE8] rounded w-full" />
                  </div>
                </div>
              ))}
            </div>
          ) : guides && guides.length > 0 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {guides.map((guide, idx) => (
                <motion.div
                  key={guide.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: idx * 0.08 }}
                >
                  <Link
                    href={`/guias/${guide.slug}`}
                    className="group block bg-white rounded-xl overflow-hidden border border-[#D1CCC5]/30 hover:border-[#0C6B58]/30 hover:shadow-lg transition-all no-underline h-full flex flex-col"
                  >
                    {/* Capa */}
                    <div className="relative h-64 overflow-hidden">
                      <img
                        src={COVER_IMAGES[guide.slug] ?? guide.coverImage}
                        alt={guide.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />

                    </div>

                    {/* Conteúdo */}
                    <div className="p-5 flex flex-col flex-1">
                      <h2
                        className="text-base lg:text-lg font-semibold text-[#2D2D2D] mb-2 group-hover:text-[#0C6B58] transition-colors leading-snug"
                        style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
                      >
                        {guide.title}
                      </h2>
                      <p className="text-sm text-[#2D2D2D]/60 mb-4 flex-1 line-clamp-3">
                        {guide.description}
                      </p>
                      <div className="flex items-center justify-between pt-3 border-t border-[#D1CCC5]/30">
                        <div className="flex items-center gap-2">
                          <img
                            src={guide.analystAvatar}
                            alt={guide.analystName}
                            className="w-6 h-6 rounded-full object-cover"
                          />
                          <span className="text-xs text-[#2D2D2D]/50">{guide.analystName}</span>
                        </div>
                        <span className="text-xs font-semibold text-[#0C6B58]">
                          {guide.totalEntries} dicas →
                        </span>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-20">
              <BookOpen className="w-12 h-12 text-[#2D2D2D]/20 mx-auto mb-4" />
              <p className="text-[#2D2D2D]/40">Os guias estão sendo preparados. Volte em breve.</p>
            </div>
          )}
        </section>
      </main>

      <Footer />
    </div>
  );
}
