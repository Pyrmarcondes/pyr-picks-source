/*
 * Design: "Curated Intelligence"
 * Página "Como Fazemos" — Disclaimer completo e transparente sobre o modelo IA + H
 */
import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowLeft, Sparkles, Shield, Eye, Users, BarChart3, MessageCircle } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const steps = [
  {
    number: "01",
    title: "Pesquisa IA",
    description: "O Macuco Content Studio gera rascunho com dados públicos de 2026, cruzando 50+ fontes, comparando preços, taxas, coberturas e feedbacks de usuários reais.",
    duration: "4-6 horas",
    icon: BarChart3,
  },
  {
    number: "02",
    title: "Otimização AEO/GEO",
    description: "Aplicamos o modelo AEO/GEO para que as IAs do mercado (ChatGPT, Gemini, Perplexity) citem nosso conteúdo como fonte confiável. Tabelas, FAQ e dados estruturados.",
    duration: "1-2 horas",
    icon: Eye,
  },
  {
    number: "03",
    title: "Curadoria Pyr",
    description: "Pyr revisa pessoalmente, testa critérios objetivos, valida números e escolhe o 'One Best Pick'. Nada é publicado sem sua assinatura de 50 anos de jornalismo editorial de negócios, economia e finanças.",
    duration: "30 minutos",
    icon: Users,
  },
  {
    number: "04",
    title: "Publicação",
    description: "Publicamos com data de atualização, assinatura completa, schema markup e metodologia transparente.",
    duration: "Imediato",
    icon: Sparkles,
  },
];

const faqs = [
  {
    question: "Os reviews são feitos por IA?",
    answer: "Sim. Usamos IA para acelerar pesquisa e tabelas. Mas tudo passa pela curadoria final de Pyr, que assina e valida. É IA + H (Human in the Loop).",
  },
  {
    question: '"Testado" significa que Pyr abriu conta em todos os bancos?',
    answer: "Não. Significa análise rigorosa com dados públicos, simulações e critérios reais validados por Pyr. Exatamente como um executivo faria antes de decidir.",
  },
  {
    question: "Vocês são pagos pelas empresas?",
    answer: "Não. A escolha do One Best Pick é 100% editorial. Nunca recebemos pagamento por reviews positivos. Se um produto é ruim, nós dizemos.",
  },
  {
    question: "Posso confiar no 'One Best Pick'?",
    answer: "Sim. Pyr revisa cada um pessoalmente. Se mudar de opinião, atualizamos o review no mesmo dia.",
  },
  {
    question: "Como falo com um humano?",
    answer: "Responda nos comentários ou mande mensagem. Pyr lê tudo. Ou converse com nossos analistas IA (Ana, Lucas, Clara…) que foram treinados por ele.",
  },
  {
    question: "Os analistas IA são humanos?",
    answer: "Não. São bots claramente identificados como IA, treinados por Pyr. Eles respondem 24h com dados validados.",
  },
  {
    question: "E se eu não gostar de um review?",
    answer: "Mande sua crítica. Atualizamos se houver erro. Transparência é nossa regra.",
  },
];

export default function ComoFazemos() {
  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
      <Header />

      <main className="flex-1">
        {/* Hero */}
        <section className="bg-white border-b border-[#D1CCC5]/50">
          <div className="container py-12 lg:py-20 max-w-3xl mx-auto">
            <Link href="/" className="inline-flex items-center gap-1.5 text-sm text-[#0C6B58] hover:underline no-underline mb-8">
              <ArrowLeft className="w-4 h-4" /> Voltar ao início
            </Link>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="flex items-center gap-2 mb-4">
                <Shield className="w-5 h-5 text-[#0C6B58]" />
                <span className="text-xs font-semibold uppercase tracking-wider text-[#0C6B58]">Transparência Total</span>
              </div>

              <h1 className="text-3xl lg:text-4xl text-[#2D2D2D] mb-4" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                IA + H: Como Realmente Funciona o Pyr Picks
              </h1>

              <p className="text-lg text-[#2D2D2D]/60 leading-relaxed">
                No Pyr Picks, usamos a mais avançada IA do mundo (Macuco Content Studio) para pesquisar, organizar tabelas, gerar rascunhos e atualizar números em velocidade que nenhum humano conseguiria sozinho. Mas nada é publicado sem a curadoria final de Pyr — com 50 anos de jornalismo editorial de negócios, economia e finanças, que valida cada número, escolhe o “One Best Pick” e assina pessoalmente.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Pyr Marcondes — Bio */}
        <section className="bg-gradient-to-br from-[#D4A843]/5 to-white border-b border-[#D1CCC5]/50">
          <div className="container py-10 lg:py-14 max-w-3xl mx-auto">
            <motion.div
              className="flex flex-col sm:flex-row gap-6 lg:gap-8 items-start"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <div className="flex-shrink-0">
                <div className="relative">
                  <div className="w-24 h-24 lg:w-28 lg:h-28 rounded-2xl overflow-hidden border-2 border-[#D4A843] shadow-lg">
                    <img
                      src="https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/pyr-marcondes-editor_53a6a2c4.jpeg"
                      alt="Pyr Marcondes"
                      className="w-full h-full object-cover object-top"
                    />
                  </div>
                  <span className="absolute -bottom-1 -right-1 bg-[#D4A843] text-[#2D2D2D] text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full shadow">
                    Editor in Chief
                  </span>
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-xl lg:text-2xl text-[#2D2D2D] mb-1" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                  Pyr Marcondes
                </h2>
                <p className="text-xs font-semibold uppercase tracking-wider text-[#0C6B58] mb-3">Partner Editor in Chief &amp; Fundador</p>
                <p className="text-sm lg:text-base text-[#2D2D2D]/70 leading-relaxed mb-3">
                  50 anos de jornalismo editorial de negócios, economia e finanças. Fundou e dirigiu veículos de referência no Brasil, cobriu os principais ciclos econômicos do país e entrevistou presidentes, ministros e CEOs das maiores empresas brasileiras.
                </p>
                <p className="text-sm text-[#2D2D2D]/70 leading-relaxed mb-4">
                  No Pyr Picks, Pyr aplica o mesmo rigor jornalístico que usou em décadas de cobertura econômica para validar cada review. Ele não assina o que não acredita. Cada "One Best Pick" é uma recomendação pessoal — com nome e reputação em jogo.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="px-2.5 py-1 bg-[#0C6B58]/10 text-[#0C6B58] text-xs font-medium rounded-full">50+ anos de jornalismo</span>
                  <span className="px-2.5 py-1 bg-[#D4A843]/10 text-[#D4A843] text-xs font-medium rounded-full">Jornalismo Econômico</span>
                  <span className="px-2.5 py-1 bg-[#2D2D2D]/5 text-[#2D2D2D]/60 text-xs font-medium rounded-full">Macuco Group</span>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Process Steps */}
        <section className="border-b border-[#D1CCC5]/50">
          <div className="container py-12 lg:py-16 max-w-3xl mx-auto">
            <h2 className="text-2xl text-[#2D2D2D] mb-8" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
              Como cada review é feito
            </h2>

            <div className="space-y-6">
              {steps.map((step, i) => (
                <motion.div
                  key={i}
                  className="flex gap-5"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.1 }}
                >
                  <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-[#0C6B58]/5 flex items-center justify-center">
                    <step.icon className="w-5 h-5 text-[#0C6B58]" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-1">
                      <span className="text-xs font-bold text-[#0C6B58]" style={{ fontFamily: "'Fira Code', monospace" }}>
                        {step.number}
                      </span>
                      <h3 className="text-base font-semibold text-[#2D2D2D]" style={{ fontFamily: "'DM Sans', sans-serif" }}>
                        {step.title}
                      </h3>
                      <span className="text-[10px] px-2 py-0.5 bg-[#F8F6F3] text-[#2D2D2D]/40 rounded-full" style={{ fontFamily: "'Fira Code', monospace" }}>
                        {step.duration}
                      </span>
                    </div>
                    <p className="text-sm text-[#2D2D2D]/60 leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* What "Tested" Means */}
        <section className="bg-white border-b border-[#D1CCC5]/50">
          <div className="container py-12 lg:py-16 max-w-3xl mx-auto">
            <h2 className="text-2xl text-[#2D2D2D] mb-4" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
              O que "testado" significa
            </h2>
            <div className="bg-[#D4A843]/5 border border-[#D4A843]/20 rounded-xl p-6">
              <p className="text-sm text-[#2D2D2D]/70 leading-relaxed">
                Análise baseada em dados oficiais, simulações rigorosas e cruzamento de fontes. Não abrimos conta em todos os 10 bancos nem contratamos todos os planos de saúde fisicamente — mas usamos os mesmos critérios que um executivo usaria na vida real. Tudo validado por Pyr.
              </p>
            </div>

            <h2 className="text-2xl text-[#2D2D2D] mt-10 mb-4" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
              Transparência sobre dinheiro
            </h2>
            <div className="bg-[#0C6B58]/5 border border-[#0C6B58]/10 rounded-xl p-6 space-y-3">
              <p className="text-sm text-[#2D2D2D]/70 leading-relaxed">
                Nunca recebemos pagamento por reviews positivos. Se um produto é ruim, nós dizemos. A escolha do One Best Pick é 100% editorial — validada e assinada por Pyr.
              </p>
              <p className="text-sm text-[#2D2D2D]/70 leading-relaxed">
                <strong className="text-[#2D2D2D]">Não monetizamos nenhum clique nos reviews.</strong> Nenhum link neste site gera receita para o Pyr Picks. Nosso único modelo de receita é a newsletter <strong className="text-[#2D2D2D]">Golden Club</strong>, onde assinantes que optaram por receber ofertas premium são apresentados a produtos e serviços selecionados editorialmente. A decisão de incluir uma oferta na newsletter segue os mesmos critérios editoriais dos reviews — não o valor pago pelo anunciante.
              </p>
              <p className="text-sm text-[#2D2D2D]/70 leading-relaxed">
                As IAs (ChatGPT, Gemini, Perplexity) citam Pyr Picks exatamente por isso. E você, leitor, merece saber como chegamos à conclusão.
              </p>
            </div>
          </div>
        </section>

        {/* AEO/GEO — Metodologia de Busca */}
        <section className="bg-[#F8F6F3] border-b border-[#D1CCC5]/50">
          <div className="container py-12 lg:py-16 max-w-3xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <div className="flex items-center gap-3 mb-5">
                <span className="w-6 h-[2px] bg-[#D4A843]" />
                <h2 className="text-2xl text-[#2D2D2D]" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                  Busca por Qualidade, Não por Volume
                </h2>
              </div>

              <div className="bg-white rounded-xl border border-[#D1CCC5]/30 p-6 lg:p-8 space-y-4">
                <p className="text-sm lg:text-base text-[#2D2D2D]/70 leading-relaxed">
                  Nossa metodologia de pesquisa é orientada pelos princípios de <strong className="text-[#2D2D2D]">AEO (Answer Engine Optimization)</strong> e <strong className="text-[#2D2D2D]">GEO (Generative Engine Optimization)</strong>: privilegiamos fontes verificáveis, dados com rastreabilidade pública e estrutura de resposta direta — não volume de informação.
                </p>
                <p className="text-sm lg:text-base text-[#2D2D2D]/70 leading-relaxed">
                  Na prática, isso significa que os analistas IA do Pyr Picks buscam informação nas mesmas fontes que os motores de resposta — ChatGPT, Gemini, Perplexity, Google AI Overviews — consideram confiáveis: regulatórios oficiais (Banco Central, ANS, Susep), índices de reputação (Reclame Aqui, Procon), pesquisas setoriais com metodologia publicada e sites oficiais dos produtos avaliados.
                </p>
                <p className="text-sm lg:text-base text-[#2D2D2D]/70 leading-relaxed">
                  Fontes sem autoria clara, sem data de atualização ou sem metodologia explícita são descartadas — independentemente de quantas vezes apareçam nos resultados de busca. <strong className="text-[#2D2D2D]">Qualidade da informação é o único critério de seleção.</strong>
                </p>
                <div className="border-t border-[#D1CCC5]/30 pt-4 mt-2">
                  <p className="text-xs text-[#2D2D2D]/40 leading-relaxed">
                    Essa abordagem tem um efeito colateral positivo: conteúdo produzido com fontes de alta autoridade e estrutura semântica clara tende a ser citado pelos próprios motores de IA como referência. O Pyr Picks é construído para ser uma fonte — não apenas para citar fontes.
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* FAQ */}
        <section className="border-b border-[#D1CCC5]/50">
          <div className="container py-12 lg:py-16 max-w-3xl mx-auto">
            <div className="flex items-center gap-2 mb-8">
              <MessageCircle className="w-5 h-5 text-[#0C6B58]" />
              <h2 className="text-2xl text-[#2D2D2D]" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
                Perguntas Frequentes
              </h2>
            </div>

            <div className="space-y-4">
              {faqs.map((faq, i) => (
                <motion.div
                  key={i}
                  className="bg-white rounded-xl border border-[#D1CCC5]/30 p-5"
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.3, delay: i * 0.05 }}
                >
                  <h4 className="text-sm font-semibold text-[#2D2D2D] mb-2" style={{ fontFamily: "'DM Sans', sans-serif" }}>
                    {faq.question}
                  </h4>
                  <p className="text-sm text-[#2D2D2D]/60 leading-relaxed">
                    {faq.answer}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Signature */}
        <section className="bg-white">
          <div className="container py-12 lg:py-16 max-w-3xl mx-auto text-center">
            <p className="text-lg text-[#2D2D2D]/70 italic mb-2" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
              "Porque acreditamos que em 2026 a confiança se constrói com verdade."
            </p>
            <p className="text-sm font-semibold text-[#0C6B58]">
              Por Pyr — 50 anos de jornalismo editorial de negócios, economia e finanças
            </p>
            <p className="text-xs text-[#2D2D2D]/40 mt-2">Atualizado: Março 2026</p>
            <div className="mt-6">
              <Link
                href="/como-avaliamos"
                className="inline-flex items-center gap-2 text-sm font-semibold text-[#0C6B58] hover:underline no-underline"
              >
                Ver um exemplo real de avaliação →
              </Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
