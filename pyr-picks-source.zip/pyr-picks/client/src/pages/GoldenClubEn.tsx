/**
 * Pyr Picks — Golden Club (English version)
 * Landing page for international readers and partners
 */
import { motion } from "framer-motion";
import { Star, Shield, Mail, TrendingUp, CheckCircle, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import GoldenClubForm from "@/components/GoldenClubForm";

const PYR_PHOTO = "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/pyr-marcondes-editor_53a6a2c4.jpeg";

const benefits = [
  {
    icon: TrendingUp,
    title: "Curated Premium Offers",
    description: "Negotiated directly by Pyr with selected partners. Never available to the general public.",
    color: "#D4A843",
  },
  {
    icon: Star,
    title: "Reviews First",
    description: "Receive analyses before they are published on the site. Be the first to know the One Best Pick.",
    color: "#0C6B58",
  },
  {
    icon: Shield,
    title: "Zero Conflict of Interest",
    description: "Offers arrive in the newsletter — never in the reviews. Editorial analysis is 100% independent of commercial offers.",
    color: "#1a5276",
  },
  {
    icon: Mail,
    title: "Respectful Frequency",
    description: "We send only when there is something genuinely relevant. No spam, no filler content, no sales pressure.",
    color: "#6a1b9a",
  },
];

const faq = [
  {
    question: "What is the Golden Club?",
    answer: "It is Pyr Picks' premium newsletter. Pyr Marcondes shares exclusive offers negotiated with selected partners — products and services that have passed the same editorial rigor as the reviews, but with special conditions for members.",
  },
  {
    question: "How does the Golden Club differ from the site's reviews?",
    answer: "Reviews are 100% editorial and independent — no click on them generates revenue for Pyr Picks. The Golden Club is the only monetization channel: offers arrive in the newsletter, never in editorial content. This separation is the guarantee of independence.",
  },
  {
    question: "How often is the newsletter sent?",
    answer: "We send only when there is something genuinely relevant for members. There is no fixed frequency — it may be weekly in periods of many developments, or bi-weekly when the market is quiet. We never send out of calendar obligation.",
  },
  {
    question: "How are offers selected?",
    answer: "Pyr negotiates directly with partners. The criterion is the same as the reviews: the product or service must be genuinely good for the executive profile of the reader. Partners who do not pass this criterion do not enter the newsletter, regardless of commercial value.",
  },
  {
    question: "Can I unsubscribe?",
    answer: "Yes, at any time. Every email has an unsubscribe link. There is no minimum membership period.",
  },
  {
    question: "Is my data shared with partners?",
    answer: "No. Your email is used exclusively to send the Pyr Picks newsletter. We do not share, sell or transfer member data to third parties — in compliance with Brazil's LGPD (data protection law).",
  },
];

export default function GoldenClubEn() {
  return (
    <div className="min-h-screen flex flex-col bg-[#F8F6F3]">
      {/* Minimal header for international page */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-[#D1CCC5]/50">
        <div className="container flex items-center justify-between py-3 lg:py-4">
          <Link href="/" className="flex items-center gap-2 no-underline flex-shrink-0">
            <div className="flex flex-col">
              <span
                className="text-xl md:text-2xl tracking-tight leading-tight"
                style={{ fontFamily: "'DM Serif Display', Georgia, serif", color: "#0C6B58" }}
              >
                Pyr Picks
              </span>
              <span className="text-[9px] font-semibold uppercase tracking-[0.2em] text-[#D4A843]">
                Premium Reviews
              </span>
            </div>
          </Link>
          <Link
            href="/golden-club"
            className="text-xs text-[#2D2D2D]/50 hover:text-[#2D2D2D] transition-colors no-underline"
          >
            Ver em Português →
          </Link>
        </div>
      </header>

      <main className="flex-1">

        {/* Hero */}
        <section className="relative overflow-hidden bg-gradient-to-br from-[#2D2D2D] via-[#1a1a1a] to-[#0C6B58]">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-[#D4A843] blur-3xl" />
            <div className="absolute bottom-0 left-0 w-64 h-64 rounded-full bg-[#0C6B58] blur-3xl" />
          </div>
          <div className="container relative py-16 lg:py-24">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
              >
                <div className="flex items-center gap-2 mb-4">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#D4A843]/20 border border-[#D4A843]/30 rounded-full text-xs font-bold uppercase tracking-[0.2em] text-[#D4A843]">
                    <Star className="w-3 h-3" />
                    Premium Newsletter
                  </span>
                </div>
                <h1
                  className="text-4xl lg:text-5xl text-white mb-4 leading-tight"
                  style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
                >
                  Golden Club
                </h1>
                <p className="text-xl text-white/70 mb-2 font-medium">
                  Pyr Picks' premium offers newsletter.
                </p>
                <p className="text-base text-white/50 mb-8 leading-relaxed">
                  Exclusive offers negotiated by Pyr Marcondes with selected partners.
                  Never available to the general public. Sent only when there is something genuinely relevant.
                </p>

                <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-6">
                  <p className="text-sm text-white/70 mb-4 font-medium">Subscribe for free:</p>
                  <GoldenClubForm source="golden-club-en" />
                  <p className="text-xs text-white/40 mt-3">
                    No spam. Cancel anytime. Your data is never shared.
                  </p>
                </div>
              </motion.div>

              <motion.div
                className="hidden lg:flex flex-col gap-6"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                {/* Pyr's letter */}
                <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6">
                  <div className="flex items-start gap-4 mb-4">
                    <img
                      src={PYR_PHOTO}
                      alt="Pyr Marcondes"
                      className="w-14 h-14 rounded-full object-cover border-2 border-[#D4A843]/50"
                    />
                    <div>
                      <p className="text-white font-semibold text-sm">Pyr Marcondes</p>
                      <p className="text-white/50 text-xs">Editor-in-Chief, Pyr Picks</p>
                      <p className="text-white/40 text-xs">50 years of business, economics and finance journalism</p>
                    </div>
                  </div>
                  <blockquote className="text-white/70 text-sm leading-relaxed italic border-l-2 border-[#D4A843]/50 pl-4">
                    "The Golden Club was born from a simple conviction: those who read Pyr Picks deserve offers as rigorous as our analyses. Only what I would use myself enters the newsletter — and what I can defend with the same editorial standard as the reviews."
                  </blockquote>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-white/5 border border-white/10 rounded-xl p-4 text-center">
                    <p className="text-2xl font-bold text-[#D4A843]">22</p>
                    <p className="text-xs text-white/50 mt-1">Reviews published</p>
                  </div>
                  <div className="bg-white/5 border border-white/10 rounded-xl p-4 text-center">
                    <p className="text-2xl font-bold text-[#D4A843]">8</p>
                    <p className="text-xs text-white/50 mt-1">AI Analysts</p>
                  </div>
                  <div className="bg-white/5 border border-white/10 rounded-xl p-4 text-center">
                    <p className="text-2xl font-bold text-[#D4A843]">0%</p>
                    <p className="text-xs text-white/50 mt-1">Payola in reviews</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* What you receive */}
        <section className="bg-white border-t border-[#D1CCC5]/50">
          <div className="container py-12 lg:py-16">
            <div className="text-center mb-10">
              <h2
                className="text-2xl lg:text-3xl text-[#2D2D2D] mb-3"
                style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
              >
                What you receive in the Golden Club
              </h2>
              <p className="text-[#2D2D2D]/60 text-base max-w-xl mx-auto">
                A newsletter that respects your time and intelligence.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {benefits.map((benefit, i) => (
                <motion.div
                  key={i}
                  className="bg-[#F8F6F3] rounded-xl p-6 border border-[#D1CCC5]/30"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.1 }}
                >
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center mb-4"
                    style={{ backgroundColor: `${benefit.color}15` }}
                  >
                    <benefit.icon className="w-5 h-5" style={{ color: benefit.color }} />
                  </div>
                  <h3 className="text-sm font-bold text-[#2D2D2D] mb-2">{benefit.title}</h3>
                  <p className="text-xs text-[#2D2D2D]/60 leading-relaxed">{benefit.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* The editorial separation */}
        <section className="bg-gradient-to-br from-[#0C6B58]/5 to-[#D4A843]/5 border-t border-[#D1CCC5]/50">
          <div className="container py-12 lg:py-16">
            <div className="max-w-3xl mx-auto">
              <div className="flex items-center gap-3 mb-6">
                <Shield className="w-6 h-6 text-[#0C6B58]" />
                <h2
                  className="text-xl lg:text-2xl text-[#2D2D2D]"
                  style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
                >
                  The Separation That Guarantees Independence
                </h2>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-white rounded-xl p-6 border border-[#D1CCC5]/30">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-6 h-6 rounded-full bg-[#0C6B58]/10 flex items-center justify-center">
                      <CheckCircle className="w-4 h-4 text-[#0C6B58]" />
                    </div>
                    <span className="text-sm font-bold text-[#0C6B58] uppercase tracking-wider">Site Reviews</span>
                  </div>
                  <ul className="space-y-2 text-sm text-[#2D2D2D]/70">
                    <li className="flex items-start gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#0C6B58] mt-2 flex-shrink-0" />
                      100% editorial and independent
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#0C6B58] mt-2 flex-shrink-0" />
                      No click generates revenue for Pyr Picks
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#0C6B58] mt-2 flex-shrink-0" />
                      One Best Pick chosen exclusively on merit
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#0C6B58] mt-2 flex-shrink-0" />
                      Commercial partners do not influence analyses
                    </li>
                  </ul>
                </div>

                <div className="bg-white rounded-xl p-6 border border-[#D4A843]/30">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-6 h-6 rounded-full bg-[#D4A843]/10 flex items-center justify-center">
                      <Star className="w-4 h-4 text-[#D4A843]" />
                    </div>
                    <span className="text-sm font-bold text-[#D4A843] uppercase tracking-wider">Golden Club</span>
                  </div>
                  <ul className="space-y-2 text-sm text-[#2D2D2D]/70">
                    <li className="flex items-start gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#D4A843] mt-2 flex-shrink-0" />
                      Pyr Picks' only monetization channel
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#D4A843] mt-2 flex-shrink-0" />
                      Offers negotiated directly by Pyr
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#D4A843] mt-2 flex-shrink-0" />
                      Only products that pass editorial rigor
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#D4A843] mt-2 flex-shrink-0" />
                      Sent only when there is something genuinely relevant
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section className="bg-white border-t border-[#D1CCC5]/50">
          <div className="container py-12 lg:py-16">
            <div className="max-w-3xl mx-auto">
              <h2
                className="text-2xl lg:text-3xl text-[#2D2D2D] mb-8 text-center"
                style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
              >
                Frequently Asked Questions
              </h2>
              <div className="space-y-4">
                {faq.map((item, i) => (
                  <motion.div
                    key={i}
                    className="border border-[#D1CCC5]/50 rounded-xl p-5"
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.3, delay: i * 0.05 }}
                  >
                    <h3 className="text-sm font-bold text-[#2D2D2D] mb-2">{item.question}</h3>
                    <p className="text-sm text-[#2D2D2D]/60 leading-relaxed">{item.answer}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Final CTA */}
        <section className="bg-gradient-to-br from-[#2D2D2D] to-[#0C6B58]">
          <div className="container py-12 lg:py-16">
            <div className="max-w-xl mx-auto text-center">
              <Star className="w-8 h-8 text-[#D4A843] mx-auto mb-4" />
              <h2
                className="text-2xl lg:text-3xl text-white mb-3"
                style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}
              >
                Join the Golden Club
              </h2>
              <p className="text-white/60 text-sm mb-6">
                Free. No spam. Cancel anytime.
              </p>
              <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-6">
                <GoldenClubForm source="golden-club-en-cta" />
              </div>
              <div className="mt-6 flex items-center justify-center gap-4 text-xs text-white/40">
                <Link href="/politica-de-privacidade" className="hover:text-white/60 transition-colors no-underline">
                  Privacy Policy (PT)
                </Link>
                <span>·</span>
                <Link href="/termos-de-uso" className="hover:text-white/60 transition-colors no-underline">
                  Terms of Use (PT)
                </Link>
                <span>·</span>
                <Link href="/golden-club" className="hover:text-white/60 transition-colors no-underline flex items-center gap-1">
                  Ver em Português <ArrowRight className="w-3 h-3" />
                </Link>
              </div>
            </div>
          </div>
        </section>

      </main>

      <footer className="bg-[#2D2D2D] border-t border-white/10">
        <div className="container py-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <span className="text-xs text-white/30">
            © 2026 Pyr Picks by Macuco GROUP. All rights reserved.
          </span>
          <Link href="/" className="text-xs text-white/40 hover:text-white/60 transition-colors no-underline">
            ← Back to Pyr Picks
          </Link>
        </div>
      </footer>
    </div>
  );
}
