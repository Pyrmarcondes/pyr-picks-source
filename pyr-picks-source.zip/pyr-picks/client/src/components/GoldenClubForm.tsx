import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Check, Mail, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';

interface GoldenClubFormProps {
  source?: string;
  compact?: boolean;
}

export default function GoldenClubForm({ source = "homepage", compact = false }: GoldenClubFormProps) {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const subscribeMutation = trpc.goldenClub.subscribe.useMutation({
    onSuccess: (data) => {
      setSubmitted(true);
      setEmail('');
      if (data.alreadyExists) {
        toast.info('Você já está no Golden Club! Fique atento ao seu e-mail.');
      } else {
        toast.success('Bem-vindo ao Golden Club! Confira seu e-mail em breve.');
      }
    },
    onError: (err) => {
      toast.error(err.message || 'Erro ao se inscrever. Tente novamente.');
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      toast.error('Por favor, insira um e-mail válido');
      return;
    }
    subscribeMutation.mutate({ email, source });
  };

  if (submitted) {
    return (
      <div className="w-full">
        <div className="bg-gradient-to-br from-[#0C6B58]/10 to-[#0C6B58]/5 border border-[#0C6B58]/20 rounded-xl p-4 text-center">
          <div className="w-10 h-10 rounded-full bg-[#0C6B58]/20 flex items-center justify-center mx-auto mb-2">
            <Check className="w-5 h-5 text-[#0C6B58]" />
          </div>
          <p className="text-sm font-semibold text-[#2D2D2D]">Inscrição confirmada!</p>
          <p className="text-xs text-[#2D2D2D]/60 mt-1">Você receberá deals exclusivos em breve.</p>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="w-full">
      <div className={`flex ${compact ? 'flex-row' : 'flex-col sm:flex-row'} gap-2`}>
        <div className="relative flex-1">
          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#2D2D2D]/40" />
          <Input
            type="email"
            placeholder="seu@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="pl-9 bg-white border-[#D1CCC5]/50 text-[#2D2D2D] placeholder:text-[#2D2D2D]/40 focus:border-[#0C6B58] focus:ring-[#0C6B58]/20"
            disabled={subscribeMutation.isPending}
          />
        </div>
        <Button
          type="submit"
          disabled={subscribeMutation.isPending}
          className="bg-[#D4A843] hover:bg-[#D4A843]/90 text-[#2D2D2D] font-semibold whitespace-nowrap"
        >
          {subscribeMutation.isPending ? (
            <><Loader2 className="w-4 h-4 animate-spin mr-1" />Inscrevendo...</>
          ) : 'Entrar no Club'}
        </Button>
      </div>
      {!compact && (
        <p className="text-[10px] text-[#2D2D2D]/50 mt-2">
          Deals exclusivos, newsletter premium e benefícios negociados por Pyr. Sem spam.
        </p>
      )}
    </form>
  );
}
