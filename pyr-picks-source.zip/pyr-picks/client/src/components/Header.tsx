/*
 * Design: "Curated Intelligence" — Sofisticação Discreta com DNA Digital
 * Header: Logo serifada + navegação por categorias + busca funcional
 * Paleta: teal (#0C6B58), âmbar (#D4A843), fundo cream (#F8F6F3)
 */
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Search, Menu, X, ChevronRight, Bot, BookOpen, Star } from "lucide-react";

const categories = [
  { label: "Finanças", href: "/categoria/financas" },
  { label: "Saúde", href: "/categoria/saude" },
  { label: "Seguros", href: "/categoria/seguros" },
  { label: "Viagens", href: "/categoria/viagens" },
  { label: "Streaming", href: "/categoria/streaming" },
  { label: "ESG", href: "/categoria/esg" },
  { label: "Fintechs", href: "/categoria/fintechs" },
  { label: "Internacional", href: "/categoria/internacional" },
];

export default function Header() {
  const [location, navigate] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const q = searchQuery.trim();
    if (!q) return;
    navigate(`/busca?q=${encodeURIComponent(q)}`);
    setSearchQuery("");
    setSearchOpen(false);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-[#D1CCC5]/50">
      {/* Top bar */}
      <div className="container flex items-center justify-between py-3 lg:py-4">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 no-underline flex-shrink-0">
          <div className="flex flex-col">
            <div className="flex items-baseline gap-1.5">
              <span
                className="text-xl md:text-2xl lg:text-3xl tracking-tight leading-tight"
                style={{ fontFamily: "'DM Serif Display', Georgia, serif", color: "#0C6B58" }}
              >
                Pyr Picks
              </span>
              <span className="text-[7px] md:text-[8px] lg:text-[9px] font-bold uppercase tracking-[0.2em] text-[#D4A843] bg-[#D4A843]/10 px-1.5 py-0.5 rounded-full">
                Premium Reviews
              </span>
            </div>
            <span className="text-[8px] md:text-[9px] lg:text-xs tracking-[0.15em] uppercase text-[#2D2D2D]/60 font-medium">
              by Macuco GROUP
            </span>
          </div>
        </Link>

        {/* Search bar - desktop */}
        <form onSubmit={handleSearch} className="hidden lg:flex items-center flex-1 max-w-sm mx-6">
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#2D2D2D]/40" />
            <input
              type="text"
              placeholder="Buscar reviews..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-[#F8F6F3] border border-[#D1CCC5] rounded-lg text-sm text-[#2D2D2D] placeholder:text-[#2D2D2D]/40 focus:outline-none focus:border-[#0C6B58] focus:ring-1 focus:ring-[#0C6B58]/20 transition-all"
            />
          </div>
        </form>

        {/* Right actions */}
        <div className="flex items-center gap-2 lg:gap-3">
          <button
            onClick={() => setSearchOpen(!searchOpen)}
            className="lg:hidden p-2 text-[#2D2D2D]/60 hover:text-[#0C6B58] transition-colors"
          >
            <Search className="w-4 h-4" />
          </button>
          <Link
            href="/bots"
            className="hidden lg:flex items-center gap-1.5 text-xs font-semibold text-white bg-[#0C6B58] hover:bg-[#0C6B58]/90 px-3 py-1.5 rounded-full transition-colors no-underline"
          >
            <Bot className="w-3.5 h-3.5" />
            Fale com IA
          </Link>
          <Link
            href="/guias"
            className="hidden lg:flex items-center gap-1.5 text-xs font-semibold text-[#D4A843] bg-[#D4A843]/10 hover:bg-[#D4A843]/20 px-3 py-1.5 rounded-full transition-colors no-underline border border-[#D4A843]/30"
          >
            <BookOpen className="w-3.5 h-3.5" />
            Guias Sem Fim
          </Link>
          <Link
            href="/como-fazemos"
            className="hidden xl:flex items-center gap-1 text-xs font-medium tracking-wide uppercase text-[#0C6B58] hover:text-[#0C6B58]/80 transition-colors no-underline"
          >
            IA + H
            <ChevronRight className="w-3 h-3" />
          </Link>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-[#2D2D2D]/60 hover:text-[#0C6B58] transition-colors"
          >
            {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Mobile search */}
      {searchOpen && (
        <form onSubmit={handleSearch} className="lg:hidden px-4 pb-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#2D2D2D]/40" />
            <input
              type="text"
              placeholder="Buscar reviews..."
              autoFocus
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-[#F8F6F3] border border-[#D1CCC5] rounded-lg text-sm text-[#2D2D2D] placeholder:text-[#2D2D2D]/40 focus:outline-none focus:border-[#0C6B58] focus:ring-1 focus:ring-[#0C6B58]/20"
            />
          </div>
        </form>
      )}

      {/* Category navigation - desktop */}
      <nav className="hidden lg:block border-t border-[#D1CCC5]/50">
        <div className="container flex items-center gap-0 py-0 overflow-x-auto">
          {categories.map((cat) => (
            <Link
              key={cat.href}
              href={cat.href}
              className={`px-3 lg:px-4 py-2.5 lg:py-3 text-xs lg:text-sm font-medium transition-colors no-underline relative whitespace-nowrap ${
                location === cat.href
                  ? "text-[#0C6B58]"
                  : "text-[#2D2D2D]/70 hover:text-[#0C6B58]"
              }`}
            >
              {cat.label}
              {location === cat.href && (
                <span className="absolute bottom-0 left-3 lg:left-4 right-3 lg:right-4 h-[2px] bg-[#0C6B58]" />
              )}
            </Link>
          ))}
        </div>
      </nav>

      {/* Disclaimer banner */}
      <div className="border-t border-[#D1CCC5]/50 bg-[#F8F6F3]">
        <div className="container py-2 lg:py-2.5 flex flex-col lg:flex-row items-center justify-center gap-1.5 lg:gap-2 text-[10px] lg:text-xs text-[#2D2D2D]/60">
          <span className="inline-flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#0C6B58]/60 flex-shrink-0" />
            <span className="text-center lg:text-left">Análises independentes. 100% editorial.</span>
          </span>
          <Link
            href="/como-fazemos"
            className="text-[#0C6B58] font-medium hover:underline no-underline whitespace-nowrap"
          >
            Modelo IA + H
          </Link>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-[#D1CCC5]/50 bg-white">
          <nav className="container py-3 flex flex-col gap-1">
            {categories.map((cat) => (
              <Link
                key={cat.href}
                href={cat.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`px-3 py-2.5 rounded-lg text-xs lg:text-sm font-medium transition-colors no-underline ${
                  location === cat.href
                    ? "bg-[#0C6B58]/5 text-[#0C6B58]"
                    : "text-[#2D2D2D]/70 hover:bg-[#F8F6F3]"
                }`}
              >
                {cat.label}
              </Link>
            ))}
            <Link
              href="/guias"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2.5 rounded-lg text-xs lg:text-sm font-semibold text-[#D4A843] bg-[#D4A843]/10 hover:bg-[#D4A843]/20 transition-colors no-underline flex items-center gap-2 border border-[#D4A843]/30"
            >
              <BookOpen className="w-4 h-4" />
              Guias Sem Fim
            </Link>
            <Link
              href="/bots"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2.5 rounded-lg text-xs lg:text-sm font-medium text-white bg-[#0C6B58] hover:bg-[#0C6B58]/90 transition-colors no-underline flex items-center gap-2"
            >
              <Bot className="w-4 h-4" />
              Fale com Analista IA
            </Link>
            <Link
              href="/sobre"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2.5 rounded-lg text-xs lg:text-sm font-medium text-[#2D2D2D]/70 hover:bg-[#F8F6F3] transition-colors no-underline flex items-center gap-1"
            >
              Quem é Pyr
              <ChevronRight className="w-3 h-3" />
            </Link>
            <Link
              href="/golden-club"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2.5 rounded-lg text-xs lg:text-sm font-semibold text-[#2D2D2D] bg-[#D4A843]/15 hover:bg-[#D4A843]/25 transition-colors no-underline flex items-center gap-2 border border-[#D4A843]/30"
            >
              <Star className="w-4 h-4 text-[#D4A843]" />
              Golden Club Newsletter
            </Link>
            <Link
              href="/como-fazemos"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2.5 rounded-lg text-xs lg:text-sm font-medium text-[#0C6B58] hover:bg-[#0C6B58]/5 transition-colors no-underline flex items-center gap-1"
            >
              Como Fazemos (IA + H)
              <ChevronRight className="w-3 h-3" />
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
