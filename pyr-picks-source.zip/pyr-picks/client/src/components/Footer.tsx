/*
 * Design: "Curated Intelligence"
 * Footer: Links institucionais, disclaimer completo, newsletter signup funcional
 */
import { Link } from "wouter";
import GoldenClubForm from "@/components/GoldenClubForm";

export default function Footer() {
  return (
    <footer className="bg-[#2D2D2D] text-white/80">
      {/* Newsletter section — usa GoldenClubForm real */}
      <div className="border-b border-white/10">
        <div className="container py-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <h3 className="text-xl text-white mb-1" style={{ fontFamily: "'DM Serif Display', Georgia, serif" }}>
              Pyr Picks Weekly
            </h3>
            <p className="text-sm text-white/50">
              Os melhores deals e reviews da semana, direto no seu e-mail. Grátis.
            </p>
          </div>
          {/* GoldenClubForm com override de estilos para fundo escuro */}
          <div className="w-full md:w-96 [&_input]:bg-white/10 [&_input]:border-white/20 [&_input]:text-white [&_input]:placeholder:text-white/30 [&_input:focus]:border-[#0C6B58]">
            <GoldenClubForm source="footer" />
          </div>
        </div>
      </div>

      {/* Links grid */}
      <div className="container py-10 grid grid-cols-2 md:grid-cols-4 gap-8">
        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wider text-white/40 mb-4" style={{ fontFamily: "'DM Sans', sans-serif" }}>
            Categorias
          </h4>
          <ul className="space-y-2.5">
            {[
              ["Finanças", "/categoria/financas"],
              ["Saúde", "/categoria/saude"],
              ["Seguros", "/categoria/seguros"],
              ["Viagens", "/categoria/viagens"],
              ["Streaming", "/categoria/streaming"],
              ["Guias Sem Fim", "/guias"],
            ].map(([item, href]) => (
              <li key={item}>
                <Link href={href} className="text-sm text-white/60 hover:text-white transition-colors no-underline">
                  {item}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wider text-white/40 mb-4" style={{ fontFamily: "'DM Sans', sans-serif" }}>
            Sobre
          </h4>
          <ul className="space-y-2.5">
            <li><Link href="/como-fazemos" className="text-sm text-white/60 hover:text-white transition-colors no-underline">Como Fazemos (IA + H)</Link></li>
            <li><Link href="/equipe" className="text-sm text-white/60 hover:text-white transition-colors no-underline">Equipe de Analistas IA</Link></li>
            <li><Link href="/sobre" className="text-sm text-white/60 hover:text-white transition-colors no-underline">Quem é Pyr</Link></li>
            <li>
              <a
                href="https://macuco.group"
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-white/60 hover:text-white transition-colors no-underline"
              >
                Macuco GROUP ↗
              </a>
            </li>
          </ul>
        </div>
        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wider text-white/40 mb-4" style={{ fontFamily: "'DM Sans', sans-serif" }}>
            Transparência
          </h4>
          <ul className="space-y-2.5">
            <li><Link href="/como-fazemos" className="text-sm text-white/60 hover:text-white transition-colors no-underline">Metodologia</Link></li>
            <li><Link href="/como-avaliamos" className="text-sm text-white/60 hover:text-white transition-colors no-underline">Como Avaliamos</Link></li>
            <li><Link href="/politica-de-privacidade" className="text-sm text-white/60 hover:text-white transition-colors no-underline">Política de Privacidade</Link></li>
            <li><Link href="/termos-de-uso" className="text-sm text-white/60 hover:text-white transition-colors no-underline">Termos de Uso</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wider text-white/40 mb-4" style={{ fontFamily: "'DM Sans', sans-serif" }}>
            Parcerias
          </h4>
          <ul className="space-y-2.5">
            <li>
              <Link href="/golden-club" className="text-sm text-white/60 hover:text-white transition-colors no-underline">
                Golden Club Newsletter
              </Link>
            </li>
            <li>
              <Link href="/anunciantes" className="text-sm text-white/60 hover:text-white transition-colors no-underline">
                Para Anunciantes
              </Link>
            </li>
            <li>
              <a
                href="mailto:pyr@macuco.digital"
                className="text-sm text-white/60 hover:text-white transition-colors no-underline"
              >
                pyr@macuco.digital
              </a>
            </li>
            <li>
              <a
                href="mailto:pyr@macuco.digital"
                className="text-sm text-white/60 hover:text-white transition-colors no-underline"
              >
                Contato Geral
              </a>
            </li>
          </ul>
        </div>
      </div>

      {/* Bottom disclaimer */}
      <div className="border-t border-white/10">
        <div className="container py-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex flex-col gap-1">
            <span className="text-xs text-white/30">
              &copy; 2026 Pyr Picks by Macuco GROUP. Todos os direitos reservados.
            </span>
            <span className="text-[11px] text-white/20 max-w-xl">
              Pyr Picks utiliza IA (Macuco Content Studio) para pesquisa e rascunhos, com curadoria final humana de Pyr. 100% editorial.
            </span>
          </div>
          <div className="flex flex-col items-end gap-1">
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] uppercase tracking-wider text-white/20">Powered by</span>
              <span className="text-xs font-medium text-[#0C6B58]">Macuco GROUP</span>
            </div>
            <span className="text-[9px] text-white/10">50 anos de jornalismo editorial de negócios, economia e finanças</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
