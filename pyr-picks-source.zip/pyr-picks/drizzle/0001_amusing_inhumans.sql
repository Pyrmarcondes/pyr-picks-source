CREATE TABLE `golden_club_subscribers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`name` varchar(255),
	`source` varchar(64) DEFAULT 'homepage',
	`confirmed` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `golden_club_subscribers_id` PRIMARY KEY(`id`),
	CONSTRAINT `golden_club_subscribers_email_unique` UNIQUE(`email`)
);
