CREATE TABLE `guide_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`guideId` int NOT NULL,
	`entryNumber` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`content` text NOT NULL,
	`tip` text,
	`requestedByUserId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `guide_entries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `guide_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`guideId` int NOT NULL,
	`weekKey` varchar(16) NOT NULL,
	`requestCount` int NOT NULL DEFAULT 1,
	`lastRequestAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `guide_requests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `guides` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(64) NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text NOT NULL,
	`analystId` varchar(64) NOT NULL,
	`analystName` varchar(128) NOT NULL,
	`analystAvatar` text NOT NULL,
	`coverImage` text NOT NULL,
	`color` varchar(16) NOT NULL DEFAULT '#0C6B58',
	`totalEntries` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `guides_id` PRIMARY KEY(`id`),
	CONSTRAINT `guides_slug_unique` UNIQUE(`slug`)
);
