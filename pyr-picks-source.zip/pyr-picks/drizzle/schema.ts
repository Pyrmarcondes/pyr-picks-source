import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** Golden Club — captura de leads para newsletter premium */
export const goldenClubSubscribers = mysqlTable("golden_club_subscribers", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  source: varchar("source", { length: 64 }).default("homepage"), // homepage, review, bots, etc.
  confirmed: boolean("confirmed").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type GoldenClubSubscriber = typeof goldenClubSubscribers.$inferSelect;
export type InsertGoldenClubSubscriber = typeof goldenClubSubscribers.$inferInsert;

/** Guias Sem Fim — definição de cada guia */
export const guides = mysqlTable("guides", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 64 }).notNull().unique(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  analystId: varchar("analystId", { length: 64 }).notNull(), // ex: ana-financas
  analystName: varchar("analystName", { length: 128 }).notNull(),
  analystAvatar: text("analystAvatar").notNull(),
  coverImage: text("coverImage").notNull(),
  color: varchar("color", { length: 16 }).notNull().default("#0C6B58"),
  totalEntries: int("totalEntries").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Guide = typeof guides.$inferSelect;
export type InsertGuide = typeof guides.$inferInsert;

/** Guias Sem Fim — cada dica/entrada gerada por IA */
export const guideEntries = mysqlTable("guide_entries", {
  id: int("id").autoincrement().primaryKey(),
  guideId: int("guideId").notNull(),
  entryNumber: int("entryNumber").notNull(), // sequência dentro do guia
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(), // markdown
  tip: text("tip"), // dica prática resumida (1 linha)
  requestedByUserId: int("requestedByUserId"), // null = substrato inicial
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type GuideEntry = typeof guideEntries.$inferSelect;
export type InsertGuideEntry = typeof guideEntries.$inferInsert;

/** Guias Sem Fim — controle de requests por usuário por semana */
export const guideRequests = mysqlTable("guide_requests", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  guideId: int("guideId").notNull(),
  weekKey: varchar("weekKey", { length: 16 }).notNull(), // ex: "2026-W12"
  requestCount: int("requestCount").default(1).notNull(),
  lastRequestAt: timestamp("lastRequestAt").defaultNow().notNull(),
});

export type GuideRequest = typeof guideRequests.$inferSelect;
export type InsertGuideRequest = typeof guideRequests.$inferInsert;
