/**
 * Sitemap XML dinâmico para o Pyr Picks
 * Inclui: páginas estáticas, reviews, categorias, perfis de analistas e guias do banco
 */
import { Router } from "express";
import { getAllGuides } from "./db";

const DOMAIN = "https://pyrpicks-eoegx4rq.manus.space";

// IDs estáticos dos reviews (mantidos em sync com client/src/lib/reviews.ts)
const REVIEW_IDS = [
  "melhor-conta-digital-premium-2026",
  "melhor-plano-saude-executivo-2026",
  "melhor-seguro-residencial-2026",
  "melhor-passagem-aerea-premium-2026",
  "melhor-servico-streaming-2026",
  "melhor-hotel-luxo-brasil-2026",
  "melhor-cartao-milhas-viagem-2026",
  "melhor-combo-streaming-musica-2026",
  "melhor-plataforma-games-streaming-2026",
  "melhores-fundos-esg-brasil-2026",
  "melhor-fintech-conta-pj-2026",
  "melhor-etf-internacional-2026",
  "melhor-plataforma-open-banking-2026",
  "melhores-creditos-carbono-brasil-2026",
  "melhor-conta-internacional-brasileiros-2026",
  // Onda 1
  "melhor-cartao-credito-premium-2026",
  "melhor-seguro-auto-premium-2026",
  "melhor-viagem-turismo-luxo-2026",
  "melhor-combo-streaming-entretenimento-2026",
  "melhor-saas-ferramentas-executivos-2026",
  "melhor-investimento-imobiliario-premium-2026",
  "melhor-mba-educacao-executiva-2026",
];

const CATEGORIES = [
  "financas",
  "saude",
  "seguros",
  "viagens",
  "streaming",
  "esg",
  "fintechs",
  "internacional",
];

const ANALYST_IDS = [
  "ana-financas",
  "dr-lucas-saude",
  "clara-seguros",
  "rafael-viagens",
  "sofia-streaming",
  "mei-chen",
  "kenji-tanaka",
  "araci-esg",
];

const STATIC_PAGES = [
  { path: "/", priority: "1.0", changefreq: "daily" },
  { path: "/como-fazemos", priority: "0.8", changefreq: "monthly" },
  { path: "/equipe", priority: "0.7", changefreq: "monthly" },
  { path: "/sobre", priority: "0.7", changefreq: "monthly" },
  { path: "/guias", priority: "0.8", changefreq: "weekly" },
  { path: "/bots", priority: "0.6", changefreq: "monthly" },
  { path: "/politica-de-privacidade", priority: "0.3", changefreq: "yearly" },
  { path: "/termos-de-uso", priority: "0.3", changefreq: "yearly" },
];

function urlEntry(
  loc: string,
  priority: string = "0.6",
  changefreq: string = "monthly",
  lastmod?: string
): string {
  const today = lastmod ?? new Date().toISOString().split("T")[0];
  return `  <url>
    <loc>${loc}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>${changefreq}</changefreq>
    <priority>${priority}</priority>
  </url>`;
}

export function registerSitemapRoute(app: Router) {
  app.get("/sitemap.xml", async (_req, res) => {
    try {
      const entries: string[] = [];

      // Páginas estáticas
      for (const page of STATIC_PAGES) {
        entries.push(urlEntry(`${DOMAIN}${page.path}`, page.priority, page.changefreq));
      }

      // Reviews
      for (const id of REVIEW_IDS) {
        entries.push(urlEntry(`${DOMAIN}/review/${id}`, "0.9", "weekly"));
      }

      // Categorias
      for (const cat of CATEGORIES) {
        entries.push(urlEntry(`${DOMAIN}/categoria/${cat}`, "0.7", "weekly"));
      }

      // Perfis de analistas
      for (const id of ANALYST_IDS) {
        entries.push(urlEntry(`${DOMAIN}/colunista/${id}`, "0.6", "monthly"));
      }

      // Guias dinâmicos do banco
      try {
        const guides = await getAllGuides();
        for (const guide of guides) {
          entries.push(urlEntry(`${DOMAIN}/guias/${guide.slug}`, "0.8", "daily"));
        }
      } catch {
        // Se o banco não estiver disponível, omite os guias dinâmicos
      }

      const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${entries.join("\n")}
</urlset>`;

      res.setHeader("Content-Type", "application/xml; charset=utf-8");
      res.setHeader("Cache-Control", "public, max-age=3600"); // cache 1h
      res.send(xml);
    } catch (err) {
      console.error("[Sitemap] Error generating sitemap:", err);
      res.status(500).send("Error generating sitemap");
    }
  });
}
