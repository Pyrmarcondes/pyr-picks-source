import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, InsertGoldenClubSubscriber, goldenClubSubscribers, users, guides, guideEntries, guideRequests, InsertGuide, InsertGuideEntry } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ─── Guias Sem Fim ────────────────────────────────────────────────────────────

/** Retorna todos os guias para a listagem */
export async function getAllGuides() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(guides).orderBy(guides.id);
}

/** Retorna um guia pelo slug */
export async function getGuideBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(guides).where(eq(guides.slug, slug)).limit(1);
  return result[0] ?? undefined;
}

/** Retorna todas as entradas de um guia em ordem cronológica */
export async function getGuideEntries(guideId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(guideEntries)
    .where(eq(guideEntries.guideId, guideId))
    .orderBy(guideEntries.entryNumber);
}

/** Insere uma nova entrada no guia e incrementa totalEntries */
export async function insertGuideEntry(entry: InsertGuideEntry) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(guideEntries).values(entry);
  await db
    .update(guides)
    .set({ totalEntries: (await getGuideEntries(entry.guideId)).length })
    .where(eq(guides.id, entry.guideId));
}

/** Retorna a chave ISO da semana atual: ex. "2026-W12" */
export function currentWeekKey(): string {
  const now = new Date();
  const year = now.getUTCFullYear();
  const start = new Date(Date.UTC(year, 0, 1));
  const diff = now.getTime() - start.getTime();
  const week = Math.ceil((diff / 86400000 + start.getUTCDay() + 1) / 7);
  return `${year}-W${String(week).padStart(2, "0")}`;
}

/** Quantos requests o usuário fez neste guia nesta semana */
export async function getUserWeeklyRequestCount(
  userId: number,
  guideId: number
): Promise<number> {
  const db = await getDb();
  if (!db) return 0;
  const weekKey = currentWeekKey();
  const result = await db
    .select()
    .from(guideRequests)
    .where(
      and(
        eq(guideRequests.userId, userId),
        eq(guideRequests.guideId, guideId),
        eq(guideRequests.weekKey, weekKey)
      )
    )
    .limit(1);
  return result[0]?.requestCount ?? 0;
}

/** Incrementa (ou cria) o contador de requests do usuário nesta semana */
export async function incrementUserWeeklyRequest(
  userId: number,
  guideId: number
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const weekKey = currentWeekKey();
  const existing = await db
    .select()
    .from(guideRequests)
    .where(
      and(
        eq(guideRequests.userId, userId),
        eq(guideRequests.guideId, guideId),
        eq(guideRequests.weekKey, weekKey)
      )
    )
    .limit(1);

  if (existing.length > 0) {
    await db
      .update(guideRequests)
      .set({
        requestCount: existing[0].requestCount + 1,
        lastRequestAt: new Date(),
      })
      .where(eq(guideRequests.id, existing[0].id));
  } else {
    await db.insert(guideRequests).values({
      userId,
      guideId,
      weekKey,
      requestCount: 1,
      lastRequestAt: new Date(),
    });
  }
}

/** Insere um guia (usado no seed inicial) */
export async function insertGuide(guide: InsertGuide) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(guides).values(guide).onDuplicateKeyUpdate({ set: { title: guide.title } });
}

export async function subscribeToGoldenClub(
  data: InsertGoldenClubSubscriber
): Promise<{ success: boolean; alreadyExists: boolean }> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  try {
    await db.insert(goldenClubSubscribers).values({
      email: data.email.toLowerCase().trim(),
      name: data.name ?? null,
      source: data.source ?? "homepage",
      confirmed: false,
    });
    return { success: true, alreadyExists: false };
  } catch (err: unknown) {
    if (err && typeof err === "object" && "code" in err && (err as { code: string }).code === "ER_DUP_ENTRY") {
      return { success: true, alreadyExists: true };
    }
    throw err;
  }
}
