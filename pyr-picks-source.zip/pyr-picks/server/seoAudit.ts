/**
 * Pyr Picks — SEO/GEO/AEO Audit Engine
 *
 * Verifica automaticamente se cada review do site atende às premissas de:
 *   - SEO técnico (título, data, imagem, categoria)
 *   - AEO — Answer Engine Optimization (FAQ, One Best Pick, pergunta primária)
 *   - GEO — Generative Engine Optimization (contexto geográfico, locale)
 *
 * Endpoints registrados em server/_core/index.ts:
 *   GET /api/seo-audit          → relatório JSON completo
 *   GET /api/seo-audit/summary  → resumo com score geral
 *
 * Também chamado pelo scheduler semanal para notificar o owner.
 */

// Importação dinâmica para evitar problemas com módulos ESM/CJS no servidor
import { createRequire } from "module";
const require = createRequire(import.meta.url);

// ─── Tipos ───────────────────────────────────────────────────────────────────

interface Review {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  analyst: string;
  image: string;
  winner: string;
  faq: { question: string; answer: string }[];
  aeo: string;
  geo: string;
  date: string;
  score?: string;
}

export interface AuditCheck {
  id: string;
  label: string;
  category: "seo" | "aeo" | "geo" | "technical";
  passed: boolean;
  value?: string;
  recommendation?: string;
}

export interface ReviewAuditResult {
  reviewId: string;
  reviewTitle: string;
  analyst: string;
  category: string;
  date: string;
  score: number; // 0-100
  checks: AuditCheck[];
  issues: string[];
  warnings: string[];
}

export interface SiteAuditResult {
  auditedAt: string;
  totalReviews: number;
  averageScore: number;
  passRate: number; // % de reviews com score >= 80
  reviewResults: ReviewAuditResult[];
  siteChecks: AuditCheck[];
  summary: {
    critical: number;
    warnings: number;
    passed: number;
  };
  recommendations: string[];
}

// ─── Carregar reviews dinamicamente ──────────────────────────────────────────

function loadReviews(): Review[] {
  try {
    // O arquivo reviews.ts é TypeScript — usamos tsx para importar
    // Na prática, o servidor roda com tsx que transpila em tempo real
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const mod = require("../client/src/lib/reviews");
    return mod.reviews as Review[];
  } catch {
    return [];
  }
}

// ─── Auditoria de um review individual ───────────────────────────────────────

function auditReview(review: Review): ReviewAuditResult {
  const checks: AuditCheck[] = [];
  const issues: string[] = [];
  const warnings: string[] = [];

  // --- SEO Básico ---

  checks.push({
    id: "seo-title-length",
    label: "Título entre 50-70 caracteres",
    category: "seo",
    passed: review.title.length >= 50 && review.title.length <= 70,
    value: `${review.title.length} chars`,
    recommendation:
      review.title.length < 50
        ? "Título muito curto — adicione mais contexto (produto, ano, perfil)"
        : review.title.length > 70
          ? "Título muito longo — pode ser truncado no Google"
          : undefined,
  });

  checks.push({
    id: "seo-title-has-year",
    label: "Título contém o ano (freshness signal)",
    category: "seo",
    passed: /202[0-9]/.test(review.title),
    value: review.title,
    recommendation: "Adicione o ano ao título para sinalizar atualidade ao Google",
  });

  checks.push({
    id: "seo-subtitle-exists",
    label: "Subtítulo/description preenchido (>= 80 chars)",
    category: "seo",
    passed: !!(review.subtitle && review.subtitle.length >= 80),
    value: review.subtitle ? `${review.subtitle.length} chars` : "ausente",
    recommendation: "Preencha o subtítulo com 120-160 chars para a meta description",
  });

  checks.push({
    id: "seo-category-assigned",
    label: "Categoria atribuída",
    category: "seo",
    passed: !!(review.category && review.category.length > 0),
    value: review.category || "ausente",
    recommendation: "Atribua uma categoria para melhorar a estrutura de URLs e breadcrumbs",
  });

  checks.push({
    id: "seo-date-recent",
    label: "Data de publicação nos últimos 12 meses",
    category: "seo",
    passed: (() => {
      const reviewDate = new Date(review.date);
      const oneYearAgo = new Date();
      oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);
      return reviewDate >= oneYearAgo;
    })(),
    value: review.date,
    recommendation: "Atualize a data ao revisar o conteúdo para manter o freshness signal",
  });

  // --- AEO (Answer Engine Optimization) ---

  checks.push({
    id: "aeo-winner-defined",
    label: "One Best Pick (winner) definido",
    category: "aeo",
    passed: !!(review.winner && review.winner.length > 0),
    value: review.winner || "ausente",
    recommendation:
      "Defina o One Best Pick — motores de resposta priorizam conteúdo com resposta direta",
  });

  checks.push({
    id: "aeo-faq-exists",
    label: "FAQ com pelo menos 3 perguntas",
    category: "aeo",
    passed: !!(review.faq && review.faq.length >= 3),
    value: review.faq ? `${review.faq.length} perguntas` : "ausente",
    recommendation:
      "Adicione FAQ com 5-8 perguntas — ChatGPT e Perplexity priorizam conteúdo em formato Q&A",
  });

  checks.push({
    id: "aeo-faq-direct-answers",
    label: "Respostas do FAQ são diretas (>= 50 chars cada)",
    category: "aeo",
    passed: !!(
      review.faq &&
      review.faq.length > 0 &&
      review.faq.every((f) => f.answer && f.answer.length >= 50)
    ),
    value:
      review.faq && review.faq.length > 0
        ? `min: ${Math.min(...review.faq.map((f) => f.answer?.length || 0))} chars`
        : "N/A",
    recommendation:
      "Respostas muito curtas não são aproveitadas pelos motores de resposta — mínimo 50 chars",
  });

  checks.push({
    id: "aeo-keywords-defined",
    label: "String de keywords AEO preenchida (>= 50 chars)",
    category: "aeo",
    passed: !!(review.aeo && review.aeo.length >= 50),
    value: review.aeo ? `${review.aeo.length} chars` : "ausente",
    recommendation:
      "Preencha o campo aeo com pelo menos 5 keywords separadas por vírgula",
  });

  // --- GEO (Generative Engine Optimization) ---

  checks.push({
    id: "geo-string-defined",
    label: "String de contexto GEO preenchida (>= 50 chars)",
    category: "geo",
    passed: !!(review.geo && review.geo.length >= 50),
    value: review.geo ? `${review.geo.length} chars` : "ausente",
    recommendation:
      "Preencha o campo geo com contexto geográfico (ex: 'melhor X em São Paulo 2026, mercado brasileiro de Y')",
  });

  checks.push({
    id: "geo-has-brasil",
    label: "Contexto GEO menciona Brasil ou cidade brasileira",
    category: "geo",
    passed: !!(
      review.geo &&
      /brasil|são paulo|rio de janeiro|belo horizonte|brasília|curitiba|porto alegre/i.test(
        review.geo
      )
    ),
    value: review.geo ? "OK" : "ausente",
    recommendation:
      "Inclua referências geográficas brasileiras no campo geo para otimizar buscas localizadas",
  });

  // --- Técnico ---

  checks.push({
    id: "tech-image-exists",
    label: "Imagem de capa definida (CDN URL)",
    category: "technical",
    passed: !!(review.image && review.image.startsWith("http")),
    value: review.image ? "OK (CDN)" : "ausente",
    recommendation: "Adicione imagem de capa via CDN para Open Graph e redes sociais",
  });

  checks.push({
    id: "tech-analyst-assigned",
    label: "Analista responsável atribuído",
    category: "technical",
    passed: !!(review.analyst && review.analyst.length > 0),
    value: review.analyst || "ausente",
    recommendation: "Atribua um analista para habilitar o perfil de autor e E-E-A-T",
  });

  checks.push({
    id: "tech-score-defined",
    label: "Score numérico definido",
    category: "technical",
    passed: !!(review.score && parseFloat(review.score) > 0),
    value: review.score || "ausente",
    recommendation: "Defina o score numérico para habilitar o schema markup de avaliação",
  });

  // Calcular score
  const passedCount = checks.filter((c) => c.passed).length;
  const score = Math.round((passedCount / checks.length) * 100);

  // Classificar issues e warnings
  checks.forEach((check) => {
    if (!check.passed && check.recommendation) {
      if (
        ["aeo-winner-defined", "aeo-faq-exists", "seo-title-length", "tech-image-exists"].includes(
          check.id
        )
      ) {
        issues.push(`[CRÍTICO] ${check.label}: ${check.recommendation}`);
      } else {
        warnings.push(`[AVISO] ${check.label}: ${check.recommendation}`);
      }
    }
  });

  return {
    reviewId: review.id,
    reviewTitle: review.title,
    analyst: review.analyst,
    category: review.category,
    date: review.date,
    score,
    checks,
    issues,
    warnings,
  };
}

// ─── Auditoria do site completo ───────────────────────────────────────────────

export function runSiteAudit(): SiteAuditResult {
  const reviews = loadReviews();

  if (reviews.length === 0) {
    return {
      auditedAt: new Date().toISOString(),
      totalReviews: 0,
      averageScore: 0,
      passRate: 0,
      reviewResults: [],
      siteChecks: [],
      summary: { critical: 0, warnings: 0, passed: 0 },
      recommendations: ["Não foi possível carregar os reviews — verifique o arquivo client/src/lib/reviews.ts"],
    };
  }

  const reviewResults = reviews.map(auditReview);
  const averageScore = Math.round(
    reviewResults.reduce((sum, r) => sum + r.score, 0) / reviewResults.length
  );
  const passRate = Math.round(
    (reviewResults.filter((r) => r.score >= 80).length / reviewResults.length) * 100
  );

  // Checks do site como um todo
  const siteChecks: AuditCheck[] = [
    {
      id: "site-sitemap-exists",
      label: "sitemap.xml disponível",
      category: "technical",
      passed: true,
      value: "/sitemap.xml",
    },
    {
      id: "site-robots-exists",
      label: "robots.txt disponível",
      category: "technical",
      passed: true,
      value: "/robots.txt",
    },
    {
      id: "site-all-reviews-have-faq",
      label: "Todos os reviews têm FAQ (>= 3 perguntas)",
      category: "aeo",
      passed: reviews.every((r) => r.faq && r.faq.length >= 3),
      value: `${reviews.filter((r) => r.faq && r.faq.length >= 3).length}/${reviews.length}`,
      recommendation: "Reviews sem FAQ não aparecem nos featured snippets do Google",
    },
    {
      id: "site-all-reviews-have-winner",
      label: "Todos os reviews têm One Best Pick",
      category: "aeo",
      passed: reviews.every((r) => r.winner),
      value: `${reviews.filter((r) => r.winner).length}/${reviews.length}`,
      recommendation: "Reviews sem One Best Pick não geram featured snippets de resposta direta",
    },
    {
      id: "site-all-reviews-have-geo",
      label: "Todos os reviews têm dados GEO (>= 50 chars)",
      category: "geo",
      passed: reviews.every((r) => r.geo && r.geo.length >= 50),
      value: `${reviews.filter((r) => r.geo && r.geo.length >= 50).length}/${reviews.length}`,
      recommendation: "Dados GEO ausentes reduzem relevância em buscas localizadas por IA",
    },
    {
      id: "site-all-reviews-have-aeo",
      label: "Todos os reviews têm dados AEO (>= 50 chars)",
      category: "aeo",
      passed: reviews.every((r) => r.aeo && r.aeo.length >= 50),
      value: `${reviews.filter((r) => r.aeo && r.aeo.length >= 50).length}/${reviews.length}`,
      recommendation: "Keywords AEO ausentes reduzem a descoberta por motores de resposta",
    },
    {
      id: "site-reviews-fresh",
      label: "Todos os reviews publicados nos últimos 12 meses",
      category: "seo",
      passed: (() => {
        const oneYearAgo = new Date();
        oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);
        return reviews.every((r) => new Date(r.date) >= oneYearAgo);
      })(),
      value: `${reviews.length} reviews verificados`,
      recommendation: "Reviews com mais de 12 meses perdem posição — atualize a data ao revisar",
    },
  ];

  // Recomendações globais
  const recommendations: string[] = [];

  const reviewsWithoutFaq = reviewResults.filter((r) =>
    r.checks.find((c) => c.id === "aeo-faq-exists" && !c.passed)
  );
  if (reviewsWithoutFaq.length > 0) {
    recommendations.push(
      `${reviewsWithoutFaq.length} review(s) sem FAQ: ${reviewsWithoutFaq.map((r) => r.reviewId).join(", ")}`
    );
  }

  const reviewsWithoutGeo = reviewResults.filter((r) =>
    r.checks.find((c) => c.id === "geo-string-defined" && !c.passed)
  );
  if (reviewsWithoutGeo.length > 0) {
    recommendations.push(
      `${reviewsWithoutGeo.length} review(s) sem dados GEO: ${reviewsWithoutGeo.map((r) => r.reviewId).join(", ")}`
    );
  }

  const reviewsLowScore = reviewResults.filter((r) => r.score < 70);
  if (reviewsLowScore.length > 0) {
    recommendations.push(
      `${reviewsLowScore.length} review(s) com score abaixo de 70: ${reviewsLowScore.map((r) => `${r.reviewId} (${r.score})`).join(", ")}`
    );
  }

  const allIssues = reviewResults.flatMap((r) => r.issues);
  const allWarnings = reviewResults.flatMap((r) => r.warnings);
  const siteIssues = siteChecks.filter((c) => !c.passed);

  return {
    auditedAt: new Date().toISOString(),
    totalReviews: reviews.length,
    averageScore,
    passRate,
    reviewResults,
    siteChecks,
    summary: {
      critical: allIssues.length + siteIssues.length,
      warnings: allWarnings.length,
      passed: reviewResults.reduce((sum, r) => sum + r.checks.filter((c) => c.passed).length, 0),
    },
    recommendations,
  };
}

// ─── Formatar relatório para notificação ─────────────────────────────────────

export function formatAuditNotification(audit: SiteAuditResult): string {
  const emoji = audit.averageScore >= 80 ? "✅" : audit.averageScore >= 60 ? "⚠️" : "🚨";
  const lines: string[] = [
    `${emoji} Auditoria SEO/GEO/AEO — Pyr Picks`,
    `Data: ${new Date(audit.auditedAt).toLocaleDateString("pt-BR")}`,
    ``,
    `📊 Score médio: ${audit.averageScore}/100`,
    `📈 Reviews com score ≥ 80: ${audit.passRate}% (${audit.reviewResults.filter((r) => r.score >= 80).length}/${audit.totalReviews})`,
    `🚨 Problemas críticos: ${audit.summary.critical}`,
    `⚠️  Avisos: ${audit.summary.warnings}`,
    ``,
  ];

  if (audit.recommendations.length > 0) {
    lines.push(`🔧 Ações recomendadas:`);
    audit.recommendations.forEach((r) => lines.push(`  • ${r}`));
    lines.push(``);
  }

  // Top 3 reviews com menor score
  const worst = [...audit.reviewResults].sort((a, b) => a.score - b.score).slice(0, 3);
  if (worst.some((r) => r.score < 80)) {
    lines.push(`📉 Reviews com maior necessidade de atenção:`);
    worst.forEach((r) => {
      if (r.score < 80) {
        lines.push(
          `  • ${r.reviewId} — score: ${r.score}/100 (${r.issues.length} críticos, ${r.warnings.length} avisos)`
        );
      }
    });
  }

  return lines.join("\n");
}
