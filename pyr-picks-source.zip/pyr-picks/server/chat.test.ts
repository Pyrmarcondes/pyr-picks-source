import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock the LLM module
vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn().mockResolvedValue({
    choices: [
      {
        message: {
          content: "Resposta de teste do analista IA.",
        },
      },
    ],
  }),
}));

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("chat.sendMessage", () => {
  it("deve retornar resposta para analista ana-financas", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.chat.sendMessage({
      analystId: "ana-financas",
      messages: [{ role: "user", content: "Qual a melhor conta digital?" }],
    });

    expect(result).toHaveProperty("content");
    expect(typeof result.content).toBe("string");
    expect(result.content.length).toBeGreaterThan(0);
  });

  it("deve retornar resposta para analista rafael-viagens", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.chat.sendMessage({
      analystId: "rafael-viagens",
      messages: [{ role: "user", content: "Como acumular milhas?" }],
    });

    expect(result).toHaveProperty("content");
    expect(typeof result.content).toBe("string");
  });

  it("deve lançar erro para analista inexistente", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.chat.sendMessage({
        analystId: "analista-inexistente",
        messages: [{ role: "user", content: "Olá" }],
      })
    ).rejects.toThrow("Analista nao encontrado");
  });

  it("deve suportar historico de conversa com multiplas mensagens", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.chat.sendMessage({
      analystId: "dr-lucas-saude",
      messages: [
        { role: "user", content: "Qual o melhor plano de saude?" },
        { role: "assistant", content: "Depende do seu perfil..." },
        { role: "user", content: "Tenho 35 anos e uso bastante." },
      ],
    });

    expect(result).toHaveProperty("content");
    expect(typeof result.content).toBe("string");
  });

  it("deve suportar todos os 5 analistas originais", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const analystIds = ["ana-financas", "dr-lucas-saude", "clara-seguros", "rafael-viagens", "sofia-streaming"];

    for (const analystId of analystIds) {
      const result = await caller.chat.sendMessage({
        analystId,
        messages: [{ role: "user", content: "Olá, pode me ajudar?" }],
      });
      expect(result).toHaveProperty("content");
    }
  });

  it("deve suportar os 3 novos analistas (Mei Chen, Kenji Tanaka, Araci ESG)", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const newAnalystIds = ["mei-chen", "kenji-tanaka", "araci-esg"];

    for (const analystId of newAnalystIds) {
      const result = await caller.chat.sendMessage({
        analystId,
        messages: [{ role: "user", content: "Olá, pode me ajudar?" }],
      });
      expect(result).toHaveProperty("content");
      expect(typeof result.content).toBe("string");
    }
  });

  it("deve retornar resposta para Mei Chen sobre mercados internacionais", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.chat.sendMessage({
      analystId: "mei-chen",
      messages: [{ role: "user", content: "Vale a pena investir em BDRs?" }],
    });
    expect(result).toHaveProperty("content");
    expect(typeof result.content).toBe("string");
  });

  it("deve retornar resposta para Araci ESG sobre fundos sustentáveis", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.chat.sendMessage({
      analystId: "araci-esg",
      messages: [{ role: "user", content: "Como identificar greenwashing?" }],
    });
    expect(result).toHaveProperty("content");
    expect(typeof result.content).toBe("string");
  });
});
