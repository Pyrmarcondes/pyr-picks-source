import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { registerSitemapRoute } from "../sitemap";
import { runSiteAudit, formatAuditNotification } from "../seoAudit";
import { notifyOwner } from "./notification";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  // OAuth callback under /api/oauth/callback
  registerOAuthRoutes(app);
  // Sitemap XML
  registerSitemapRoute(app);

  // SEO/GEO/AEO Audit endpoints
  app.get("/api/seo-audit", (_req, res) => {
    try {
      const audit = runSiteAudit();
      res.json(audit);
    } catch (err) {
      res.status(500).json({ error: "Falha ao executar auditoria", details: String(err) });
    }
  });

  app.get("/api/seo-audit/summary", (_req, res) => {
    try {
      const audit = runSiteAudit();
      res.json({
        auditedAt: audit.auditedAt,
        totalReviews: audit.totalReviews,
        averageScore: audit.averageScore,
        passRate: audit.passRate,
        summary: audit.summary,
        recommendations: audit.recommendations,
        worstReviews: audit.reviewResults
          .filter((r) => r.score < 80)
          .sort((a, b) => a.score - b.score)
          .slice(0, 5)
          .map((r) => ({ id: r.reviewId, score: r.score, issues: r.issues.length, warnings: r.warnings.length })),
      });
    } catch (err) {
      res.status(500).json({ error: "Falha ao executar auditoria", details: String(err) });
    }
  });

  // Scheduler: auditoria semanal toda segunda-feira às 08:00 BRT
  const AUDIT_INTERVAL_MS = 7 * 24 * 60 * 60 * 1000; // 7 dias
  async function runWeeklyAudit() {
    try {
      const audit = runSiteAudit();
      const message = formatAuditNotification(audit);
      await notifyOwner({
        title: `📊 Auditoria SEO/GEO/AEO Semanal — Score: ${audit.averageScore}/100`,
        content: message,
      });
      console.log(`[SEO Audit] Auditoria semanal concluída. Score: ${audit.averageScore}/100, ${audit.summary.critical} críticos, ${audit.summary.warnings} avisos.`);
    } catch (err) {
      console.error("[SEO Audit] Erro na auditoria semanal:", err);
    }
  }
  // Executar primeira auditoria após 5 segundos do boot, depois semanalmente
  setTimeout(() => {
    runWeeklyAudit();
    setInterval(runWeeklyAudit, AUDIT_INTERVAL_MS);
  }, 5000);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
