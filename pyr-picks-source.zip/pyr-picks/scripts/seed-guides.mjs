/**
 * Seed script — Guias Sem Fim
 * Popula os 5 guias e o substrato inicial (5 dicas por guia)
 * Uso: node scripts/seed-guides.mjs
 */
import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import { eq } from "drizzle-orm";
import dotenv from "dotenv";
dotenv.config();

// ─── Importar schema diretamente ─────────────────────────────────────────────
// Usamos dynamic import para ESM
const { guides, guideEntries } = await import("../drizzle/schema.ts").catch(async () => {
  // fallback: importar via tsx
  const mod = await import("../drizzle/schema.js");
  return mod;
});

const connection = await mysql.createConnection(process.env.DATABASE_URL);
const db = drizzle(connection);

// ─── Avatares dos analistas ───────────────────────────────────────────────────
const AVATARS = {
  "ana-financas": "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/ana-financas-avatar-dark-5jcqGDeaqjJQWuBrfptzmZ.webp",
  "dr-lucas-saude": "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/dr-lucas-saude-avatar-dark-GHWMg3BbHfJmKHPmEAqiJP.webp",
  "rafael-viagens": "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/rafael-viagens-avatar-dark-MQ5FKPBaPSATZXoFpyHgk8.webp",
  "clara-seguros": "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/clara-seguros-avatar-dark-U8ioVRVwXN8f3oAoJiyzS3.webp",
  "kenji-tanaka": "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/kenji-tanaka-avatar-dark-Ld7BXkqpnYBrpFrKgNBC3x.webp",
};

const GUIDES = [
  {
    slug: "como-investir-melhor",
    title: "Como Investir Melhor",
    description: "Princípios atemporais de finanças pessoais e investimentos. Cada dica é um conceito que vale para sempre — sem produtos específicos, sem taxas do dia.",
    analystId: "ana-financas",
    analystName: "Ana Finanças",
    analystAvatar: AVATARS["ana-financas"],
    coverImage: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-investir-melhor-cover-EEoyWFq7fUcVU9LNw4UwRV.webp",
    color: "#0C6B58",
    entries: [
      { title: "O que é diversificação e por que ela importa", content: `## O que é diversificação e por que ela importa\n\nDiversificação é o princípio de não concentrar todos os seus recursos em um único ativo, setor ou classe de investimento. A lógica é simples: se um investimento vai mal, os outros podem compensar a perda.\n\n**Por que funciona?**\n\nDiferentes ativos se comportam de formas distintas diante dos mesmos eventos econômicos. Enquanto a bolsa cai em momentos de crise, títulos de renda fixa tendem a se valorizar. Enquanto investimentos em reais sofrem com a inflação, ativos dolarizados podem proteger o poder de compra.\n\n**O erro mais comum**\n\nMuitos investidores acreditam que diversificar é ter muitos ativos diferentes — mas comprar 20 ações de empresas do mesmo setor não é diversificação real. Diversificação genuína envolve classes de ativos distintas (renda fixa, variável, internacional, real estate) e descorrelação entre elas.\n\n**A regra prática**\n\nAntes de adicionar qualquer ativo à sua carteira, pergunte: *"Se esse ativo cair 50%, o que acontece com o restante da minha carteira?"* Se a resposta for "cai junto", você não está diversificado.`, tip: "Revise sua carteira e verifique se seus ativos se comportam de forma diferente em crises — se todos caem juntos, você precisa diversificar de verdade." },
      { title: "Renda fixa não é sinônimo de segurança absoluta", content: `## Renda fixa não é sinônimo de segurança absoluta\n\nUm dos mitos mais perigosos do investidor iniciante é tratar toda renda fixa como "dinheiro seguro". A realidade é mais complexa.\n\n**O que renda fixa realmente significa**\n\nRenda fixa é uma categoria de investimento onde as regras de remuneração são definidas no momento da aplicação — seja uma taxa prefixada, seja um índice como CDI ou IPCA mais um spread. O "fixo" é a fórmula, não o valor final.\n\n**Os riscos que existem**\n\nTrês riscos principais afetam investimentos de renda fixa:\n\n1. **Risco de crédito:** o emissor pode não pagar.\n2. **Risco de liquidez:** alguns títulos têm prazo longo e mercado secundário ilíquido.\n3. **Risco de inflação:** um título prefixado a 10% ao ano perde valor real se a inflação chegar a 12%.\n\n**A pergunta certa a fazer**\n\nAntes de investir em qualquer título de renda fixa: *"Quem é o emissor, qual é o prazo, e o que acontece se eu precisar do dinheiro antes?"*`, tip: "Sempre verifique o rating de crédito do emissor e o prazo de vencimento antes de aplicar em qualquer título de renda fixa." },
      { title: "A diferença entre poupar e investir", content: `## A diferença entre poupar e investir\n\nPoupar e investir são comportamentos distintos que muitas pessoas confundem — e essa confusão tem custo financeiro real.\n\n**Poupar é guardar. Investir é fazer o dinheiro trabalhar.**\n\nQuando você guarda dinheiro na conta corrente, está poupando — mas o poder de compra desse dinheiro diminui a cada dia por causa da inflação. Poupar sem investir é perder dinheiro lentamente.\n\nInvestir é alocar recursos em ativos que têm potencial de crescer acima da inflação ao longo do tempo.\n\n**O custo de não investir**\n\nConsidere R$ 10.000 parados em conta corrente por 10 anos. Com inflação média de 5% ao ano, o poder de compra real cai para aproximadamente R$ 6.139.\n\n**Por onde começar**\n\nA transição começa com uma pergunta: *"Para que prazo preciso desse dinheiro?"*\n\n- Dinheiro de emergência (até 12 meses): liquidez diária, baixo risco\n- Objetivos de médio prazo (1-5 anos): renda fixa com prazo adequado\n- Objetivos de longo prazo (5+ anos): pode incluir renda variável`, tip: "Separe seu dinheiro em três blocos — emergência, médio prazo e longo prazo — e invista cada bloco de acordo com o horizonte de tempo." },
      { title: "Como a inflação corrói seu patrimônio silenciosamente", content: `## Como a inflação corrói seu patrimônio silenciosamente\n\nA inflação é o inimigo invisível do patrimônio. Ela não aparece no extrato bancário — mas trabalha todos os dias para reduzir o que seu dinheiro pode comprar.\n\n**O mecanismo da corrosão**\n\nImagine que você tem R$ 100.000 investidos em algo que rende 6% ao ano, mas a inflação está em 8% ao ano. Matematicamente, você "ganhou" R$ 6.000 — mas perdeu poder de compra equivalente a R$ 8.000. Resultado real: -2% ao ano.\n\n**Por que isso importa mais do que parece**\n\nO efeito composto da inflação é devastador no longo prazo. Uma inflação de 5% ao ano reduz o poder de compra de R$ 1.000.000 para aproximadamente R$ 614.000 em 10 anos.\n\n**A proteção correta**\n\nInvestimentos que protegem da inflação têm rendimento atrelado a índices de preços (como IPCA) mais um spread adicional. Esse spread é o ganho real.`, tip: "Calcule o rendimento real dos seus investimentos: rendimento nominal menos inflação. Se for negativo ou próximo de zero, é hora de revisar a carteira." },
      { title: "O que é liquidez e por que ela tem preço", content: `## O que é liquidez e por que ela tem preço\n\nLiquidez é a capacidade de converter um investimento em dinheiro rapidamente, sem perda significativa de valor.\n\n**O triângulo impossível**\n\nVocê não pode ter ao mesmo tempo alta rentabilidade, alta segurança e alta liquidez. Sempre há um trade-off. Investimentos com liquidez diária tendem a ter rentabilidade menor.\n\n**Por que liquidez tem preço**\n\nQuando você abre mão de liquidez, está prestando um serviço ao emissor do título. Em troca, ele paga um prêmio: uma taxa maior do que pagaria por dinheiro disponível a qualquer momento.\n\n**O erro de travar tudo**\n\nMuitos investidores travam todo o patrimônio em busca de rentabilidade máxima — e ficam sem recursos quando surge uma emergência. A regra geral: mantenha pelo menos 3 a 6 meses de despesas em investimentos com liquidez imediata.`, tip: "Antes de qualquer aplicação, verifique o prazo de resgate e o custo de saída antecipada — liquidez é um ativo que vale dinheiro." },
    ],
  },
  {
    slug: "como-escolher-plano-de-saude",
    title: "Como Escolher Plano de Saúde",
    description: "Critérios, armadilhas e perguntas essenciais para escolher o plano certo. Sem mencionar operadoras específicas — princípios que valem para qualquer escolha.",
    analystId: "dr-lucas-saude",
    analystName: "Dr. Lucas Saúde",
    analystAvatar: AVATARS["dr-lucas-saude"],
    coverImage: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-plano-saude-cover-8CgCRtESFqmqq9xhqnLpNC.webp",
    color: "#1a5276",
    entries: [
      { title: "Cobertura vs. preço: o erro mais caro na escolha", content: `## Cobertura vs. preço: o erro mais caro na escolha\n\nO critério mais comum na escolha de plano de saúde é o preço. É também o critério que mais frequentemente leva a arrependimento.\n\n**Por que o preço é uma armadilha**\n\nUm plano barato pode ter cobertura restrita que só se revela no momento em que você mais precisa — durante uma internação ou tratamento de longa duração.\n\n**O que avaliar além do preço**\n\n1. **Abrangência geográfica:** o plano cobre apenas sua cidade, o estado ou tem cobertura nacional?\n2. **Rede credenciada:** os hospitais e especialistas que você já usa estão na rede?\n3. **Cobertura de procedimentos:** o plano cobre o rol mínimo da ANS ou tem coberturas adicionais?\n4. **Carências:** quanto tempo você precisa esperar para usar cada tipo de cobertura?\n\n**A pergunta certa**\n\n*"Qual é o pior cenário de saúde que posso enfrentar nos próximos 5 anos, e esse plano me cobre adequadamente?"*`, tip: "Antes de assinar qualquer plano, solicite a lista completa de procedimentos cobertos e a rede credenciada na sua região." },
      { title: "O que são carências e como elas funcionam", content: `## O que são carências e como elas funcionam\n\nCarência é o período após a contratação durante o qual você paga a mensalidade mas não tem direito a usar determinados serviços.\n\n**Os prazos máximos da ANS**\n\n- Urgência e emergência: 24 horas\n- Consultas e exames simples: até 30 dias\n- Internações e cirurgias: até 180 dias\n- Parto: até 300 dias\n- Doenças preexistentes: até 24 meses\n\n**Portabilidade de carências**\n\nSe você já tem um plano e quer trocar, a portabilidade permite migrar sem cumprir novas carências — desde que o novo plano tenha cobertura equivalente ou superior e você não tenha interrompido o pagamento.`, tip: "Ao contratar um plano, leia o contrato especificamente nas cláusulas de carência e doenças preexistentes — é onde estão as surpresas desagradáveis." },
      { title: "Individual, familiar ou empresarial: qual escolher", content: `## Individual, familiar ou empresarial: qual escolher\n\n**Plano individual:** contratado diretamente com a operadora. Tem reajustes regulados pela ANS. Mais caro por pessoa e cada vez mais difícil de encontrar.\n\n**Plano familiar:** inclui titular e dependentes no mesmo contrato. Geralmente mais econômico por pessoa.\n\n**Plano empresarial:** contratado por empresas para funcionários. Mais barato por ter grupo maior. Desvantagem: ao sair da empresa, você perde a cobertura.\n\n**O critério decisivo**\n\nSe você é autônomo ou MEI, um plano coletivo por adesão (oferecido por associações profissionais) pode combinar o custo do empresarial com a estabilidade do individual.`, tip: "Se você tem empresa, compare o custo de oferecer plano empresarial com o benefício fiscal — em muitos casos, o plano é dedutível do imposto de renda da pessoa jurídica." },
      { title: "Rede credenciada: a pergunta que ninguém faz antes", content: `## Rede credenciada: a pergunta que ninguém faz antes\n\nA rede credenciada é o conjunto de hospitais, clínicas e médicos que atendem pelo seu plano. É um dos fatores mais importantes — e menos verificados — na hora de contratar.\n\n**O que verificar antes de contratar**\n\n1. O hospital que você usaria em emergência está na rede?\n2. Os médicos que você já consulta aceitam o plano?\n3. Os laboratórios próximos a você estão credenciados?\n4. Há cobertura adequada nas cidades que você frequenta?\n\n**A armadilha da rede "ampla"**\n\nOperadoras anunciam redes com milhares de prestadores — mas a qualidade e distribuição geográfica variam. Uma rede com 5.000 médicos concentrados em São Paulo não ajuda quem mora no interior.`, tip: "Pesquise a rede credenciada pelo CEP da sua casa e do seu trabalho antes de contratar — não confie apenas no número total de prestadores anunciado." },
      { title: "Reajustes: como evitar surpresas na mensalidade", content: `## Reajustes: como evitar surpresas na mensalidade\n\n**Os dois tipos de reajuste**\n\n1. **Por variação de custos:** aplicado anualmente. Para planos individuais, o percentual máximo é definido pela ANS. Para planos coletivos, a negociação é entre operadora e contratante — sem teto da ANS.\n\n2. **Por faixa etária:** ao completar determinadas idades, o valor aumenta automaticamente.\n\n**O que ninguém te conta sobre planos coletivos**\n\nPlanos coletivos não têm o teto de reajuste da ANS. A operadora pode propor qualquer percentual na renovação anual. Um plano barato hoje pode se tornar inviável em alguns anos.\n\n**Como se proteger**\n\nAo contratar, pergunte: *"Qual foi o percentual de reajuste nos últimos 3 anos?"*`, tip: "Guarde os contratos e históricos de reajuste do seu plano — em caso de reajuste abusivo, você pode recorrer à ANS com documentação do histórico." },
    ],
  },
  {
    slug: "como-viajar-melhor-gastando-menos",
    title: "Como Viajar Melhor Gastando Menos",
    description: "Estratégias, hacks de milhas e princípios do viajante experiente. Sem mencionar programas específicos — fundamentos que funcionam em qualquer contexto.",
    analystId: "rafael-viagens",
    analystName: "Rafael Viagens",
    analystAvatar: AVATARS["rafael-viagens"],
    coverImage: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-viajar-melhor-cover-TZx8dNrgcXG8MPMWaoGEjZ.webp",
    color: "#2e7d32",
    entries: [
      { title: "A lógica dos programas de milhas: como realmente funciona", content: `## A lógica dos programas de milhas: como realmente funciona\n\nProgramas de milhas são, na essência, moedas emitidas por companhias aéreas e bancos. Entender essa lógica muda completamente a forma como você os usa.\n\n**Milhas são uma moeda que deprecia**\n\nDiferente do dinheiro real, milhas perdem valor ao longo do tempo. As companhias aéreas podem aumentar o custo de emissão a qualquer momento. A regra de ouro: milha acumulada é milha a ser usada, não guardada indefinidamente.\n\n**Onde as milhas têm mais valor**\n\nMilhas valem mais em passagens de longa distância e em classes superiores (executiva, primeira classe). Uma passagem executiva para a Europa que custaria R$ 15.000 pode ser emitida por milhas que, se convertidas em dinheiro, valeriam R$ 3.000.\n\n**A pergunta antes de acumular**\n\n*"Para qual destino e classe eu quero usar essas milhas?"* Ter um objetivo claro evita acumular milhas sem estratégia.`, tip: "Defina um destino-objetivo antes de começar a acumular milhas — isso orienta qual cartão usar e qual programa priorizar." },
      { title: "Quando reservar: a janela ideal para cada tipo de viagem", content: `## Quando reservar: a janela ideal para cada tipo de viagem\n\nO momento da reserva afeta o preço significativamente — mas a lógica não é simplesmente "quanto antes, melhor".\n\n**A curva de preços das passagens**\n\n- Muito antecipado (mais de 6 meses): preços moderados, disponibilidade ampla\n- Janela ideal (2-4 meses para internacionais, 3-6 semanas para domésticos): melhor relação preço/disponibilidade\n- Última hora: pode ser barato ou muito caro, dependendo da ocupação\n\n**O erro do "vou esperar baixar"**\n\nEsperar o preço cair é uma estratégia arriscada. Passagens raramente caem significativamente depois que a demanda se consolida. Se o preço está dentro do seu orçamento e a data é certa, reserve.`, tip: "Para viagens internacionais planejadas, comece a monitorar preços 4-6 meses antes e defina um preço-alvo para tomar a decisão sem hesitar." },
      { title: "Como escolher o cartão de crédito certo para viagens", content: `## Como escolher o cartão de crédito certo para viagens\n\n**Os critérios que importam**\n\n1. **Taxa de conversão:** quantos pontos você ganha por real gasto?\n2. **Anuidade vs. benefícios:** uma anuidade alta só se justifica se os benefícios superarem o custo.\n3. **Parceiros de transferência:** o cartão transfere para o programa de milhas que você usa?\n4. **Benefícios de viagem:** seguro de bagagem, acesso a salas VIP, seguro médico internacional.\n\n**O erro da diversificação excessiva**\n\nTer muitos cartões diferentes dilui o gasto e dificulta atingir os bônus de aceleração. Concentrar gastos em 1-2 cartões principais gera mais milhas do que distribuir entre 5 cartões.`, tip: "Calcule quantas milhas você acumula por ano com seu cartão atual e compare com alternativas — a diferença pode ser de uma passagem internacional por ano." },
      { title: "Hospedagem: como maximizar valor sem pagar mais", content: `## Hospedagem: como maximizar valor sem pagar mais\n\n**Reservar diretamente vs. plataformas**\n\nReservar diretamente com o hotel geralmente oferece:\n- Melhor preço (hotéis pagam comissão às plataformas)\n- Acumulação de pontos de fidelidade\n- Flexibilidade maior de cancelamento\n- Possibilidade de upgrade no check-in\n\n**A localização como variável de custo**\n\nUm hotel levemente fora do centro turístico pode custar 30-50% menos — e se o transporte público é eficiente, a diferença de tempo é mínima. Calcule o custo total (hospedagem + transporte) antes de decidir.`, tip: "Ao reservar hotéis, verifique sempre o preço direto no site do hotel após encontrar a melhor opção nas plataformas — frequentemente é igual ou menor, com mais benefícios." },
      { title: "Seguro viagem: o que cobre e o que não cobre", content: `## Seguro viagem: o que cobre e o que não cobre\n\n**As coberturas essenciais**\n\n- Despesas médicas e hospitalares: o item mais crítico\n- Repatriação médica: transporte de volta ao Brasil em emergência grave\n- Cancelamento de viagem: reembolso por motivos cobertos\n- Extravio de bagagem: indenização por bagagem perdida ou atrasada\n\n**O que geralmente não está coberto**\n\n- Doenças preexistentes\n- Esportes de alto risco sem cobertura adicional\n- Cancelamentos por "arrependimento"\n\n**A armadilha do seguro barato**\n\nSeguros com cobertura médica muito baixa podem ser insuficientes para cobrir uma internação nos EUA, onde uma noite em UTI pode custar US$ 10.000 ou mais.`, tip: "Para viagens aos EUA ou Canadá, contrate seguro com cobertura médica mínima de US$ 100.000 — o custo hospitalar nesses países pode ser devastador sem cobertura adequada." },
    ],
  },
  {
    slug: "como-proteger-seu-patrimonio",
    title: "Como Proteger seu Patrimônio",
    description: "Riscos que você provavelmente não está cobrindo, cláusulas que merecem atenção e passos para revisar sua proteção.",
    analystId: "clara-seguros",
    analystName: "Clara Seguros",
    analystAvatar: AVATARS["clara-seguros"],
    coverImage: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-proteger-patrimonio-cover-2A6QGzJzHf23uLbpU7tkUR.webp",
    color: "#8B6914",
    entries: [
      { title: "Os 5 riscos que a maioria das pessoas ignora", content: `## Os 5 riscos que a maioria das pessoas ignora\n\n1. **Responsabilidade civil pessoal:** um acidente de carro com invalidez permanente pode gerar indenizações de milhões. O seguro básico raramente cobre.\n2. **Invalidez por doença:** a maioria segura a vida mas não a renda. Uma doença grave que impeça de trabalhar pode ser mais devastadora do que a morte.\n3. **Danos a terceiros em imóvel:** se um cano estourar no seu apartamento e danificar o de baixo, você é responsável.\n4. **Morte do cônjuge sem planejamento:** casais que dependem de duas rendas frequentemente não têm proteção para o cenário em que uma desaparece.\n5. **Perda de documentos e dados digitais:** perder acesso a contas bancárias ou dados de empresa tem custo financeiro e legal significativo.\n\n**A pergunta que revela as lacunas**\n\n*"Se eu perder minha capacidade de trabalhar por 2 anos, minha família mantém o padrão de vida?"*`, tip: "Faça um inventário dos seus riscos: liste o que aconteceria com sua família em cada cenário de perda — renda, saúde, imóvel, veículo." },
      { title: "Seguro de vida: quanto você realmente precisa", content: `## Seguro de vida: quanto você realmente precisa\n\n**O cálculo correto (método de reposição de renda)**\n\n1. Calcule sua renda anual líquida\n2. Multiplique pelo número de anos que sua família precisaria de suporte\n3. Adicione dívidas existentes (financiamento imobiliário, empréstimos)\n4. Subtraia o patrimônio líquido já acumulado\n\nO resultado é o capital segurado necessário.\n\n**Por que a maioria está subassegurada**\n\nSeguros de vida contratados via empregador geralmente cobrem 1-2 salários anuais — insuficiente para a maioria das famílias.\n\n**Seguro de vida vs. seguro de invalidez**\n\nSão produtos distintos. O seguro de vida paga em caso de morte. O seguro de invalidez paga em caso de incapacidade permanente. Idealmente, você precisa de ambos.`, tip: "Revise o valor do seu seguro de vida a cada 3-5 anos ou após grandes mudanças de vida — casamento, filhos, compra de imóvel, aumento significativo de renda." },
      { title: "Seguro residencial: o que a maioria não contrata", content: `## Seguro residencial: o que a maioria não contrata\n\n**As coberturas essenciais**\n\n- Incêndio, raio e explosão\n- Danos elétricos (muito comum, frequentemente excluído)\n- Roubo e furto qualificado\n- Responsabilidade civil familiar (danos causados a vizinhos)\n- Vendaval e granizo\n- Quebra de vidros\n\n**O que frequentemente não está coberto**\n\n- Danos por umidade ou infiltração progressiva\n- Objetos de valor sem declaração específica\n- Danos causados por obras no imóvel\n\n**Imóvel alugado**\n\nInquilinos são responsáveis por danos causados ao imóvel durante a locação. Um seguro residencial para inquilinos é altamente recomendável — e geralmente muito mais barato do que para proprietários.`, tip: "Faça um inventário fotográfico dos seus bens de valor e guarde em nuvem — em caso de sinistro, a documentação prévia acelera o processo de indenização." },
      { title: "Seguro de veículo: além da colisão", content: `## Seguro de veículo: além da colisão\n\n**As coberturas que merecem atenção**\n\n1. **Responsabilidade civil:** cobre danos a terceiros. O limite padrão pode ser insuficiente em acidentes graves.\n2. **Danos morais:** em acidentes com vítimas, ações por danos morais podem resultar em indenizações significativas.\n3. **Assistência 24h:** reboque, pane seca, chaveiro.\n4. **Carro reserva:** quanto tempo você ficaria sem carro em caso de sinistro?\n\n**Franquia: o trade-off que poucos entendem**\n\nFranquia mais alta = prêmio menor. Mas a franquia é o valor que você paga do próprio bolso em caso de sinistro. Escolha uma franquia que você consegue pagar sem comprometer o orçamento.`, tip: "Verifique o limite de cobertura de responsabilidade civil da sua apólice — em acidentes com vítimas graves, indenizações de R$ 500.000 ou mais são possíveis." },
      { title: "Como ler uma apólice de seguro sem se perder", content: `## Como ler uma apólice de seguro sem se perder\n\n**A estrutura básica de qualquer apólice**\n\n1. **Condições gerais:** regras que se aplicam a todos os contratos daquele tipo.\n2. **Condições especiais:** adaptações específicas para o produto contratado.\n3. **Condições particulares:** dados específicos do seu contrato.\n4. **Cláusulas de exclusão:** o que o seguro explicitamente não cobre. Esta é a seção mais importante e menos lida.\n\n**As exclusões que mais surpreendem**\n\n- Danos causados por "desgaste natural"\n- Eventos causados por "ato intencional" do segurado\n- Danos em áreas não declaradas no contrato\n\n**Prazo de comunicação de sinistro**\n\nToda apólice tem prazo para comunicar um sinistro. Perder esse prazo pode resultar em negativa de cobertura.`, tip: "Leia as cláusulas de exclusão de qualquer apólice antes de assinar — é a seção mais curta e a mais importante para entender o que você realmente está comprando." },
    ],
  },
  {
    slug: "como-navegar-no-mundo-digital-financeiro",
    title: "Como Navegar no Mundo Digital Financeiro",
    description: "Fintechs, open banking, Pix, segurança digital e o futuro do dinheiro. Sem hype, com critério.",
    analystId: "kenji-tanaka",
    analystName: "Kenji Tanaka",
    analystAvatar: AVATARS["kenji-tanaka"],
    coverImage: "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-mundo-digital-cover-5rbVJT5JRAq2EHRek2iztn.webp",
    color: "#0d47a1",
    entries: [
      { title: "O que é open banking e por que muda tudo", content: `## O que é open banking e por que muda tudo\n\nOpen banking é um sistema que permite que você compartilhe seus dados financeiros com outras instituições de forma segura e padronizada. Em termos simples: seus dados bancários são seus, e você pode autorizar que outras empresas os acessem para oferecer serviços melhores.\n\n**O que muda na prática**\n\n- Uma fintech pode acessar seu histórico de transações para oferecer crédito com taxa mais justa\n- Um aplicativo de gestão financeira pode consolidar todas as suas contas em um lugar\n- Portabilidade de crédito fica mais simples\n\n**O que open banking não é**\n\nNão é o banco compartilhando seus dados sem autorização. Você controla quem acessa, por quanto tempo e para qual finalidade. Você pode revogar o acesso a qualquer momento.`, tip: "Verifique no aplicativo do seu banco a seção de open banking — você pode ver quais empresas têm acesso aos seus dados e revogar autorizações que não reconhece." },
      { title: "Segurança digital financeira: os erros mais comuns", content: `## Segurança digital financeira: os erros mais comuns\n\n**Os vetores de ataque mais comuns**\n\n1. **Phishing:** mensagens que imitam comunicações legítimas de bancos para roubar credenciais.\n2. **Engenharia social:** ligações de "funcionários do banco" que criam urgência artificial.\n3. **SIM swap:** golpistas convencem a operadora a transferir seu número para um chip deles.\n4. **Malware:** aplicativos maliciosos que capturam senhas em segundo plano.\n\n**Os comportamentos que aumentam o risco**\n\n- Usar a mesma senha em múltiplos serviços\n- Não ativar autenticação em dois fatores\n- Usar redes Wi-Fi públicas para acessar serviços bancários\n\n**A regra de ouro**\n\nNenhum banco legítimo pede sua senha por telefone, e-mail ou mensagem.`, tip: "Ative autenticação em dois fatores em todos os seus serviços financeiros e use um aplicativo autenticador (não SMS) sempre que possível." },
      { title: "Pix: além da transferência instantânea", content: `## Pix: além da transferência instantânea\n\n**Funcionalidades menos conhecidas**\n\n- **Pix Cobrança:** equivalente a um boleto digital, com data de vencimento e multa por atraso\n- **Pix Agendado:** transferências programadas para datas futuras\n- **Pix Automático:** débito automático para assinaturas e contas recorrentes\n\n**Limites e segurança**\n\nO Banco Central estabelece limites para Pix noturno. Reduzir o limite noturno é uma medida de segurança simples e eficaz.\n\n**O risco do Pix que poucos conhecem**\n\nDiferente de cartões de crédito, transferências Pix são difíceis de reverter. Em casos de golpe, o prazo para contestação é curto e a recuperação do dinheiro não é garantida.`, tip: "Configure limites personalizados para Pix noturno no seu banco — reduzir o limite entre 20h e 6h é uma das proteções mais simples contra golpes." },
      { title: "Como avaliar uma fintech antes de confiar seu dinheiro", content: `## Como avaliar uma fintech antes de confiar seu dinheiro\n\n**A primeira verificação: regulação**\n\nNo Brasil, instituições financeiras precisam de autorização do Banco Central. Antes de abrir conta em qualquer fintech, verifique se ela está listada no site do Banco Central como instituição autorizada.\n\n**O que a autorização significa na prática**\n\nBancos autorizados têm acesso ao FGC, que protege depósitos até R$ 250.000 por CPF por instituição. Contas de pagamento não têm essa proteção.\n\n**Sinais de alerta**\n\n- Promessas de rentabilidade muito acima do mercado\n- Dificuldade para encontrar informações sobre os sócios\n- Ausência de CNPJ verificável ou registro no Banco Central\n- Pressão para indicar outras pessoas`, tip: "Antes de abrir conta em qualquer fintech, pesquise o CNPJ no site do Banco Central (bcb.gov.br) para confirmar que é uma instituição autorizada e regulada." },
      { title: "Criptomoedas: separando realidade do hype", content: `## Criptomoedas: separando realidade do hype\n\n**O que torna algumas criptomoedas diferentes**\n\n- **Moedas de pagamento:** projetadas para ser meio de troca\n- **Plataformas de contratos inteligentes:** redes que permitem executar programas descentralizados\n- **Stablecoins:** ativos digitais atrelados a moedas tradicionais\n- **Tokens de projetos específicos:** ativos que podem ou não ter valor real\n\n**Os riscos que o hype esconde**\n\n1. Volatilidade extrema: quedas de 50-80% em meses são historicamente comuns\n2. Risco de custódia: exchanges podem falir ou ser hackeadas\n3. Risco regulatório: regulações podem mudar e afetar o valor\n4. Risco de fraude: o espaço tem histórico de projetos fraudulentos\n\n**A abordagem racional**\n\nA pergunta não é "qual vai subir mais" — é "quanto posso perder sem comprometer meu plano financeiro?"`, tip: "Se você investir em criptomoedas, use apenas exchanges regulamentadas no Brasil e nunca mantenha valores significativos em exchanges — transfira para uma carteira própria." },
    ],
  },
];

// ─── Inserção no banco ────────────────────────────────────────────────────────
console.log("🌱 Iniciando seed dos Guias Sem Fim...\n");

for (const guideData of GUIDES) {
  const { entries, ...guideFields } = guideData;

  // Verificar se o guia já existe
  const existing = await db.select().from(guides).where(eq(guides.slug, guideFields.slug));

  let guideId;
  if (existing.length > 0) {
    guideId = existing[0].id;
    console.log(`⏭  Guia já existe: "${guideFields.title}" (id: ${guideId})`);
  } else {
    const result = await db.insert(guides).values({
      ...guideFields,
      totalEntries: entries.length,
    });
    guideId = result[0].insertId;
    console.log(`✅ Guia criado: "${guideFields.title}" (id: ${guideId})`);
  }

  // Inserir entradas que não existem ainda
  const existingEntries = await db.select().from(guideEntries).where(eq(guideEntries.guideId, guideId));
  const existingNumbers = new Set(existingEntries.map((e) => e.entryNumber));

  let inserted = 0;
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    const entryNumber = i + 1;
    if (existingNumbers.has(entryNumber)) continue;

    await db.insert(guideEntries).values({
      guideId,
      entryNumber,
      title: entry.title,
      content: entry.content,
      tip: entry.tip,
      requestedByUserId: null,
    });
    inserted++;
  }

  if (inserted > 0) {
    console.log(`   └─ ${inserted} dica(s) inserida(s)\n`);
  } else {
    console.log(`   └─ Dicas já existem, nada inserido\n`);
  }
}

console.log("✅ Seed concluído com sucesso!");
await connection.end();
