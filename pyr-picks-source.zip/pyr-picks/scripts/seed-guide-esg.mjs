/**
 * Seed script: 6º Guia Sem Fim — Como Investir com Critério ESG
 * Analista: Araci (ESG)
 */
import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import * as dotenv from "dotenv";

dotenv.config();

const connection = await mysql.createConnection(process.env.DATABASE_URL);
const db = drizzle(connection);

const ARACI_AVATAR = "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/araci-esg-avatar-dark-U8ioVRVwXN8f3oAoJiyzS3.webp";
const ESG_COVER = "https://d2xsxph8kpxj0f.cloudfront.net/118386641/EoeGX4rQUSLVYZfAzik4yn/guia-esg-araci-cover-L623tekYX3nH2vd6J5yqtY.webp";

// Insert guide
await connection.execute(`
  INSERT INTO guides (slug, title, description, analystId, analystName, analystAvatar, coverImage, color, totalEntries, createdAt, updatedAt)
  VALUES (
    'como-investir-com-criterio-esg',
    'Como Investir com Critério ESG',
    'Guia atemporal sobre investimentos responsáveis: o que são critérios ESG, como avaliar empresas e fundos, e como construir uma carteira alinhada com valores ambientais, sociais e de governança — sem abrir mão de retorno.',
    'araci-esg',
    'Araci',
    '${ARACI_AVATAR}',
    '${ESG_COVER}',
    '#1a4a2e',
    5,
    NOW(),
    NOW()
  )
`);

const [[{ id: guideId }]] = await connection.execute(
  "SELECT id FROM guides WHERE slug = 'como-investir-com-criterio-esg' LIMIT 1"
);

console.log(`Guide created with ID: ${guideId}`);

const entries = [
  {
    number: 1,
    title: "O que significa ESG — e por que importa para o investidor",
    content: `## O que é ESG?

ESG é a sigla para **Environmental, Social and Governance** — em português, Ambiental, Social e Governança. São três dimensões que avaliam como uma empresa se comporta além dos resultados financeiros.

**Ambiental (E):** Como a empresa impacta o meio ambiente? Emissões de carbono, uso de água, gestão de resíduos, desmatamento.

**Social (S):** Como trata funcionários, fornecedores e comunidades? Diversidade, condições de trabalho, direitos humanos na cadeia produtiva.

**Governança (G):** Como é administrada? Transparência, composição do conselho, política anticorrupção, direitos dos acionistas minoritários.

### Por que o investidor deveria se importar?

Empresas com boas práticas ESG tendem a:
- Ter menos risco regulatório e reputacional
- Atrair e reter talentos com mais facilidade
- Estar melhor posicionadas para transições regulatórias (ex: precificação de carbono)
- Apresentar menor volatilidade no longo prazo

**O princípio fundamental:** ESG não é filantropia — é gestão de risco de longo prazo. Uma empresa que polui, explora trabalhadores ou tem governança opaca carrega riscos que não aparecem no balanço trimestral, mas aparecem no preço da ação quando o problema vira notícia.

> Antes de investir em qualquer empresa, pergunte: quais são os riscos ESG que ela carrega e como a gestão está endereçando cada um?`,
  },
  {
    number: 2,
    title: "Como avaliar se um fundo é realmente ESG",
    content: `## Como avaliar se um fundo é realmente ESG

O mercado de fundos ESG cresceu muito — e com ele, o **greenwashing**: fundos que se dizem ESG mas não têm critérios rigorosos. Saber distinguir o real do cosmético é uma habilidade essencial.

### Perguntas que você deve fazer antes de investir em um fundo ESG

**1. Qual é a metodologia de seleção?**
Fundos sérios descrevem critérios objetivos: pontuação mínima em rating ESG, exclusão de setores (armamentos, tabaco, carvão), ou integração de fatores ESG na análise financeira.

**2. Quem faz o rating ESG das empresas?**
Existem agências especializadas (MSCI, Sustainalytics, ISS ESG). Um fundo que usa ratings próprios sem metodologia publicada merece ceticismo.

**3. O fundo exclui setores controversos?**
Fundos de exclusão eliminam empresas de setores como combustíveis fósseis, armamentos ou tabaco. Fundos de integração apenas pesam os fatores ESG sem excluir. Saiba qual abordagem o fundo usa.

**4. Há engajamento ativo com as empresas?**
Os melhores gestores ESG votam em assembleias e dialogam com a gestão das empresas para melhorar práticas. Isso é mais eficaz do que simplesmente excluir empresas problemáticas.

**5. Qual é o histórico de votação em assembleias?**
No Brasil, gestores são obrigados a publicar sua política de voto. Verifique se o gestor realmente vota contra propostas que prejudicam acionistas minoritários ou o meio ambiente.

> **Regra prática:** Se o fundo não consegue explicar em 3 frases como seleciona suas empresas, provavelmente não tem critérios ESG reais.`,
  },
  {
    number: 3,
    title: "ESG no Brasil: o que é diferente e o que você precisa saber",
    content: `## ESG no Brasil: particularidades que o investidor precisa conhecer

O Brasil tem um contexto ESG único no mundo — tanto em riscos quanto em oportunidades.

### Riscos específicos do mercado brasileiro

**Desmatamento e cadeia produtiva:** Empresas de agronegócio, papel e celulose, e mineração enfrentam escrutínio crescente sobre desmatamento na Amazônia e Cerrado. Investidores internacionais monitoram isso de perto — e podem desinvestir rapidamente quando surgem escândalos.

**Trabalho análogo à escravidão:** O Brasil tem um dos maiores programas de fiscalização do trabalho escravo do mundo. Empresas que aparecem na "lista suja" do MTE sofrem consequências reputacionais e financeiras severas.

**Governança em empresas estatais:** Empresas com participação estatal (Petrobras, Eletrobras, Banco do Brasil) têm riscos de governança específicos: interferência política, nomeações não-técnicas, decisões que beneficiam o acionista controlador em detrimento dos minoritários.

### Oportunidades únicas

**Energia renovável:** O Brasil tem uma das matrizes elétricas mais limpas do mundo (hidrelétrica, eólica, solar). Empresas do setor elétrico brasileiro têm vantagem ESG estrutural em comparação com pares globais.

**Biodiversidade e bioeconomia:** A Amazônia representa um ativo de biodiversidade sem paralelo. Empresas que desenvolvem modelos de negócio baseados em conservação (castanha, açaí, biotecnologia) estão na fronteira de uma nova economia.

**Mercado de carbono:** O Brasil está construindo seu mercado regulado de carbono (SBCE). Empresas que já têm inventários de emissões e projetos de redução estarão melhor posicionadas quando o mercado se consolidar.

> **Princípio:** No Brasil, o risco ESG mais relevante para a maioria das empresas não é o ambiental — é o de governança. Comece avaliando como a empresa trata seus acionistas minoritários.`,
  },
  {
    number: 4,
    title: "Como construir uma carteira com critérios ESG",
    content: `## Como construir uma carteira com critérios ESG

Investir com critérios ESG não significa abrir mão de diversificação ou retorno. Significa adicionar uma camada de análise que o mercado tradicional frequentemente ignora.

### Abordagens possíveis

**1. Exclusão simples**
Você define setores que não quer financiar (ex: tabaco, armamentos, combustíveis fósseis) e exclui empresas desses setores da sua carteira. É a abordagem mais simples, mas não garante que as empresas restantes tenham boas práticas.

**2. Integração ESG**
Você inclui fatores ESG como variáveis na sua análise de valuation. Uma empresa com alto risco ambiental não regulado pode parecer barata pelo P/L, mas cara quando você desconta o risco de passivos futuros.

**3. Best-in-class**
Você investe nas empresas com melhores práticas ESG dentro de cada setor — incluindo setores controversos. A lógica é que engajar com as melhores empresas de petróleo, por exemplo, é mais eficaz do que excluir o setor inteiro.

**4. Impacto**
Você investe em empresas ou projetos com o objetivo explícito de gerar impacto positivo mensurável — e aceita que o retorno financeiro pode ser secundário. É a abordagem mais exigente em termos de due diligence.

### Construção prática

Para um investidor pessoa física no Brasil, uma carteira ESG pode combinar:
- **Fundos de ações ESG** para exposição diversificada ao mercado brasileiro
- **Fundos de renda fixa ESG** (debêntures verdes, CRAs de projetos sustentáveis)
- **Ações diretas** de empresas que você analisou e considera bem governadas
- **Fundos globais ESG** para diversificação geográfica

> **Princípio:** Não existe carteira ESG perfeita. O objetivo é reduzir exposição a riscos ESG não precificados e alinhar seu capital com os valores que você quer financiar — dentro das suas restrições de retorno e liquidez.`,
  },
  {
    number: 5,
    title: "Greenwashing: como identificar e evitar",
    content: `## Greenwashing: como identificar e evitar

Greenwashing é quando uma empresa ou fundo exagera ou fabrica suas credenciais de sustentabilidade para atrair investidores e consumidores. É um dos maiores riscos para quem investe com critérios ESG.

### Sinais de alerta em empresas

**Metas sem base:** "Seremos neutros em carbono até 2050" sem plano detalhado, sem metas intermediárias e sem auditoria independente é marketing, não compromisso.

**Relatório ESG sem dados negativos:** Todo relatório de sustentabilidade honesto inclui os problemas, os incidentes e os indicadores que pioraram. Se o relatório só tem boas notícias, ele não é confiável.

**Certificações de baixo rigor:** Existem centenas de selos e certificações de sustentabilidade com critérios muito diferentes. Pesquise o que cada certificação realmente exige antes de usá-la como critério de investimento.

**Ação principal contradiz o discurso:** Uma empresa que lança uma linha de produtos "eco-friendly" enquanto seu negócio principal é altamente poluente não está mudando — está fazendo relações públicas.

### Sinais de alerta em fundos

**Nome ESG sem metodologia:** Qualquer fundo pode se chamar "ESG" ou "Sustentável" no Brasil sem critérios mínimos regulatórios (isso está mudando com as novas regras da CVM).

**Carteira idêntica ao índice:** Se o fundo ESG tem as mesmas ações que o Ibovespa, ele não está aplicando critérios de exclusão reais.

**Sem engajamento:** Gestores ESG sérios publicam relatórios de engajamento mostrando como dialogaram com as empresas. Se não há engajamento, o ESG é passivo.

### Como se proteger

1. Leia a política de investimento do fundo, não apenas o marketing
2. Verifique a carteira real — as 10 maiores posições dizem mais do que qualquer declaração
3. Procure relatórios de engajamento e histórico de votação em assembleias
4. Desconfie de fundos que não conseguem explicar por que excluíram ou incluíram empresas específicas

> **Princípio:** A melhor defesa contra greenwashing é fazer perguntas específicas. Peça dados, peça metodologia, peça o histórico de votação. Quem tem substância responde. Quem não tem, desvia.`,
  },
];

for (const entry of entries) {
  await connection.execute(
    `INSERT INTO guide_entries (guideId, entryNumber, title, content, createdAt)
     VALUES (?, ?, ?, ?, NOW())`,
    [guideId, entry.number, entry.title, entry.content]
  );
  console.log(`  ✓ Entry ${entry.number}: ${entry.title}`);
}

console.log("\n✅ Guia ESG criado com sucesso!");
await connection.end();
